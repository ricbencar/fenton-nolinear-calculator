r"""Read-only parity reference: emit JSON to stdout; never open the GUI or write reports.

Run from android: ..\.venv\Scripts\python.exe tools/python_reference.py
The reference module is the user's current ../fenton_gui.py, not an archived copy.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import Mock

sys.dont_write_bytecode = True
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
sys.stdout.reconfigure(encoding="utf-8")
source = Path(__file__).resolve().parents[2] / "fenton_gui.py"
spec = importlib.util.spec_from_file_location("fenton_reference", source)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

# Kotlin property -> reference attribute, in a stable order for generated fixtures.
fields = {
    "wavelength": "L", "waveNumber": "k", "celerity": "c",
    "crestElevation": "eta_crest", "troughElevation": "eta_trough",
    "eulerianCurrent": "EulerianCurrent", "stokesCurrent": "StokesCurrent",
    "meanFluidSpeed": "MeanFluidSpeed", "waveVolumeFlux": "WaveVolumeFlux_q",
    "volumeFlux": "VolumeFluxQ", "bernoulliConstant": "BernoulliR",
    "reducedBernoulliConstant": "Bernoulli_r",
    "kineticEnergy": "KineticEnergy", "potentialEnergy": "PotentialEnergy",
    "totalEnergy": "EnergyDensity", "momentumFlux": "MomentumFlux",
    "radiationStress": "Sxx", "impulse": "Impulse", "wavePower": "Power",
    "groupVelocity": "Cg", "surfaceHorizontalVelocity": "u_surf",
    "bedHorizontalVelocity": "u_bed", "maxHorizontalAcceleration": "acc_max",
    "maxBedHorizontalAcceleration": "acc_bed_max", "maxVerticalVelocity": "w_max",
    "velocityAsymmetry": "asymmetry", "meanSquareBedOrbitalVelocity": "MeanSquareBedVelocity",
    "meanSquareBedAbsoluteVelocity": "MeanSquareBedAbsoluteVelocity",
    "tauBed": "tau_bed", "bedExcursion": "ExcursionBed",
    "micheBreakingLimit": "breaking_limit_miche", "saturation": "breaking_index",
    "ursellNumber": "ursell", "kineticEnergyDepth": "KE_depth", "potentialEnergyDepth": "PE_depth",
    "energyDepth": "E_depth", "momentumFluxDepth": "MomentumFluxDepth",
    "radiationStressDepth": "Sxx_depth", "impulseDepth": "I_depth", "wavePowerDepth": "F_depth",
}
cases = [
    (1, 9, 10, 0, 1), (1, 9, 10, .5, 1), (1, 9, 10, -.5, 1),
    (1, 9, 5, 0, 1), (.2, 4, 60, 0, 1), (2, 9, 10, 0, 1),
    (1, 9, 10, .2, 2), (3, 9, 5, 0, 1), (3, 9, 5, 1, 1),
    *[(h, t, 5, u, 1) for h in (1, 2) for t in (3, 4) for u in (0, 1)],
    (3, 4, 5, 1, 1), (1, 3, 20, -.5, 1), (2, 4, 5, .2, 2), (1, 3, 5, .5, 2),
]
results = []
solutions = {}
for case in cases:
    solver = module.FentonStreamFunction(*case[:4])
    solver.Current_criterion = case[4]
    solver.solve()
    solutions[case] = solver
    results.append({
        "input": case, "order": solver.n, "accepted": bool(solver.converged),
        "status": solver.solution_status, "message": solver.last_error,
        "values": {name: float(getattr(solver, attr)) for name, attr in fields.items()}
        if solver.converged else {},
    })
    print(f"Reference {case}: {solver.solution_status}, N={solver.n}", file=sys.stderr, flush=True)

# Capture the desktop formatter in memory, including its glossary and exact spacing.
def deny_file(*args, **kwargs):
    raise OSError("File output deliberately disabled by parity runner")

module.open = deny_file
lines = []
fake = SimpleNamespace(txt_output=Mock(), btn_calc=Mock(), log=lambda text, _: lines.append(text))
module.FentonApp._finalize_output(
    fake, solutions[(3, 9, 5, 0, 1)], solutions[(3, 9, 5, 1, 1)], 3.0, 9.0, 5.0, 1.0,
)
print(json.dumps({
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "fields": list(fields), "cases": results, "default_report": "".join(lines),
}, ensure_ascii=True, allow_nan=False))
