package com.example.fenton.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MaritimeDarkPrimary,
    onPrimary = Color(0xFF002044),
    primaryContainer = Color(0xFF0B3D70),
    onPrimaryContainer = Color(0xFFD4E8FF),
    secondary = MaritimeDarkSecondary,
    onSecondary = Color(0xFF0B2945),
    secondaryContainer = Color(0xFF234A6D),
    onSecondaryContainer = Color(0xFFD7E9FA),
    tertiary = MaritimeDarkTertiary,
    onTertiary = Color(0xFF003733),
    tertiaryContainer = Color(0xFF07544F),
    onTertiaryContainer = Color(0xFFB6F1EC),
    error = MaritimeDarkError,
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = MaritimeDarkBackground,
    onBackground = MaritimeDarkText,
    surface = MaritimeDarkSurface,
    onSurface = MaritimeDarkText,
    surfaceVariant = MaritimeDarkSurfaceVariant,
    onSurfaceVariant = MaritimeDarkMutedText,
    outline = MaritimeDarkOutline,
    outlineVariant = MaritimeDarkOutlineVariant,
    inverseSurface = MaritimeDarkText,
    inverseOnSurface = MaritimeDarkBackground,
    inversePrimary = MaritimeNavy,
    scrim = Color.Black,
)

private val LightColorScheme = lightColorScheme(
    primary = MaritimeNavy,
    onPrimary = Color.White,
    primaryContainer = MaritimePrimaryContainer,
    onPrimaryContainer = MaritimeNavy,
    secondary = MaritimeBlue,
    onSecondary = Color.White,
    secondaryContainer = MaritimeSecondaryContainer,
    onSecondaryContainer = MaritimeText,
    tertiary = MaritimeTeal,
    onTertiary = Color(0xFF00201E),
    tertiaryContainer = MaritimeTertiaryContainer,
    onTertiaryContainer = Color(0xFF003D39),
    error = MaritimeError,
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = MaritimeBackground,
    onBackground = MaritimeText,
    surface = MaritimeSurface,
    onSurface = MaritimeText,
    surfaceVariant = MaritimeSurfaceVariant,
    onSurfaceVariant = MaritimeMutedText,
    outline = MaritimeOutline,
    outlineVariant = MaritimeOutlineVariant,
    inverseSurface = MaritimeText,
    inverseOnSurface = MaritimeBackground,
    inversePrimary = MaritimeDarkPrimary,
    scrim = Color.Black,
)

@Composable
fun FentonTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    // Keep the scientific palette stable across Android versions; dynamic color is
    // intentionally not applied. Retain the parameter for source compatibility.
    @Suppress("UNUSED_VARIABLE")
    val dynamicColorRequested = dynamicColor

    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography = Typography,
        content = content,
    )
}
