package com.example.fenton.ui.dashboard

import com.example.fenton.solver.FentonCalculation
import com.example.fenton.solver.WaveSolution
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sqrt

/** Maps a numerical Fenton result into solution cards, comparison rows, and highlights. */
object FentonDashboardMapper {
    const val STATUS_TITLE: String = "Full nonlinear solution converged"
    const val STATUS_SUBTITLE: String = "Fourier order N=50 • 110 nonlinear equations"

    const val DIMENSIONS_SECTION: String = "Dimensions & Wave Velocity"
    const val CURRENTS_SECTION: String = "Currents, Fluxes & Bernoulli"
    const val INTEGRAL_SECTION: String = "Integral Forces & Momentum Fluxes"
    const val ENERGY_SECTION: String = "Energy Balance & Bed Motion"

    const val HYDRO_DISPERSION_SECTION: String = "DISPERSION & PHASE (GEOMETRY)"
    const val HYDRO_MEAN_FLOWS_SECTION: String = "MEAN FLOWS (FENTON SOLUTION-FLAT)"
    const val HYDRO_FLUXES_SECTION: String = "FLUXES & BERNOULLI CONSTANTS"
    const val HYDRO_INTEGRALS_SECTION: String = "INTEGRAL QUANTITIES (PER UNIT CREST WIDTH)"
    const val HYDRO_KINEMATICS_SECTION: String = "KINEMATICS (EXTREMES / BED ORBITAL MOTION)"
    const val HYDRO_NONLINEARITY_SECTION: String = "NONLINEARITY / BREAKING DIAGNOSTICS"

    private val engineeringHighlightOrder = listOf(
        HydrodynamicParameterId.WAVELENGTH,
        HydrodynamicParameterId.WAVE_NUMBER,
        HydrodynamicParameterId.HEIGHT_TO_DEPTH,
        HydrodynamicParameterId.DIMENSIONLESS_PERIOD,
        HydrodynamicParameterId.CELERITY,
        HydrodynamicParameterId.CREST_ELEVATION,
        HydrodynamicParameterId.TROUGH_ELEVATION,
        HydrodynamicParameterId.MICHE_BREAKING_LIMIT,
        HydrodynamicParameterId.SATURATION,
        HydrodynamicParameterId.MAX_SURFACE_HORIZONTAL_VELOCITY,
        HydrodynamicParameterId.MAX_BED_HORIZONTAL_VELOCITY,
    )
    private val engineeringHighlightOrderById =
        engineeringHighlightOrder.withIndex().associate { (index, id) -> id to index }

    fun map(calculation: FentonCalculation): DashboardResult {
        val requested = calculation.withCurrent
        val hasCurrent = requested.inputCurrent != 0.0
        val hydrodynamicSections = mapHydrodynamicSections(
            noCurrent = calculation.noCurrent,
            withCurrent = requested,
            hasCurrent = hasCurrent,
        )
        val highlights = hydrodynamicSections
            .flatMap(HydrodynamicSection::rows)
            .filter(HydrodynamicRow::isHighlight)
            .plus(
                mapReferenceScaleHighlights(
                    noCurrent = calculation.noCurrent,
                    withCurrent = requested,
                    hasCurrent = hasCurrent,
                ),
            )
            .sortedBy { row -> requireNotNull(row.highlightOrder) }
        check(highlights.map(HydrodynamicRow::id) == engineeringHighlightOrder) {
            "Engineering highlights must contain the complete canonical sequence."
        }
        return DashboardResult(
            submittedInput = SubmittedWaveInput(
                waveHeight = requested.waveHeight,
                wavePeriod = requested.wavePeriod,
                waterDepth = requested.waterDepth,
                currentVelocity = requested.inputCurrent,
            ),
            noCurrent = mapSolution(calculation.noCurrent, DashboardMode.NO_CURRENT),
            withCurrent = if (hasCurrent) {
                mapSolution(requested, DashboardMode.WITH_CURRENT)
            } else {
                null
            },
            hasCurrent = hasCurrent,
            statusTitle = STATUS_TITLE,
            statusSubtitle = STATUS_SUBTITLE,
            hydrodynamicSections = hydrodynamicSections,
            highlights = highlights,
        )
    }

    private fun mapHydrodynamicSections(
        noCurrent: WaveSolution,
        withCurrent: WaveSolution,
        hasCurrent: Boolean,
    ): List<HydrodynamicSection> {
        fun numericRow(
            id: HydrodynamicParameterId,
            label: String,
            noCurrentValue: Double,
            withCurrentValue: Double,
            unit: String,
            definition: String,
        ): HydrodynamicRow {
            val order = engineeringHighlightOrderById[id]
            return HydrodynamicRow(
                id = id,
                label = label,
                noCurrentValue = fixed5(noCurrentValue),
                withCurrentValue = if (hasCurrent) fixed5(withCurrentValue) else null,
                unit = unit,
                definition = definition,
                isHighlight = order != null,
                highlightOrder = order,
            )
        }

        fun textRow(
            id: HydrodynamicParameterId,
            label: String,
            noCurrentValue: String,
            withCurrentValue: String,
            unit: String,
            definition: String,
        ): HydrodynamicRow = HydrodynamicRow(
            id = id,
            label = label,
            noCurrentValue = noCurrentValue,
            withCurrentValue = if (hasCurrent) withCurrentValue else null,
            unit = unit,
            definition = definition,
        )

        val noCurrentSqrtGd = sqrt(noCurrent.gravity * noCurrent.waterDepth)
        val withCurrentSqrtGd = sqrt(withCurrent.gravity * withCurrent.waterDepth)

        val dispersion = listOf(
            numericRow(
                HydrodynamicParameterId.WAVELENGTH,
                "Wavelength (L)",
                noCurrent.wavelength,
                withCurrent.wavelength,
                "m",
                "Crest-to-crest wavelength.",
            ),
            numericRow(
                HydrodynamicParameterId.WAVE_NUMBER,
                "Wave number (k)",
                noCurrent.waveNumber,
                withCurrent.waveNumber,
                "rad/m",
                "Spatial angular frequency, k = 2π/L.",
            ),
            numericRow(
                HydrodynamicParameterId.KD,
                "kd",
                noCurrent.kd,
                withCurrent.kd,
                "-",
                "Relative depth expressed as wave number multiplied by water depth.",
            ),
            numericRow(
                HydrodynamicParameterId.ANGULAR_FREQUENCY,
                "Angular frequency (ω)",
                2.0 * PI / noCurrent.wavePeriod,
                2.0 * PI / withCurrent.wavePeriod,
                "rad/s",
                "Angular frequency, ω = 2π/T.",
            ),
            numericRow(
                HydrodynamicParameterId.CELERITY,
                "Celerity / phase speed (c)",
                noCurrent.celerity,
                withCurrent.celerity,
                "m/s",
                "Wave phase speed, c = L/T.",
            ),
            numericRow(
                HydrodynamicParameterId.DIMENSIONLESS_CELERITY,
                "c/√(gd)",
                noCurrent.celerity / noCurrentSqrtGd,
                withCurrent.celerity / withCurrentSqrtGd,
                "-",
                "Wave phase speed normalized by the shallow-water speed √(gd).",
            ),
            numericRow(
                HydrodynamicParameterId.CREST_ELEVATION,
                "Crest elevation (ηc)",
                noCurrent.crestElevation,
                withCurrent.crestElevation,
                "m",
                "Wave-crest elevation relative to still-water level.",
            ),
            numericRow(
                HydrodynamicParameterId.TROUGH_ELEVATION,
                "Trough elevation (ηt)",
                noCurrent.troughElevation,
                withCurrent.troughElevation,
                "m",
                "Wave-trough elevation relative to still-water level.",
            ),
        )

        val meanFlows = listOf(
            numericRow(
                HydrodynamicParameterId.EULERIAN_CURRENT,
                "Eulerian current (ū₁)",
                noCurrent.eulerianCurrent,
                withCurrent.eulerianCurrent,
                "m/s",
                "Eulerian depth-mean current; positive values follow wave propagation.",
            ),
            numericRow(
                HydrodynamicParameterId.STOKES_CURRENT,
                "Stokes current (ū₂)",
                noCurrent.stokesCurrent,
                withCurrent.stokesCurrent,
                "m/s",
                "Stokes or mass-transport current from the nonlinear solution.",
            ),
            numericRow(
                HydrodynamicParameterId.MEAN_FLUID_SPEED,
                "Mean fluid speed (Ū)",
                noCurrent.meanFluidSpeed,
                withCurrent.meanFluidSpeed,
                "m/s",
                "Mean fluid speed in the moving-wave formulation.",
            ),
        )

        val fluxes = listOf(
            numericRow(
                HydrodynamicParameterId.WAVE_VOLUME_FLUX,
                "Wave volume flux (q)",
                noCurrent.waveVolumeFlux,
                withCurrent.waveVolumeFlux,
                "m²/s",
                "Wave volume flux, q = Ūd − Q.",
            ),
            numericRow(
                HydrodynamicParameterId.VOLUME_FLUX,
                "Volume flux (Q)",
                noCurrent.volumeFlux,
                withCurrent.volumeFlux,
                "m²/s",
                "Depth-integrated volume flux.",
            ),
            numericRow(
                HydrodynamicParameterId.BERNOULLI_CONSTANT,
                "Bernoulli constant (R)",
                noCurrent.bernoulliConstant,
                withCurrent.bernoulliConstant,
                "m²/s²",
                "Bernoulli constant of the steady-wave solution.",
            ),
            numericRow(
                HydrodynamicParameterId.REDUCED_BERNOULLI,
                "Reduced Bernoulli (r = R−g d)",
                noCurrent.reducedBernoulliConstant,
                withCurrent.reducedBernoulliConstant,
                "m²/s²",
                "Reduced Bernoulli constant, r = R − gd.",
            ),
        )

        val integrals = listOf(
            numericRow(
                HydrodynamicParameterId.KINETIC_ENERGY,
                "Kinetic energy (T)",
                noCurrent.kineticEnergy / 1_000.0,
                withCurrent.kineticEnergy / 1_000.0,
                "kJ/m²",
                "Kinetic energy density per unit horizontal area.",
            ),
            numericRow(
                HydrodynamicParameterId.POTENTIAL_ENERGY,
                "Potential energy (V)",
                noCurrent.potentialEnergy / 1_000.0,
                withCurrent.potentialEnergy / 1_000.0,
                "kJ/m²",
                "Potential energy density per unit horizontal area.",
            ),
            numericRow(
                HydrodynamicParameterId.TOTAL_ENERGY,
                "Total energy (E = T+V)",
                noCurrent.totalEnergy / 1_000.0,
                withCurrent.totalEnergy / 1_000.0,
                "kJ/m²",
                "Total wave energy density, equal to kinetic plus potential energy.",
            ),
            numericRow(
                HydrodynamicParameterId.MOMENTUM_FLUX,
                "Momentum flux (S)",
                noCurrent.momentumFlux / 1_000.0,
                withCurrent.momentumFlux / 1_000.0,
                "kN/m",
                "Momentum flux in the moving frame, per unit crest width.",
            ),
            numericRow(
                HydrodynamicParameterId.RADIATION_STRESS,
                "Radiation stress (Sₓₓ)",
                noCurrent.radiationStress / 1_000.0,
                withCurrent.radiationStress / 1_000.0,
                "kN/m",
                "Radiation-stress component in the direction of wave propagation.",
            ),
            numericRow(
                HydrodynamicParameterId.IMPULSE,
                "Impulse (I)",
                noCurrent.impulse / 1_000.0,
                withCurrent.impulse / 1_000.0,
                "10³ kg/(m·s)",
                "Wave impulse per unit crest width.",
            ),
            numericRow(
                HydrodynamicParameterId.WAVE_POWER,
                "Wave power (F)",
                noCurrent.wavePower / 1_000.0,
                withCurrent.wavePower / 1_000.0,
                "kW/m",
                "Wave energy flux per unit crest width.",
            ),
            numericRow(
                HydrodynamicParameterId.GROUP_VELOCITY,
                "Group velocity (Cg = F/E)",
                noCurrent.groupVelocity,
                withCurrent.groupVelocity,
                "m/s",
                "Energy-transport velocity defined by the ratio of wave power to total energy density.",
            ),
        )

        val kinematics = listOf(
            numericRow(
                HydrodynamicParameterId.MAX_SURFACE_HORIZONTAL_VELOCITY,
                "Max surface horiz. vel |u|",
                noCurrent.surfaceHorizontalVelocity,
                withCurrent.surfaceHorizontalVelocity,
                "m/s",
                "Horizontal free-surface velocity evaluated at the crest phase.",
            ),
            numericRow(
                HydrodynamicParameterId.MAX_BED_HORIZONTAL_VELOCITY,
                "Max bed horiz. vel |u|",
                noCurrent.bedHorizontalVelocity,
                withCurrent.bedHorizontalVelocity,
                "m/s",
                "Horizontal seabed velocity evaluated at the crest phase.",
            ),
            numericRow(
                HydrodynamicParameterId.MAX_HORIZONTAL_ACCELERATION,
                "Max horiz. accel |aₓ|",
                noCurrent.maxHorizontalAcceleration,
                withCurrent.maxHorizontalAcceleration,
                "m/s²",
                "Maximum horizontal fluid-acceleration magnitude over the phase scan.",
            ),
            numericRow(
                HydrodynamicParameterId.VELOCITY_ASYMMETRY,
                "Velocity asymmetry |uc|/|ut|",
                noCurrent.velocityAsymmetry,
                withCurrent.velocityAsymmetry,
                "-",
                "Magnitude ratio between crest-phase and trough-phase horizontal velocities.",
            ),
            numericRow(
                HydrodynamicParameterId.MEAN_SQUARE_BED_ORBITAL_VELOCITY,
                "Mean square bed orbital vel ub²",
                noCurrent.meanSquareBedOrbitalVelocity,
                withCurrent.meanSquareBedOrbitalVelocity,
                "m²/s²",
                "Mean square orbital bed velocity with the Eulerian current removed.",
            ),
            numericRow(
                HydrodynamicParameterId.BED_ORBITAL_RMS_VELOCITY,
                "Bed orbital RMS velocity ub,rms",
                noCurrent.bedOrbitalRmsVelocity,
                withCurrent.bedOrbitalRmsVelocity,
                "m/s",
                "Root-mean-square orbital bed velocity, √(ub²).",
            ),
        )

        val nonlinearity = listOf(
            numericRow(
                HydrodynamicParameterId.MICHE_BREAKING_LIMIT,
                "Miche breaking limit (Hmax)",
                noCurrent.micheBreakingLimit,
                withCurrent.micheBreakingLimit,
                "m",
                "Miche limiting wave height used as the breaking diagnostic.",
            ),
            numericRow(
                HydrodynamicParameterId.SATURATION,
                "Saturation (H/Hmax)",
                noCurrent.saturation,
                withCurrent.saturation,
                "-",
                "Ratio of the submitted wave height to the Miche limiting height.",
            ),
            textRow(
                HydrodynamicParameterId.BREAKING_STATUS,
                "Breaking status",
                if (noCurrent.isBreaking) "BREAKING" else "STABLE",
                if (withCurrent.isBreaking) "BREAKING" else "STABLE",
                "-",
                "Engineering warning derived from the Miche limiting-height comparison.",
            ),
            numericRow(
                HydrodynamicParameterId.URSELL_NUMBER,
                "Ursell number (U)",
                noCurrent.ursellNumber,
                withCurrent.ursellNumber,
                "-",
                "Shallow-water nonlinearity measure, H L²/d³.",
            ),
            textRow(
                HydrodynamicParameterId.DEPTH_REGIME,
                "Regime (by d/L)",
                noCurrent.regime,
                withCurrent.regime,
                "-",
                "Depth regime classified from the relative depth d/L.",
            ),
        )

        return listOf(
            HydrodynamicSection(HYDRO_DISPERSION_SECTION, dispersion),
            HydrodynamicSection(HYDRO_MEAN_FLOWS_SECTION, meanFlows),
            HydrodynamicSection(HYDRO_FLUXES_SECTION, fluxes),
            HydrodynamicSection(HYDRO_INTEGRALS_SECTION, integrals),
            HydrodynamicSection(HYDRO_KINEMATICS_SECTION, kinematics),
            HydrodynamicSection(HYDRO_NONLINEARITY_SECTION, nonlinearity),
        )
    }

    /** Reference-scale values intentionally omitted from the full comparison table. */
    private fun mapReferenceScaleHighlights(
        noCurrent: WaveSolution,
        withCurrent: WaveSolution,
        hasCurrent: Boolean,
    ): List<HydrodynamicRow> {
        fun referenceRow(
            id: HydrodynamicParameterId,
            label: String,
            noCurrentValue: Double,
            withCurrentValue: Double,
            definition: String,
        ): HydrodynamicRow = HydrodynamicRow(
            id = id,
            label = label,
            noCurrentValue = fixed5(noCurrentValue),
            withCurrentValue = if (hasCurrent) fixed5(withCurrentValue) else null,
            unit = "-",
            definition = definition,
            isHighlight = true,
            highlightOrder = requireNotNull(engineeringHighlightOrderById[id]),
        )

        return listOf(
            referenceRow(
                id = HydrodynamicParameterId.HEIGHT_TO_DEPTH,
                label = "Height to depth (H/d)",
                noCurrentValue = noCurrent.waveHeight / noCurrent.waterDepth,
                withCurrentValue = withCurrent.waveHeight / withCurrent.waterDepth,
                definition = "Submitted wave height normalized by the still-water depth.",
            ),
            referenceRow(
                id = HydrodynamicParameterId.DIMENSIONLESS_PERIOD,
                label = "Dimensionless period τ√(g/d)",
                noCurrentValue = noCurrent.wavePeriod * sqrt(noCurrent.gravity / noCurrent.waterDepth),
                withCurrentValue = withCurrent.wavePeriod * sqrt(withCurrent.gravity / withCurrent.waterDepth),
                definition = "Submitted wave period normalized using gravity and still-water depth.",
            ),
        )
    }

    private fun mapSolution(
        solution: WaveSolution,
        mode: DashboardMode,
    ): DashboardSolution {
        val gravity = solution.gravity
        val depth = solution.waterDepth
        val sqrtGd = sqrt(gravity * depth)
        val sqrtGd3 = sqrt(gravity * depth * depth * depth)

        val byId = listOf(
            metric(
                id = 1,
                label = "Water depth",
                value = depth,
                unit = "m",
                formula = "d/d = 1",
                dimensionlessValue = 1.0,
                definition = "Still-water depth from the seabed to mean water level; the reference length scale.",
            ),
            metric(
                id = 2,
                label = "Wave length",
                value = solution.wavelength,
                unit = "m",
                formula = "λ/d",
                dimensionlessValue = solution.wavelength / depth,
                definition = "Crest-to-crest wavelength.",
                emphasis = DashboardEmphasis.PRIMARY,
            ),
            metric(
                id = 3,
                label = "Wave height",
                value = solution.waveHeight,
                unit = "m",
                formula = "H/d",
                dimensionlessValue = solution.waveHeight / depth,
                definition = "Crest-to-trough wave height.",
            ),
            metric(
                id = 4,
                label = "Wave period",
                value = solution.wavePeriod,
                unit = "s",
                formula = "τ√(g/d)",
                dimensionlessValue = solution.wavePeriod * sqrt(gravity / depth),
                definition = "Time between successive wave crests.",
            ),
            metric(
                id = 5,
                label = "Wave speed",
                value = solution.celerity,
                unit = "m/s",
                formula = "c/√(gd)",
                dimensionlessValue = solution.celerity / sqrtGd,
                definition = "Phase speed (celerity), c = L/T.",
            ),
            metric(
                id = 6,
                label = "Eulerian current",
                value = solution.eulerianCurrent,
                unit = "m/s",
                formula = "ū₁/√(gd)",
                dimensionlessValue = solution.eulerianCurrent / sqrtGd,
                definition = "Eulerian depth-mean current; positive values follow wave propagation.",
            ),
            metric(
                id = 7,
                label = "Stokes current",
                value = solution.stokesCurrent,
                unit = "m/s",
                formula = "ū₂/√(gd)",
                dimensionlessValue = solution.stokesCurrent / sqrtGd,
                definition = "Stokes or mass-transport current from the nonlinear solution.",
            ),
            metric(
                id = 8,
                label = "Mean fluid speed",
                value = solution.meanFluidSpeed,
                unit = "m/s",
                formula = "Ū/√(gd)",
                dimensionlessValue = solution.meanFluidSpeed / sqrtGd,
                definition = "Mean fluid speed in the moving-wave formulation.",
            ),
            metric(
                id = 9,
                label = "Wave volume flux",
                value = solution.waveVolumeFlux,
                unit = "m²/s",
                formula = "q/√(gd³)",
                dimensionlessValue = solution.waveVolumeFlux / sqrtGd3,
                definition = "Wave volume flux, q = Ūd − Q.",
            ),
            metric(
                id = 10,
                label = "Reduced Bernoulli constant",
                value = solution.reducedBernoulliConstant,
                unit = "m²/s²",
                formula = "r/gd",
                dimensionlessValue = solution.reducedBernoulliConstant / (gravity * depth),
                definition = "Reduced Bernoulli constant, r = R − gd.",
            ),
            metric(
                id = 11,
                label = "Volume flux",
                value = solution.volumeFlux,
                unit = "m²/s",
                formula = "Q/√(gd³)",
                dimensionlessValue = solution.volumeFlux / sqrtGd3,
                definition = "Depth-integrated volume flux.",
            ),
            metric(
                id = 12,
                label = "Bernoulli constant",
                value = solution.bernoulliConstant,
                unit = "m²/s²",
                formula = "R/gd",
                dimensionlessValue = solution.bernoulliConstant / (gravity * depth),
                definition = "Bernoulli constant of the steady-wave solution.",
            ),
            metric(
                id = 13,
                label = "Momentum flux",
                value = solution.momentumFlux / 1_000.0,
                unit = "kN/m",
                formula = "S/ρgd²",
                dimensionlessValue = solution.momentumFluxDepth,
                definition = "Momentum flux in the moving frame, per unit crest width.",
            ),
            metric(
                id = 14,
                label = "Impulse",
                value = solution.impulse / 1_000.0,
                unit = "10³ kg/(m·s)",
                formula = "I/(ρ√(gd³))",
                dimensionlessValue = solution.impulseDepth,
                definition = "Wave impulse per unit crest width.",
            ),
            metric(
                id = 15,
                label = "Kinetic energy",
                value = solution.kineticEnergy / 1_000.0,
                unit = "kJ/m²",
                formula = "T/ρgd²",
                dimensionlessValue = solution.kineticEnergyDepth,
                definition = "Kinetic energy density per unit horizontal area.",
            ),
            metric(
                id = 16,
                label = "Potential energy",
                value = solution.potentialEnergy / 1_000.0,
                unit = "kJ/m²",
                formula = "V/ρgd²",
                dimensionlessValue = solution.potentialEnergyDepth,
                definition = "Potential energy density per unit horizontal area.",
            ),
            metric(
                id = 17,
                label = "Mean square of bed velocity",
                value = solution.meanSquareBedOrbitalVelocity,
                unit = "m²/s²",
                formula = "ub²/gd",
                dimensionlessValue = solution.meanSquareBedOrbitalVelocity / (gravity * depth),
                definition = "Mean square orbital bed velocity, with the Eulerian current removed.",
                emphasis = DashboardEmphasis.BED,
            ),
            metric(
                id = 18,
                label = "Radiation stress",
                value = solution.radiationStress / 1_000.0,
                unit = "kN/m",
                formula = "S_xx/ρgd²",
                dimensionlessValue = solution.radiationStressDepth,
                definition = "Radiation-stress component in the direction of wave propagation.",
            ),
            metric(
                id = 19,
                label = "Wave power",
                value = solution.wavePower / 1_000.0,
                unit = "kW/m",
                formula = "F/(ρg³ᐟ²d⁵ᐟ²)",
                dimensionlessValue = solution.wavePowerDepth,
                definition = "Wave energy flux per unit crest width.",
                emphasis = DashboardEmphasis.ACCENT,
            ),
        ).associateBy(DashboardMetric::id)

        fun items(vararg ids: Int): List<DashboardMetric> = ids.map { id ->
            requireNotNull(byId[id]) { "Missing dashboard item $id." }
        }

        return DashboardSolution(
            mode = mode,
            title = when (mode) {
                DashboardMode.NO_CURRENT -> "No Current"
                DashboardMode.WITH_CURRENT -> "With Current"
            },
            sections = listOf(
                DashboardSection(DIMENSIONS_SECTION, items(1, 2, 3, 4, 5)),
                DashboardSection(CURRENTS_SECTION, items(6, 7, 8, 9, 10, 11, 12)),
                DashboardSection(INTEGRAL_SECTION, items(13, 14, 18, 19)),
                DashboardSection(ENERGY_SECTION, items(15, 16, 17)),
            ),
        )
    }

    private fun metric(
        id: Int,
        label: String,
        value: Double,
        unit: String,
        formula: String,
        dimensionlessValue: Double,
        definition: String,
        emphasis: DashboardEmphasis = DashboardEmphasis.DEFAULT,
    ): DashboardMetric = DashboardMetric(
        id = id,
        label = label,
        physicalValue = fixed5(value),
        physicalUnit = unit,
        dimensionlessFormula = formula,
        dimensionlessValue = fixed5(dimensionlessValue),
        definition = definition,
        emphasis = emphasis,
    )

    private fun fixed5(value: Double): String = String.format(Locale.US, "%.5f", value)
}
