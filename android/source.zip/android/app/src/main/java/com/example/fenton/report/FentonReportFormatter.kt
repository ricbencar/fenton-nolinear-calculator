package com.example.fenton.report

import com.example.fenton.solver.FentonCalculation
import com.example.fenton.solver.WaveSolution
import java.util.Locale
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sqrt

/** Produces the fixed-width text report emitted by the desktop application. */
object FentonReportFormatter {
    const val REPORT_WIDTH: Int = 107

    private const val INNER_WIDTH: Int = REPORT_WIDTH - 2

    fun format(calculation: FentonCalculation): String = buildString {
        val reference = requireNotNull(calculation.noCurrent ?: calculation.withCurrent)
        val noCurrent = calculation.noCurrent ?: reference
        val withCurrent = calculation.withCurrent ?: reference
        val hasCurrent = calculation.input.currentVelocity != 0.0
        val valid0 = calculation.noCurrent != null
        val validC = hasCurrent && calculation.withCurrent != null
        val issues = listOfNotNull(
            calculation.noCurrentFailure?.let { "[No current] $it" },
            calculation.withCurrentFailure?.let { "[With current] $it" },
        )

        boxTitle("NONLINEAR WAVE HYDRODYNAMICS SOLVER (FENTON)")
        boxText("Wave height (H)             : ${noCurrent.waveHeight} m")
        boxText("Wave period (τ)             : ${noCurrent.wavePeriod} s")
        boxText("Water depth (d)             : ${noCurrent.waterDepth} m")
        boxText(
            "Eulerian current ū₁         : ${calculation.input.currentVelocity} m/s " +
                "(positive with wave propagation)",
        )
        horizontalLine()
        boxText(if (issues.isEmpty()) "Status: Finite-system and output accuracy checks passed."
            else "Status: Results shown for converged cases only.")
        for ((valid, solution, label) in listOf(
            Triple(valid0, noCurrent, "No current"), Triple(validC, withCurrent, "With current"),
        )) {
            if (!valid) continue
            val diagnostic = solution.diagnostics
            boxText("$label: N=${diagnostic.fourierOrder}; max|F|=${scientific3(diagnostic.residualMax)}")
            if (diagnostic.verified) {
                boxText("Finite-system interval residual bound: ${scientific3(diagnostic.intervalResidualMax)}; nine output bounds checked.")
            }
            if (diagnostic.numericalNote.isNotEmpty()) boxText(diagnostic.numericalNote)
        }
        horizontalLine()
        issues.forEach { append(it).append('\n') }
        append('\n')

        appendHydrodynamicSummary(noCurrent, withCurrent, hasCurrent, valid0, validC)
        if (valid0) appendSolutionFlat(noCurrent, "SOLUTION.RES (NO CURRENT)")
        if (validC) {
            appendSolutionFlat(withCurrent, "SOLUTION.RES (WITH CURRENT)")
        }
        appendGlossary()
    }

    private fun StringBuilder.appendHydrodynamicSummary(
        noCurrent: WaveSolution,
        withCurrent: WaveSolution,
        hasCurrent: Boolean,
        valid0: Boolean,
        validC: Boolean,
    ) {
        val gravity = noCurrent.gravity
        val depth = noCurrent.waterDepth
        val sqrtGd = sqrt(gravity * depth)
        val sqrtGOverD = sqrt(gravity / depth)

        fun current(value: Any): Any = if (hasCurrent) value else "-"

        val rows = buildList {
            add(section("INPUTS & REFERENCE SCALES"))
            add(cells("Water depth (d)", noCurrent.waterDepth, current(withCurrent.waterDepth), "m"))
            add(cells("Wave height (H)", noCurrent.waveHeight, current(withCurrent.waveHeight), "m"))
            add(cells("Wave period (τ)", noCurrent.wavePeriod, current(withCurrent.wavePeriod), "s"))
            add(
                cells(
                    "H/d",
                    noCurrent.waveHeight / noCurrent.waterDepth,
                    current(withCurrent.waveHeight / withCurrent.waterDepth),
                    "-",
                ),
            )
            add(
                cells(
                    "τ√(g/d)",
                    noCurrent.wavePeriod * sqrtGOverD,
                    current(withCurrent.wavePeriod * sqrt(withCurrent.gravity / withCurrent.waterDepth)),
                    "-",
                ),
            )

            add(section("DISPERSION & PHASE (GEOMETRY)"))
            add(cells("Wavelength (L)", noCurrent.wavelength, current(withCurrent.wavelength), "m"))
            add(cells("Wave number (k)", noCurrent.waveNumber, current(withCurrent.waveNumber), "rad/m"))
            add(cells("kd", noCurrent.kd, current(withCurrent.kd), "-"))
            add(
                cells(
                    "Angular frequency (ω)",
                    2.0 * PI / noCurrent.wavePeriod,
                    current(2.0 * PI / withCurrent.wavePeriod),
                    "rad/s",
                ),
            )
            add(cells("Celerity / phase speed (c)", noCurrent.celerity, current(withCurrent.celerity), "m/s"))
            add(cells("c/√(gd)", noCurrent.celerity / sqrtGd, current(withCurrent.celerity / sqrt(withCurrent.gravity * withCurrent.waterDepth)), "-"))
            add(cells("Crest elevation (ηc)", noCurrent.crestElevation, current(withCurrent.crestElevation), "m"))
            add(cells("Trough elevation (ηt)", noCurrent.troughElevation, current(withCurrent.troughElevation), "m"))

            add(section("MEAN FLOWS (FENTON SOLUTION-FLAT)"))
            add(cells("Eulerian current (ū₁)", noCurrent.eulerianCurrent, current(withCurrent.eulerianCurrent), "m/s"))
            add(cells("Stokes current (ū₂)", noCurrent.stokesCurrent, current(withCurrent.stokesCurrent), "m/s"))
            add(cells("Mean fluid speed (Ū)", noCurrent.meanFluidSpeed, current(withCurrent.meanFluidSpeed), "m/s"))

            add(section("FLUXES & BERNOULLI CONSTANTS"))
            add(cells("Wave volume flux (q)", noCurrent.waveVolumeFlux, current(withCurrent.waveVolumeFlux), "m²/s"))
            add(cells("Volume flux (Q)", noCurrent.volumeFlux, current(withCurrent.volumeFlux), "m²/s"))
            add(cells("Bernoulli constant (R)", noCurrent.bernoulliConstant, current(withCurrent.bernoulliConstant), "m²/s²"))
            add(cells("Reduced Bernoulli (r = R−g d)", noCurrent.reducedBernoulliConstant, current(withCurrent.reducedBernoulliConstant), "m²/s²"))

            add(section("INTEGRAL QUANTITIES (PER UNIT CREST WIDTH)"))
            add(cells("Kinetic energy (T)", noCurrent.kineticEnergy / 1_000.0, current(withCurrent.kineticEnergy / 1_000.0), "kJ/m²"))
            add(cells("Potential energy (V)", noCurrent.potentialEnergy / 1_000.0, current(withCurrent.potentialEnergy / 1_000.0), "kJ/m²"))
            add(cells("Total energy (E = T+V)", noCurrent.totalEnergy / 1_000.0, current(withCurrent.totalEnergy / 1_000.0), "kJ/m²"))
            add(cells("Momentum flux (S)", noCurrent.momentumFlux / 1_000.0, current(withCurrent.momentumFlux / 1_000.0), "kN/m"))
            add(cells("Radiation stress (Sₓₓ)", noCurrent.radiationStress / 1_000.0, current(withCurrent.radiationStress / 1_000.0), "kN/m"))
            add(cells("Impulse (I)", noCurrent.impulse / 1_000.0, current(withCurrent.impulse / 1_000.0), "10³ kg/(m·s)"))
            add(cells("Wave power (F)", noCurrent.wavePower / 1_000.0, current(withCurrent.wavePower / 1_000.0), "kW/m"))
            add(cells("Energy-flux velocity (F/E)\u3164", noCurrent.groupVelocity, current(withCurrent.groupVelocity), "m/s"))

            add(section("KINEMATICS (EXTREMES / BED ORBITAL MOTION)"))
            add(cells("Surface max |u|", noCurrent.surfaceHorizontalVelocity, current(withCurrent.surfaceHorizontalVelocity), "m/s"))
            add(cells("Bed max |u|", noCurrent.bedHorizontalVelocity, current(withCurrent.bedHorizontalVelocity), "m/s"))
            add(cells("Surface max |aₓ|", noCurrent.maxHorizontalAcceleration, current(withCurrent.maxHorizontalAcceleration), "m/s²"))
            add(cells("Bed max |aₓ|", noCurrent.maxBedHorizontalAcceleration, current(withCurrent.maxBedHorizontalAcceleration), "m/s²"))
            add(cells("Velocity asymmetry |uc|/|ut|", noCurrent.velocityAsymmetry, current(withCurrent.velocityAsymmetry), "-"))
            add(cells("Mean square bed orbital vel ub²", noCurrent.meanSquareBedOrbitalVelocity, current(withCurrent.meanSquareBedOrbitalVelocity), "m²/s²"))
            add(
                cells(
                    "Bed orbital RMS velocity ub,rms",
                    sqrt(max(0.0, noCurrent.meanSquareBedOrbitalVelocity)),
                    current(sqrt(max(0.0, withCurrent.meanSquareBedOrbitalVelocity))),
                    "m/s",
                ),
            )

            add(section("NONLINEARITY / BREAKING DIAGNOSTICS"))
            add(cells("Miche breaking limit (Hmax)", noCurrent.micheBreakingLimit, current(withCurrent.micheBreakingLimit), "m"))
            add(cells("Saturation (H/Hmax)", noCurrent.saturation, current(withCurrent.saturation), "-"))
            add(
                cells(
                    "Breaking status",
                    if (noCurrent.isBreaking) "BREAKING" else "BELOW MICHE",
                    if (hasCurrent) {
                        if (withCurrent.isBreaking) "BREAKING" else "BELOW MICHE"
                    } else {
                        "-"
                    },
                    "-",
                ),
            )
            add(cells("Ursell number (U)", noCurrent.ursellNumber, current(withCurrent.ursellNumber), "-"))
            add(cells("Regime (by d/L)", noCurrent.regime, current(withCurrent.regime), "-"))
        }

        printTable(
            title = "CALCULATED HYDRODYNAMIC PARAMETERS",
            headers = listOf("PARAMETER", "NO CURRENT", "WITH CURRENT", "UNIT"),
            widths = listOf(42, 16, 16, 20),
            alignments = listOf(Alignment.LEFT, Alignment.RIGHT, Alignment.RIGHT, Alignment.LEFT),
            rows = rows.map { row ->
                if (row is Row.Cells) Row.Cells(listOf(row.values[0],
                    if (valid0) row.values[1] else null,
                    if (validC) row.values[2] else null, row.values[3]))
                else row
            },
        )
    }

    private fun StringBuilder.appendSolutionFlat(solution: WaveSolution, title: String) {
        val gravity = solution.gravity
        val depth = solution.waterDepth
        val height = solution.waveHeight
        val period = solution.wavePeriod
        val wavelength = solution.wavelength
        val celerity = solution.celerity
        val sqrtGd = sqrt(gravity * depth)
        val sqrtGd3 = sqrt(gravity * depth * depth * depth)

        val rows = listOf(
            cells(1, "Water depth", fixed5(depth), "d/d = 1", fixed5(1.0)),
            cells(2, "Wave length", fixed5(wavelength), "λ/d", fixed5(wavelength / depth)),
            cells(3, "Wave height", fixed5(height), "H/d", fixed5(height / depth)),
            cells(4, "Wave period", fixed5(period), "τ√(g/d)", fixed5(period * sqrt(gravity / depth))),
            cells(5, "Wave speed", fixed5(celerity), "c/√(gd)", fixed5(celerity / sqrtGd)),
            cells(6, "Eulerian current", fixed5(solution.eulerianCurrent), "ū₁/√(gd)", fixed5(solution.eulerianCurrent / sqrtGd)),
            cells(7, "Stokes current", fixed5(solution.stokesCurrent), "ū₂/√(gd)", fixed5(solution.stokesCurrent / sqrtGd)),
            cells(8, "Mean fluid speed", fixed5(solution.meanFluidSpeed), "Ū/√(gd)", fixed5(solution.meanFluidSpeed / sqrtGd)),
            cells(9, "Wave volume flux, q = Ū d − Q", fixed5(solution.waveVolumeFlux), "q/√(gd³)", fixed5(solution.waveVolumeFlux / sqrtGd3)),
            cells(10, "Bernoulli constant, r = R − gd", fixed5(solution.reducedBernoulliConstant), "r/gd", fixed5(solution.reducedBernoulliConstant / (gravity * depth))),
            cells(11, "Volume flux", fixed5(solution.volumeFlux), "Q/√(gd³)", fixed5(solution.volumeFlux / sqrtGd3)),
            cells(12, "Bernoulli constant", fixed5(solution.bernoulliConstant), "R/gd", fixed5(solution.bernoulliConstant / (gravity * depth))),
            cells(13, "Momentum flux", fixed5(solution.momentumFlux / 1_000.0), "S/ρgd²", fixed5(solution.momentumFluxDepth)),
            cells(14, "Impulse", fixed5(solution.impulse / 1_000.0), "I/(ρ√(gd³))", fixed5(solution.impulseDepth)),
            cells(15, "Kinetic energy", fixed5(solution.kineticEnergy / 1_000.0), "T/ρgd²", fixed5(solution.kineticEnergyDepth)),
            cells(16, "Potential energy", fixed5(solution.potentialEnergy / 1_000.0), "V/ρgd²", fixed5(solution.potentialEnergyDepth)),
            cells(17, "Mean square of bed velocity (absolute)", fixed5(solution.meanSquareBedAbsoluteVelocity), "ub²/gd", fixed5(solution.meanSquareBedAbsoluteVelocity / (gravity * depth))),
            cells(18, "Radiation stress", fixed5(solution.radiationStress / 1_000.0), "S_xx/ρgd²", fixed5(solution.radiationStressDepth)),
            cells(19, "Wave power", fixed5(solution.wavePower / 1_000.0), "F/(ρg³ᐟ²d⁵ᐟ²)\u3164\u3164", fixed5(solution.wavePowerDepth)),
        )

        printTable(
            title = title,
            headers = listOf("#", "PARAMETER", "value", "adim param", "adim value"),
            widths = listOf(2, 37, 13, 25, 14),
            alignments = listOf(Alignment.RIGHT, Alignment.LEFT, Alignment.RIGHT, Alignment.LEFT, Alignment.RIGHT),
            rows = rows,
        )
    }

    private fun StringBuilder.appendGlossary() {
        val rows = listOf(
            cells("d", "Still-water depth (bed to mean water level). Reference length scale.", "m ; d/d=1"),
            cells("H", "Wave height (crest-to-trough).", "m ; H/d"),
            cells("τ", "Wave period.", "s ; τ√(g/d)"),
            cells("L", "Wavelength (crest-to-crest).", "m ; L/d"),
            cells("k", "Wave number, k = 2π/L.", "rad/m"),
            cells("ω", "Angular frequency, ω = 2π/τ.", "rad/s"),
            cells("c", "Phase speed (celerity).", "m/s ; c/√(gd)"),
            cells("ηc, ηt", "Crest and trough elevations relative to still-water level.", "m"),
            cells("ū₁", "Eulerian (depth-mean) current; ū₁ = Uc.", "m/s ; ū₁/√(gd)"),
            cells("ū₂", "Stokes / mass-transport current from nonlinear solution.", "m/s ; ū₂/√(gd)"),
            cells("Ū", "Mean fluid speed (depth-mean).", "m/s ; Ū/√(gd)"),
            cells("Q", "Volume flux (depth-integrated).", "m²/s ; Q/√(gd³)"),
            cells("q", "Wave volume flux, q = Ū d − Q.", "m²/s ; q/√(gd³)"),
            cells("R", "Bernoulli constant.", "m²/s² ; R/(gd)"),
            cells("r", "Reduced Bernoulli constant r = R − g d.", "m²/s² ; r/(gd)"),
            cells("S", "Momentum flux (moving frame).", "kN/m ; S/(ρgd²)"),
            cells("I", "Wave impulse per unit width.", "10³ kg/(m·s) ; I/(ρ√(gd³))"),
            cells("T", "Kinetic energy density.", "kJ/m² ; T/(ρgd²)"),
            cells("V", "Potential energy density.", "kJ/m² ; V/(ρgd²)"),
            cells("E", "Total energy density E = T + V.", "kJ/m²"),
            cells("F", "Wave power (energy flux).", "kW/m ; F/(ρg³ᐟ²d⁵ᐟ²)\u3164"),
            cells("Cg", "Energy-flux / energy-density ratio F/E.", "m/s"),
            cells("Sₓₓ", "Radiation stress component in wave direction.", "kN/m ; Sₓₓ/(ρgd²)"),
            cells("ub²", "Mean square *orbital* bed velocity: ub² = <(ub(t) − ū₁)²>. Non-negative by definition; computed by phase averaging.", "m²/s² ; /gd"),
            cells("ub,rms", "Root-mean-square orbital bed velocity: ub,rms = √(ub²).", "m/s"),
            cells("usurf,max", "Maximum absolute surface horizontal velocity over phase.", "m/s"),
            cells("ubed,max", "Maximum absolute bed horizontal velocity over phase.", "m/s"),
            cells("a_x,surf,max", "Maximum absolute surface material horizontal acceleration over phase.", "m/s²"),
            cells("a_x,bed,max", "Maximum absolute bed material horizontal acceleration over phase.", "m/s²"),
            cells("Asymmetry", "Velocity asymmetry indicator |uc|/|ut|.", "-"),
            cells("Hmax", "Miche breaking limit used as stability diagnostic.", "m"),
            cells("Ursell", "Ursell number, a shallow-water nonlinearity measure.", "-"),
            cells("Regime", "Depth regime based on d/L (deep/intermediate/shallow).", "-"),
        )

        printTable(
            title = "PARAMETER DEFINITIONS & GLOSSARY",
            headers = listOf("TERM / SYMBOL", "MEANING", "UNITS / NONDIM"),
            widths = listOf(14, 64, 19),
            alignments = listOf(Alignment.LEFT, Alignment.LEFT, Alignment.LEFT),
            rows = rows,
        )
    }

    private fun scientific3(value: Double): String = String.format(Locale.US, "%.3e", value)

    private fun StringBuilder.horizontalLine(character: Char = '-') {
        append('+')
        repeat(INNER_WIDTH) { append(character) }
        append("+\n")
    }

    private fun StringBuilder.boxTitle(title: String) {
        horizontalLine()
        append('|')
        append(centerLikePython(title, INNER_WIDTH, ' '))
        append("|\n")
        horizontalLine()
    }

    private fun StringBuilder.boxText(text: String) {
        var rendered = text.replace('\n', ' ').trimEnd()
        if (codePointLength(rendered) > INNER_WIDTH) {
            rendered = takeCodePoints(rendered, INNER_WIDTH - 3) + "..."
        }
        append('|')
        append(rendered)
        append(" ".repeat(INNER_WIDTH - codePointLength(rendered)))
        append("|\n")
    }

    private fun StringBuilder.printTable(
        title: String,
        headers: List<String>,
        widths: List<Int>,
        alignments: List<Alignment>,
        rows: List<Row>,
    ) {
        require(headers.size == widths.size && widths.size == alignments.size)
        require(1 + widths.sum() + 3 * widths.size == REPORT_WIDTH)

        boxTitle(title)
        append('|')
        headers.indices.forEach { index ->
            append(' ')
            append(formatCell(headers[index], widths[index], alignments[index]))
            append(" |")
        }
        append('\n')
        tableSeparator(widths)

        rows.forEach { row ->
            when (row) {
                is Row.Section -> {
                    val sectionText = " ${row.title} "
                    append('|')
                    append(centerLikePython(sectionText, INNER_WIDTH, '-'))
                    append("|\n")
                }

                is Row.Cells -> {
                    require(row.values.size == widths.size)
                    val wrapped = row.values.mapIndexed { index, value ->
                        when (value) {
                            null -> listOf("-")
                            is Number -> listOf(value)
                            else -> wrapWords(value.toString().replace('\n', ' ').trimEnd(), widths[index])
                        }
                    }
                    val lineCount = wrapped.maxOf { it.size }
                    repeat(lineCount) { lineIndex ->
                        append('|')
                        wrapped.indices.forEach { column ->
                            val value = wrapped[column].getOrElse(lineIndex) { "" }
                            append(' ')
                            append(formatCell(value, widths[column], alignments[column]))
                            append(" |")
                        }
                        append('\n')
                    }
                }
            }
        }

        horizontalLine()
        append('\n')
    }

    private fun StringBuilder.tableSeparator(widths: List<Int>) {
        append('|')
        widths.forEachIndexed { index, width ->
            if (index > 0) append('+')
            repeat(width + 2) { append('-') }
        }
        append("|\n")
    }

    private fun formatCell(value: Any?, width: Int, alignment: Alignment): String {
        if (value is Number) {
            return formatNumber(value.toDouble(), width)
        }

        val raw = (value?.toString() ?: "-").replace('\n', ' ').trim()
        val rendered = takeCodePoints(raw, width)
        val padding = width - codePointLength(rendered)
        return when (alignment) {
            Alignment.LEFT -> rendered + " ".repeat(padding)
            Alignment.RIGHT -> " ".repeat(padding) + rendered
            Alignment.CENTER -> centerLikePython(rendered, width, ' ')
        }
    }

    private fun formatNumber(value: Double, width: Int): String {
        val special = when {
            value.isNaN() -> "nan"
            value == Double.POSITIVE_INFINITY -> "inf"
            value == Double.NEGATIVE_INFINITY -> "-inf"
            else -> null
        }
        if (special != null) return special.padStart(width)

        for (decimals in intArrayOf(5, 4, 3, 2, 1, 0)) {
            val rendered = String.format(Locale.US, "%.${decimals}f", value)
            if (rendered.length <= width) return rendered.padStart(width)
        }
        for (decimals in intArrayOf(6, 5, 4, 3)) {
            val rendered = String.format(Locale.US, "%.${decimals}e", value)
            if (rendered.length <= width) return rendered.padStart(width)
        }
        return String.format(Locale.US, "%.2e", value).take(width).padStart(width)
    }

    private fun fixed5(value: Double): String = String.format(Locale.US, "%.5f", value)

    private fun wrapWords(text: String, width: Int): List<Any> {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return listOf("")

        val lines = mutableListOf<String>()
        var current = ""
        for (word in words) {
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (current.isNotEmpty() && codePointLength(candidate) > width) {
                lines += current
                current = word
            } else {
                current = candidate
            }
        }
        lines += current
        return lines
    }

    /** Mirrors CPython's odd-margin placement in str.center(). */
    private fun centerLikePython(text: String, width: Int, fill: Char): String {
        val length = codePointLength(text)
        if (length >= width) return text
        val margin = width - length
        val left = margin / 2 + if ((margin and width and 1) != 0) 1 else 0
        val right = margin - left
        return fill.toString().repeat(left) + text + fill.toString().repeat(right)
    }

    private fun codePointLength(value: String): Int = value.codePointCount(0, value.length)

    private fun takeCodePoints(value: String, count: Int): String {
        if (codePointLength(value) <= count) return value
        return value.substring(0, value.offsetByCodePoints(0, count))
    }

    private fun section(title: String): Row = Row.Section(title)

    private fun cells(vararg values: Any?): Row = Row.Cells(values.toList())

    private enum class Alignment {
        LEFT,
        RIGHT,
        CENTER,
    }

    private sealed interface Row {
        data class Section(val title: String) : Row
        data class Cells(val values: List<Any?>) : Row
    }
}
