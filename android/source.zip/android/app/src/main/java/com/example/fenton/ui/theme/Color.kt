package com.example.fenton.ui.theme

import androidx.compose.ui.graphics.Color

// Maritime Navy — light palette
val MaritimeNavy = Color(0xFF002D62)
val MaritimeBlue = Color(0xFF1F4E79)
val MaritimeTeal = Color(0xFF20B2AA)
val MaritimeGreen = Color(0xFF2E8B57)
val MaritimeBackground = Color(0xFFF0F4F8)
val MaritimeSurface = Color(0xFFFFFFFF)
val MaritimeText = Color(0xFF0A192F)
val MaritimeMutedText = Color(0xFF46586E)
val MaritimeOutline = Color(0xFF75869A)
val MaritimeOutlineVariant = Color(0xFFCBD5E1)

val MaritimePrimaryContainer = Color(0xFFD8E8F7)
val MaritimeSecondaryContainer = Color(0xFFDCE8F3)
val MaritimeTertiaryContainer = Color(0xFFCCF1EE)
val MaritimeGreenContainer = Color(0xFFD5EDE0)
val MaritimeSurfaceVariant = Color(0xFFE7EDF3)

// Maritime Navy — dark palette
val MaritimeDarkBackground = Color(0xFF061426)
val MaritimeDarkSurface = Color(0xFF0A1F36)
val MaritimeDarkSurfaceVariant = Color(0xFF132C46)
val MaritimeDarkPrimary = Color(0xFF9EC7F2)
val MaritimeDarkSecondary = Color(0xFFA8C7E6)
val MaritimeDarkTertiary = Color(0xFF5DD6CE)
val MaritimeDarkGreen = Color(0xFF78C99A)
val MaritimeDarkText = Color(0xFFF0F5FA)
val MaritimeDarkMutedText = Color(0xFFBCC9D8)
val MaritimeDarkOutline = Color(0xFF8698AC)
val MaritimeDarkOutlineVariant = Color(0xFF334B64)

val MaritimeError = Color(0xFFBA1A1A)
val MaritimeDarkError = Color(0xFFFFB4AB)
