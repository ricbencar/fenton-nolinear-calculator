package com.example.fenton.ui.dashboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fenton.R
import com.example.fenton.ui.theme.FentonTheme
import com.example.fenton.ui.theme.MaritimeBlue
import com.example.fenton.ui.theme.MaritimeGreen
import com.example.fenton.ui.theme.MaritimeNavy
import com.example.fenton.ui.theme.NumericValueTextStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.milliseconds
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FentonDashboardScreen(
    state: FentonDashboardUiState,
    onIntent: (DashboardIntent) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val clipboard = remember(context) { context.getSystemService(ClipboardManager::class.java) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val reportCopiedMessage = stringResource(R.string.report_copied)
    var selectedHydrodynamicRow by remember { mutableStateOf<HydrodynamicRow?>(null) }
    var showFentonTheory by remember { mutableStateOf(false) }

    val copyReport = {
        state.report?.let { report ->
            clipboard?.setPrimaryClip(ClipData.newPlainText("Fenton engineering report", report))
            scope.launch { snackbarHostState.showSnackbar(reportCopiedMessage) }
        }
        Unit
    }
    val shareReport = {
        state.report?.let { shareReport(context, it) }
        Unit
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            MaritimeTopBar()
        },
    ) { contentPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(contentPadding)) {
            DashboardContent(
                state = state,
                onIntent = onIntent,
                onCopyReport = copyReport,
                onShareReport = shareReport,
                onHydrodynamicInfo = { selectedHydrodynamicRow = it },
                onShowTheory = { showFentonTheory = true },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxSize()
                    .widthIn(max = 1_120.dp),
            )
        }
    }

    selectedHydrodynamicRow?.let { row ->
        HydrodynamicDetailsSheet(
            row = row,
            onDismiss = { selectedHydrodynamicRow = null },
        )
    }
    if (showFentonTheory) {
        FentonTheorySheet(onDismiss = { showFentonTheory = false })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MaritimeTopBar(
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaritimeNavy,
            titleContentColor = Color.White,
            actionIconContentColor = Color.White,
        ),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    modifier = Modifier.semantics { contentDescription = "Wave solver" },
                    shape = CircleShape,
                    color = MaritimeBlue,
                    contentColor = Color.White,
                ) {
                    Text(
                        text = "≈",
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 4.dp),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Column {
                    Text(
                        text = stringResource(R.string.screen_title),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                    )
                    Text(
                        text = stringResource(R.string.screen_subtitle),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.78f),
                        maxLines = 1,
                    )
                }
            }
        },
    )
}

@Composable
private fun DashboardContent(
    state: FentonDashboardUiState,
    onIntent: (DashboardIntent) -> Unit,
    onCopyReport: () -> Unit,
    onShareReport: () -> Unit,
    onHydrodynamicInfo: (HydrodynamicRow) -> Unit,
    onShowTheory: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier) {
        val tabletLayout = maxWidth >= 760.dp
        val horizontalPadding = if (tabletLayout) 28.dp else 16.dp

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = horizontalPadding,
                end = horizontalPadding,
                top = 20.dp,
                bottom = 40.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (state.isEditing) {
                item(key = "input-editor") {
                    WaveInputEditor(
                        state = state,
                        onIntent = onIntent,
                        tabletLayout = tabletLayout,
                    )
                }
            } else {
                state.result?.let { result ->
                    item(key = "fixed-inputs") {
                        FixedInputStrip(
                            input = result.submittedInput,
                            tabletLayout = tabletLayout,
                            onEdit = { onIntent(DashboardIntent.EditInputs) },
                            onShowTheory = onShowTheory,
                        )
                    }
                    item(key = "status") {
                        CurrentStatusCard(result = result)
                    }
                    if (state.report != null) {
                        item(key = "report-actions") {
                            ReportActions(
                                onCopyReport = onCopyReport,
                                onShareReport = onShareReport,
                            )
                        }
                    }

                    if (result.highlights.isNotEmpty()) {
                        item(key = "hydrodynamic-highlights") {
                            HydrodynamicHighlights(
                                rows = result.highlights,
                                tabletLayout = tabletLayout,
                                onInfo = onHydrodynamicInfo,
                            )
                        }
                    }

                    item(key = "hydrodynamic-columns") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "Calculated Hydrodynamic Parameters",
                                modifier = Modifier.semantics { heading() },
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                            )
                            HydrodynamicColumnHeader(hasCurrent = result.hasCurrent)
                        }
                    }

                    itemsIndexed(
                        items = result.hydrodynamicSections,
                        key = { _, section -> section.title },
                    ) { index, section ->
                        AnimatedSection(
                            animationKey = section.title,
                            index = index,
                        ) {
                            HydrodynamicSectionCard(
                                section = section,
                                hasCurrent = result.hasCurrent,
                                onInfo = onHydrodynamicInfo,
                            )
                        }
                    }
                }
            }

            state.errorMessage?.let { message ->
                item(key = "error") { ErrorBanner(message = message) }
            }
        }
    }
}

@Composable
private fun ReportActions(
    onCopyReport: () -> Unit,
    onShareReport: () -> Unit,
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = stringResource(R.string.output_title),
                modifier = Modifier.semantics { heading() },
                style = MaterialTheme.typography.titleSmall,
            )
            Text(
                text = stringResource(R.string.report_actions_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(
                    onClick = onCopyReport,
                    modifier = Modifier.semantics { contentDescription = "Copy the full report" },
                ) {
                    Text(stringResource(R.string.copy_action))
                }
                Button(
                    onClick = onShareReport,
                    modifier = Modifier.semantics { contentDescription = "Share the full report" },
                ) {
                    Text(stringResource(R.string.share_action))
                }
            }
        }
    }
}

@Composable
private fun WaveInputEditor(
    state: FentonDashboardUiState,
    onIntent: (DashboardIntent) -> Unit,
    tabletLayout: Boolean,
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(
            modifier = Modifier.padding(if (tabletLayout) 24.dp else 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.inputs_title),
                    modifier = Modifier.semantics { heading() },
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(
                    text = stringResource(R.string.inputs_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            InputFields(
                state = state,
                onIntent = onIntent,
                tabletLayout = tabletLayout,
            )

            Button(
                onClick = { onIntent(DashboardIntent.Calculate) },
                enabled = !state.isCalculating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .semantics {
                        contentDescription = if (state.isCalculating) {
                            "Calculation in progress"
                        } else {
                            "Calculate nonlinear wave solution"
                        }
                    },
                shape = RoundedCornerShape(16.dp),
            ) {
                if (state.isCalculating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(stringResource(R.string.calculating))
                } else {
                    Text(
                        text = stringResource(R.string.calculate),
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Text(
                text = stringResource(R.string.offline_hint),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun InputFields(
    state: FentonDashboardUiState,
    onIntent: (DashboardIntent) -> Unit,
    tabletLayout: Boolean,
) {
    val fields = listOf(
        InputFieldSpec(
            field = DashboardInputField.WAVE_HEIGHT,
            value = state.waveHeight,
            label = stringResource(R.string.wave_height_label),
            keyboardType = KeyboardType.Decimal,
        ),
        InputFieldSpec(
            field = DashboardInputField.WAVE_PERIOD,
            value = state.wavePeriod,
            label = stringResource(R.string.wave_period_label),
            keyboardType = KeyboardType.Decimal,
        ),
        InputFieldSpec(
            field = DashboardInputField.WATER_DEPTH,
            value = state.waterDepth,
            label = stringResource(R.string.water_depth_label),
            keyboardType = KeyboardType.Decimal,
        ),
        InputFieldSpec(
            field = DashboardInputField.CURRENT_VELOCITY,
            value = state.currentVelocity,
            label = stringResource(R.string.current_velocity_label),
            keyboardType = KeyboardType.Text,
        ),
    )

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        when {
            tabletLayout -> Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top,
            ) {
                fields.forEachIndexed { index, spec ->
                    DashboardDecimalField(
                        spec = spec,
                        invalid = spec.field in state.invalidFields,
                        enabled = !state.isCalculating,
                        imeAction = if (index == fields.lastIndex) ImeAction.Done else ImeAction.Next,
                        onValueChange = { onIntent(DashboardIntent.InputChanged(spec.field, it)) },
                        onDone = { onIntent(DashboardIntent.Calculate) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            maxWidth >= 520.dp -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                fields.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        pair.forEach { spec ->
                            DashboardDecimalField(
                                spec = spec,
                                invalid = spec.field in state.invalidFields,
                                enabled = !state.isCalculating,
                                imeAction = if (spec.field == DashboardInputField.CURRENT_VELOCITY) {
                                    ImeAction.Done
                                } else {
                                    ImeAction.Next
                                },
                                onValueChange = {
                                    onIntent(DashboardIntent.InputChanged(spec.field, it))
                                },
                                onDone = { onIntent(DashboardIntent.Calculate) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
            else -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                fields.forEachIndexed { index, spec ->
                    DashboardDecimalField(
                        spec = spec,
                        invalid = spec.field in state.invalidFields,
                        enabled = !state.isCalculating,
                        imeAction = if (index == fields.lastIndex) ImeAction.Done else ImeAction.Next,
                        onValueChange = { onIntent(DashboardIntent.InputChanged(spec.field, it)) },
                        onDone = { onIntent(DashboardIntent.Calculate) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

private data class InputFieldSpec(
    val field: DashboardInputField,
    val value: String,
    val label: String,
    val keyboardType: KeyboardType,
)

@Composable
private fun DashboardDecimalField(
    spec: InputFieldSpec,
    invalid: Boolean,
    enabled: Boolean,
    imeAction: ImeAction,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    OutlinedTextField(
        value = spec.value,
        onValueChange = onValueChange,
        modifier = modifier,
        enabled = enabled,
        isError = invalid,
        singleLine = true,
        label = { Text(spec.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingText = if (invalid) {
            {
                Text(
                    stringResource(
                        if (spec.field == DashboardInputField.CURRENT_VELOCITY) {
                            R.string.finite_value_error
                        } else {
                            R.string.positive_value_error
                        },
                    ),
                )
            }
        } else {
            null
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = spec.keyboardType,
            imeAction = imeAction,
        ),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        shape = RoundedCornerShape(14.dp),
    )
}

@Composable
private fun FixedInputStrip(
    input: SubmittedWaveInput,
    tabletLayout: Boolean,
    onEdit: () -> Unit,
    onShowTheory: () -> Unit,
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                TextButton(
                    onClick = onShowTheory,
                    modifier = Modifier
                        .weight(1f)
                        .semantics { contentDescription = "Open Fenton theory and formulas" },
                    contentPadding = PaddingValues(horizontal = 0.dp, vertical = 4.dp),
                ) {
                    Text(
                        text = "≈",
                        modifier = Modifier.padding(end = 8.dp),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = stringResource(R.string.fenton_theory),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                TextButton(
                    onClick = onEdit,
                    modifier = Modifier.semantics { contentDescription = "Edit wave inputs" },
                ) {
                    Text(
                        text = stringResource(R.string.edit_inputs),
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
            }

            val cells = listOf(
                "Wave height" to "${formatInput(input.waveHeight)} m",
                "Wave period" to "${formatInput(input.wavePeriod)} s",
                "Water depth" to "${formatInput(input.waterDepth)} m",
                "Current velocity" to "${formatInput(input.currentVelocity)} m/s",
            )
            if (tabletLayout) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    cells.forEach { (label, value) ->
                        FixedInputCell(label, value, Modifier.weight(1f))
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    cells.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { (label, value) ->
                                FixedInputCell(label, value, Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FixedInputCell(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(text = value, style = NumericValueTextStyle, maxLines = 1)
        }
    }
}

@Composable
private fun CurrentStatusCard(result: DashboardResult) {
    val statusHeadline = result.statusTitle
    val statusSubtitle = result.statusSubtitle
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .semantics {
                contentDescription =
                    "Solver status: ${result.statusTitle}. $statusHeadline. $statusSubtitle"
            },
        color = MaritimeNavy,
        contentColor = Color.White,
        shape = RoundedCornerShape(24.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Surface(
                modifier = Modifier.semantics { contentDescription = "Numerically verified wave solution" },
                shape = CircleShape,
                color = MaritimeBlue,
                contentColor = Color.White,
            ) {
                Text(
                    text = "≈",
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = statusHeadline,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = statusSubtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f),
                )
            }
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = MaritimeGreen,
                contentColor = Color.White,
            ) {
                Text(
                    text = "VERIFIED",
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun HydrodynamicHighlights(
    rows: List<HydrodynamicRow>,
    tabletLayout: Boolean,
    onInfo: (HydrodynamicRow) -> Unit,
) {
    val orderedRows = remember(rows) {
        rows.sortedBy { requireNotNull(it.highlightOrder) }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Engineering Highlights",
            modifier = Modifier.semantics { heading() },
            style = MaterialTheme.typography.titleSmall,
        )
        if (tabletLayout) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                orderedRows.chunked(4).forEach { group ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        group.forEach { row ->
                            HydrodynamicHighlightTile(
                                row = row,
                                onInfo = { onInfo(row) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        repeat(4 - group.size) { Spacer(modifier = Modifier.weight(1f)) }
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                orderedRows.forEach { row ->
                    HydrodynamicHighlightTile(
                        row = row,
                        onInfo = { onInfo(row) },
                        modifier = Modifier.width(236.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun HydrodynamicHighlightTile(
    row: HydrodynamicRow,
    onInfo: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val order = row.highlightOrder ?: 0
    val container = when (order % 3) {
        0 -> MaterialTheme.colorScheme.primaryContainer
        1 -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.tertiaryContainer
    }
    val content = when (order % 3) {
        0 -> MaterialTheme.colorScheme.onPrimaryContainer
        1 -> MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.onTertiaryContainer
    }
    Surface(
        modifier = modifier,
        color = container,
        contentColor = content,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, content.copy(alpha = 0.14f)),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    text = row.label,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.labelLarge,
                    minLines = 2,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                HydrodynamicInfoButton(row = row, onClick = onInfo, tint = content)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                HighlightComparisonValue(
                    label = "NO CURRENT",
                    value = row.noCurrentValue,
                    unit = row.unit,
                    modifier = Modifier.weight(1f),
                )
                HighlightComparisonValue(
                    label = "WITH CURRENT",
                    value = row.withCurrentValue ?: "—",
                    unit = row.unit,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun HighlightComparisonValue(
    label: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = unit,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun HydrodynamicColumnHeader(hasCurrent: Boolean) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, end = 8.dp, top = 9.dp, bottom = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = "PARAMETER",
                modifier = Modifier.weight(1.25f),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "NO CURRENT",
                modifier = Modifier.weight(0.9f),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                textAlign = TextAlign.End,
            )
            Text(
                text = "WITH CURRENT",
                modifier = Modifier.weight(0.9f),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(
                    alpha = if (hasCurrent) 1f else 0.55f,
                ),
                maxLines = 2,
                textAlign = TextAlign.End,
            )
            Spacer(modifier = Modifier.size(48.dp))
        }
    }
}

@Composable
private fun HydrodynamicSectionCard(
    section: HydrodynamicSection,
    hasCurrent: Boolean,
    onInfo: (HydrodynamicRow) -> Unit,
    modifier: Modifier = Modifier,
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
                    .semantics { heading() },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Surface(
                    modifier = Modifier.semantics {
                        contentDescription = hydrodynamicSectionMarkerDescription(section.title)
                    },
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ) {
                    Text(
                        text = hydrodynamicSectionMarker(section.title),
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Text(
                    text = section.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            section.rows.forEachIndexed { index, row ->
                HydrodynamicComparisonRow(
                    row = row,
                    hasCurrent = hasCurrent,
                    onInfo = { onInfo(row) },
                )
                if (index != section.rows.lastIndex) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f),
                    )
                }
            }
        }
    }
}

@Composable
private fun HydrodynamicComparisonRow(
    row: HydrodynamicRow,
    hasCurrent: Boolean,
    onInfo: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.Transparent,
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Column(modifier = Modifier.weight(1.25f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = row.label,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Normal,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = row.unit,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            HydrodynamicValue(
                value = row.noCurrentValue,
                modifier = Modifier.weight(0.9f),
            )
            HydrodynamicValue(
                value = row.withCurrentValue ?: "—",
                modifier = Modifier.weight(0.9f),
                muted = !hasCurrent,
            )
            HydrodynamicInfoButton(
                row = row,
                onClick = onInfo,
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun HydrodynamicValue(
    value: String,
    modifier: Modifier = Modifier,
    muted: Boolean = false,
) {
    Text(
        text = value,
        modifier = modifier,
        style = MaterialTheme.typography.bodySmall.copy(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
        ),
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (muted) 0.5f else 1f),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.End,
    )
}

@Composable
private fun HydrodynamicInfoButton(
    row: HydrodynamicRow,
    onClick: () -> Unit,
    tint: Color,
) {
    TextButton(
        onClick = onClick,
        modifier = Modifier
            .size(48.dp)
            .semantics { contentDescription = "More information about ${row.label}" },
        contentPadding = PaddingValues(0.dp),
    ) {
        Text(text = "ⓘ", color = tint, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AnimatedSection(
    animationKey: String,
    index: Int,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    var visible by remember(animationKey) { mutableStateOf(false) }
    LaunchedEffect(animationKey) {
        delay((index * 70L).milliseconds)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(animationSpec = tween(durationMillis = 320)) +
            slideInVertically(
                animationSpec = tween(durationMillis = 360),
                initialOffsetY = { it / 5 },
            ),
    ) {
        content()
    }
}

@Composable
private fun ErrorBanner(message: String) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = "Calculation error: $message" },
        color = MaterialTheme.colorScheme.errorContainer,
        contentColor = MaterialTheme.colorScheme.onErrorContainer,
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = stringResource(R.string.calculation_error),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
            Text(text = message, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FentonTheorySheet(onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.background,
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 1_080.dp)
                .align(Alignment.CenterHorizontally),
        ) {
            val tabletLayout = maxWidth >= 760.dp
            val horizontalPadding = if (tabletLayout) 28.dp else 16.dp
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 720.dp),
                contentPadding = PaddingValues(
                    start = horizontalPadding,
                    end = horizontalPadding,
                    bottom = 32.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item(key = "theory-header") {
                    FentonTheoryHeader()
                }

                if (tabletLayout) {
                    itemsIndexed(
                        items = fentonTheorySections.chunked(2),
                        key = { _, pair -> pair.joinToString(separator = "|") { it.title } },
                    ) { _, pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            pair.forEach { section ->
                                FentonTheorySectionCard(
                                    section = section,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                } else {
                    itemsIndexed(
                        items = fentonTheorySections,
                        key = { _, section -> section.title },
                    ) { _, section ->
                        FentonTheorySectionCard(section = section)
                    }
                }

                item(key = "theory-dismiss") {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .semantics { contentDescription = "Dismiss Fenton theory" },
                    ) {
                        Text(stringResource(R.string.dismiss))
                    }
                }
            }
        }
    }
}

@Composable
private fun FentonTheoryHeader() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaritimeNavy,
        contentColor = Color.White,
        shape = RoundedCornerShape(22.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                modifier = Modifier.semantics { contentDescription = "Nonlinear wave theory" },
                color = MaritimeBlue,
                contentColor = Color.White,
                shape = CircleShape,
            ) {
                Text(
                    text = "≈",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = "Fenton stream-function theory",
                    modifier = Modifier.semantics { heading() },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "Model, nonlinear equations, numerical method, and engineering limits",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f),
                )
            }
        }
    }
}

@Composable
private fun FentonTheorySectionCard(
    section: FentonTheorySection,
    modifier: Modifier = Modifier,
) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        SelectionContainer {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Surface(
                        shape = RoundedCornerShape(9.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ) {
                        Text(
                            text = section.marker,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Text(
                        text = section.title,
                        modifier = Modifier.semantics { heading() },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Text(
                    text = section.body.replace('\n', ' '),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (section.formulas.isNotEmpty()) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = section.formulasLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            section.formulas.forEach { formula ->
                                Text(
                                    text = formula,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HydrodynamicDetailsSheet(row: HydrodynamicRow, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp)
                .align(Alignment.CenterHorizontally)
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.parameter_details),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = row.label,
                    modifier = Modifier.semantics { heading() },
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(
                    text = row.definition,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                if (maxWidth >= 520.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        HydrodynamicDetailValue(
                            label = "NO CURRENT",
                            value = row.noCurrentValue,
                            unit = row.unit,
                            modifier = Modifier.weight(1f),
                        )
                        HydrodynamicDetailValue(
                            label = "WITH CURRENT",
                            value = row.withCurrentValue ?: "Not available",
                            unit = row.unit,
                            modifier = Modifier.weight(1f),
                            muted = row.withCurrentValue == null,
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        HydrodynamicDetailValue(
                            label = "NO CURRENT",
                            value = row.noCurrentValue,
                            unit = row.unit,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        HydrodynamicDetailValue(
                            label = "WITH CURRENT",
                            value = row.withCurrentValue ?: "Not available",
                            unit = row.unit,
                            modifier = Modifier.fillMaxWidth(),
                            muted = row.withCurrentValue == null,
                        )
                    }
                }
            }

            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { contentDescription = "Dismiss parameter details" },
            ) {
                Text(stringResource(R.string.dismiss))
            }
        }
    }
}

@Composable
private fun HydrodynamicDetailValue(
    label: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier,
    muted: Boolean = false,
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = value,
                style = NumericValueTextStyle,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (muted) 0.55f else 1f),
            )
            Text(
                text = "${stringResource(R.string.unit)}: ${unit.ifBlank { "dimensionless" }}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun hydrodynamicSectionMarker(title: String): String = when (title) {
    FentonDashboardMapper.HYDRO_DISPERSION_SECTION -> "≈"
    FentonDashboardMapper.HYDRO_MEAN_FLOWS_SECTION -> "↔"
    FentonDashboardMapper.HYDRO_FLUXES_SECTION -> "Q"
    FentonDashboardMapper.HYDRO_INTEGRALS_SECTION -> "∫"
    FentonDashboardMapper.HYDRO_KINEMATICS_SECTION -> "u"
    FentonDashboardMapper.HYDRO_NONLINEARITY_SECTION -> "!"
    else -> "•"
}

private fun hydrodynamicSectionMarkerDescription(title: String): String = when (title) {
    FentonDashboardMapper.HYDRO_DISPERSION_SECTION -> "Wave dispersion marker"
    FentonDashboardMapper.HYDRO_MEAN_FLOWS_SECTION -> "Mean flow marker"
    FentonDashboardMapper.HYDRO_FLUXES_SECTION -> "Flux and Bernoulli marker"
    FentonDashboardMapper.HYDRO_INTEGRALS_SECTION -> "Integral quantity marker"
    FentonDashboardMapper.HYDRO_KINEMATICS_SECTION -> "Kinematics marker"
    FentonDashboardMapper.HYDRO_NONLINEARITY_SECTION -> "Breaking diagnostic marker"
    else -> "Engineering section marker"
}

private data class FentonTheorySection(
    val marker: String,
    val title: String,
    val body: String,
    val formulas: List<String> = emptyList(),
    val formulasLabel: String = "PRINCIPAL FORMULAS",
)

private val fentonTheorySections = listOf(
    FentonTheorySection(
        marker = "01",
        title = "Physical model",
        body = """
            This calculator solves a steady, periodic, two-dimensional finite-depth gravity wave
            with an optional uniform current collinear with wave propagation. It uses a
            Rienecker–Fenton stream-function/Fourier collocation formulation, solving wavelength
            and the nonlinear free surface together from H, T, d, and the prescribed Eulerian
            current Uc. It evaluates a no-current reference and, when Uc is non-zero, a second
            current case. The fluid model is inviscid, incompressible, and irrotational, over a
            horizontal impermeable bed.
        """.trimIndent(),
    ),
    FentonTheorySection(
        marker = "02",
        title = "Coordinates and scaling",
        body = """
            The vertical coordinate z is measured upward from the bed: z = 0 at the bed and z = d
            at still-water level. X is the travelling phase and Y is the vertical coordinate in
            wave-number scaling. The crest is X = 0, the trough is X = π, and the free surface is
            Y = ζ(X) = kη(X). Velocities in the nonlinear state use √(g/k); reported velocities are
            converted to the depth scale √(gd). The requested Fourier order is N = 50. The solver
            reduces N when conditioning requires it; the state always contains 2N + 10 unknowns.
        """.trimIndent(),
        formulas = listOf(
            "k = 2π/L  ω = 2π/T  c = L/T = ω/k",
            "X = k(x − ct)  Y = k(z − d)",
            "z₁ = kd  z₂ = kH  z₃ = T√(gk)  z₄ = c√(k/g)",
            "z₅ = ū₁√(k/g) z₆ = ū₂√(k/g)  z₇ = Ū√(k/g)",
            "z₈ = q√(k³/g)  z₉ = (R − gd)k/g",
        ),
    ),
    FentonTheorySection(
        marker = "03",
        title = "Stream-function representation",
        body = """
            In dimensionless k–g scaling, the stream function is a uniform mean-flow term plus N
            Fourier modes. The hyperbolic basis satisfies bed impermeability by construction: at
            Y = −kd, the linear term and every Sj term vanish. Exponential ratios avoid cancellation
            between large hyperbolic terms. Differentiating Ψ gives the
            wave-frame horizontal and vertical velocity components U and V.
        """.trimIndent(),
        formulas = listOf(
            "Ψ(X,Y) = −z₇(Y + kd) + Σ[j=1…N] Bj Sj(Y) cos(jX)",
            "Sj(Y) = [exp(jY) − exp(−jY−2jkd)]/[1 + exp(−2jkd)]",
            "Cj(Y) = [exp(jY) + exp(−jY−2jkd)]/[1 + exp(−2jkd)]",
            "U = −z₇ + Σ jBj Cj(Y)cos(jX)",
            "V = Σ jBj Sj(Y)sin(jX)",
        ),
    ),
    FentonTheorySection(
        marker = "04",
        title = "Free-surface equations",
        body = """
            The symmetric half wave is collocated at Xm = mπ/N for m = 0…N. At every node the
            unknown surface is simultaneously a streamline and a zero-gauge-pressure Bernoulli
            surface, providing 2(N + 1) equations. Eight global equations impose the
            submitted height, apparent period, current convention, zero mean elevation, and
            crest-to-trough height, closing the (2N + 10)-unknown system.
        """.trimIndent(),
        formulas = listOf(
            "Σ Bj Sj(ζm)cos(jXm) − q* − Ū*ζm = 0  (q*=z₈, Ū*=z₇)",
            "½(Um² + Vm²) + ζm − r* = 0  (r*=z₉)",
            "z₂ − z₁(H/d) = 0",
            "z₂ − [H/(gT²)]z₃² = 0",
            "z₄z₃ − 2π = 0",
            "z₅ + z₇ − z₄ = 0",
            "z₁(z₆ + z₇ − z₄) − z₈ = 0",
            "z₅ − [Uc/√(gd)]√z₁ = 0",
            "z₁₀ + zN₊₁₀ + 2Σ[m=1…N−1]z₁₀₊m = 0",
            "z₁₀ − zN₊₁₀ − z₂ = 0",
        ),
    ),
    FentonTheorySection(
        marker = "05",
        title = "Current conventions",
        body = """
            The implementation prescribes the Eulerian current ū₁ = Uc. The reported Stokes
            current ū₂ is solved rather than prescribed. Ū is the mean fluid speed in the wave
            frame, Q is depth-integrated volume flux, and q is wave volume flux. The reduced
            Bernoulli constant removes the still-water hydrostatic contribution gd.
        """.trimIndent(),
        formulas = listOf(
            "ū₁ = c − Ū",
            "ū₂ = c − Q/d",
            "q = Ūd − Q = d(ū₂ − ū₁)",
            "r = R − gd  R/(gd) = 1 + z₉/(kd)",
        ),
    ),
    FentonTheorySection(
        marker = "06",
        title = "Nonlinear numerical solution",
        body = """
            Wave height is introduced by continuation: normally four height steps, increased to
            eight for |Uc/√(gd)| ≥ 1. Each step starts from a linear finite-depth seed or an
            extrapolation of accepted height steps. Newton's method uses an analytic Jacobian and a
            column-equilibrated SVD. Backtracking halves a trial step until kd remains positive
            and the squared residual does not increase. Failed height steps are retried with
            smaller increments. Fourier order is reduced when the equilibrated Jacobian
            condition exceeds 10¹¹. A small correction alone is not sufficient for acceptance.
        """.trimIndent(),
        formulas = listOf(
            "final correction tolerance = 10⁻¹⁰ |kd|",
            "intermediate tolerance = 10⁻⁸ |kd|",
            "final max|F| ≤ 10⁻¹⁰; intermediate max|F| ≤ 10⁻⁸",
            "SVD cutoff: σ ≤ 10⁻¹⁵ σmax is discarded",
            "interpolated-surface residual ≤ 10⁻⁶",
            "output error budget = 10⁻⁷ + 10⁻⁸ |reference|",
        ),
        formulasLabel = "TOLERANCES",
    ),
    FentonTheorySection(
        marker = "07",
        title = "Surface and kinematics",
        body = """
            After convergence, a half-wave cosine transform produces the free-surface
            coefficients. Point velocities use the same Sj and Cj basis; fixed-frame horizontal
            velocity adds the solved Eulerian current. Dimensional velocity uses √(gd), and
            horizontal material acceleration uses g. Absolute velocity and acceleration peaks are
            bracketed with max(257, 8N + 1) phases over 0 ≤ X ≤ π, then refined by golden-section
            search. Surface and bed horizontal acceleration maxima are reported separately.
        """.trimIndent(),
        formulas = listOf(
            "kη(X) = Σ[j=1…N−1] Yj cos(jX) + ½YN cos(NX)",
            "ax = −c ux + u ux + v uy",
        ),
    ),
    FentonTheorySection(
        marker = "08",
        title = "Integral outputs",
        body = """
            Kinetic energy, potential energy, total energy, radiation stress, impulse, and wave
            power are derived from converged Fourier invariants and dimensionalized with the
            appropriate depth scales. Momentum flux is integrated separately at the crest with
            1,200 trapezoidal samples. Mean-square orbital bed velocity removes the Eulerian current
            and is evaluated analytically by Fourier orthogonality. The Solution.res bed row
            includes the current squared, whereas the summary orbital value excludes it.
        """.trimIndent(),
        formulas = listOf(
            "energy-flux velocity = F/E",
            "β = ⟨ub,absolute²⟩ = ⟨ub,orbital²⟩ + ū₁²",
            "Sxx = 4T − 3V + ρβd − 2ū₁I",
            "F = c(3T − 2V) + ½β(I + ρcd) − 2cū₁I",
            "V* = ¼Σ[j=1…N−1]Yj² + YN²/16",
            "S/(ρgd²) = ∫₀^{z_s/d} {P + (u − c)²} dy",
            "P = R/(gd) − y − ½[(u − c)² + v²]  y = z/d",
            "z_s/d = 1 + ζ(X)/(kd)",
            "ub² = ⟨[ub(X) − Uc]²⟩  ub,rms = √ub²",
        ),
    ),
    FentonTheorySection(
        marker = "09",
        title = "Engineering diagnostics and limits",
        body = """
            Miche breaking, saturation, Ursell number, depth regime, bed shear, and bed excursion
            are post-processing diagnostics. They do not alter the nonlinear solution. The model
            does not represent viscous damping, surface tension, breaking evolution, variable
            bathymetry, three-dimensional effects, or a time-domain random sea state.
        """.trimIndent(),
        formulas = listOf(
            "Hmax = 0.142 L tanh(kd)  breaking if H > Hmax",
            "saturation = H/Hmax  Ursell = HL²/d³",
            "d/L < 0.05: shallow; < 0.5: intermediate; otherwise deep",
            "τb = ½ρ(0.005)(max|ub|)²",
            "bed excursion = max|ub − ū₁|T/(2π)",
        ),
    ),
    FentonTheorySection(
        marker = "10",
        title = "Numerical acceptance and verification scope",
        body = """
            Each converged state is checked on a denser surface grid and against spectral-bed
            identities. Independent pressure and velocity integrals use two periodic phase grids
            with 64- and 96-point Gauss–Legendre depth quadrature. Their refinement difference and
            their agreement with the reported invariants must fit the output error budget.
            A separate 50-digit outward-rounded interval evaluation checks every finite-system
            residual and nine output formulas. Failed cases are not presented as valid results.
            These are runtime numerical checks; they do not prove the existence of an exact
            water wave. The desktop Lean verification does not constitute a formal proof of
            this Kotlin/Android implementation.
        """.trimIndent(),
    ),
)

private fun formatInput(value: Double): String = String.format(Locale.US, "%.5f", value)
    .trimEnd('0')
    .trimEnd('.')

private fun shareReport(context: Context, report: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.share_subject))
        putExtra(Intent.EXTRA_TEXT, report)
    }
    context.startActivity(
        Intent.createChooser(intent, context.getString(R.string.share_chooser_title)),
    )
}

@Preview(showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun DashboardEditorPreview() {
    FentonTheme(dynamicColor = false) {
        FentonDashboardScreen(
            state = FentonDashboardUiState(),
            onIntent = {},
        )
    }
}
