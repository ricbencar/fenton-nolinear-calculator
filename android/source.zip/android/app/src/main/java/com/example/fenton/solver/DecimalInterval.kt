package com.example.fenton.solver

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.sqrt

/**
 * Outward-rounded decimal intervals. Binary64 inputs are interpreted exactly.
 * Android-compatible exp/sqrt enclosures avoid relying on libm error estimates.
 */
internal class DecimalInterval(val lo: BigDecimal, val hi: BigDecimal = lo) {
    constructor(value: Double) : this(BigDecimal(value))
    constructor(value: Int) : this(BigDecimal(value))

    init { require(lo <= hi) { "Invalid interval endpoints." } }

    operator fun plus(other: DecimalInterval) =
        DecimalInterval(lo.add(other.lo, DOWN), hi.add(other.hi, UP))
    operator fun unaryMinus() = DecimalInterval(hi.negate(), lo.negate())
    operator fun minus(other: DecimalInterval) = this + -other
    operator fun times(other: DecimalInterval): DecimalInterval {
        val pairs = listOf(lo to other.lo, lo to other.hi, hi to other.lo, hi to other.hi)
        return DecimalInterval(pairs.minOf { (a, b) -> a.multiply(b, DOWN) },
            pairs.maxOf { (a, b) -> a.multiply(b, UP) })
    }
    operator fun div(other: DecimalInterval): DecimalInterval {
        require(!(other.lo.signum() <= 0 && other.hi.signum() >= 0)) { "Interval division includes zero." }
        return this * DecimalInterval(BigDecimal.ONE.divide(other.hi, DOWN), BigDecimal.ONE.divide(other.lo, UP))
    }
    operator fun times(other: Int) = this * DecimalInterval(other)
    operator fun div(other: Int) = this / DecimalInterval(other)
    operator fun plus(other: Int) = this + DecimalInterval(other)
    fun minimumMagnitude(): BigDecimal =
        if (lo.signum() <= 0 && hi.signum() >= 0) BigDecimal.ZERO else minOf(lo.abs(), hi.abs())
    fun magnitude(): BigDecimal = maxOf(lo.abs(), hi.abs())
    fun square(): DecimalInterval {
        val minimum = minimumMagnitude()
        val maximum = magnitude()
        return DecimalInterval(minimum.multiply(minimum, DOWN), maximum.multiply(maximum, UP))
    }
    fun pow(exponent: Int): DecimalInterval {
        require(exponent >= 0)
        var answer = DecimalInterval(1)
        var base = this
        var power = exponent
        while (power > 0) {
            if (power % 2 == 1) answer *= base
            base = base.square()
            power /= 2
        }
        return answer
    }
    fun exp(): DecimalInterval {
        val lower = exponential(lo)
        val upper = if (lo == hi) lower else exponential(hi)
        return DecimalInterval(lower.lo, upper.hi)
    }
    fun sqrt(): DecimalInterval {
        require(lo.signum() >= 0) { "Negative square-root interval." }
        return DecimalInterval(squareRoot(lo).lo, squareRoot(hi).hi)
    }

    companion object {
        val DOWN = MathContext(50, RoundingMode.FLOOR)
        val UP = MathContext(50, RoundingMode.CEILING)
        private val WORK = MathContext(64, RoundingMode.HALF_EVEN)
        val PI = DecimalInterval(BigDecimal("3.14159265358979323846"), BigDecimal("3.14159265358979323847"))

        private fun squareRoot(x: BigDecimal): DecimalInterval {
            if (x.signum() == 0) return DecimalInterval(0)
            var root = BigDecimal(sqrt(x.toDouble()))
            require(root.signum() > 0) { "Square root outside the supported numerical range." }
            repeat(16) { root = root.add(x.divide(root, WORK), WORK).divide(BigDecimal(2), WORK) }
            val roundedLo = root.round(DOWN)
            val roundedHi = root.round(UP)
            val lower = maxOf(BigDecimal.ZERO, roundedLo.subtract(roundedLo.ulp()))
            val upper = roundedHi.add(roundedHi.ulp())
            // An exact algebraic check certifies the bracket independently of Newton convergence.
            check(lower.multiply(lower) <= x && upper.multiply(upper) >= x)
            return DecimalInterval(lower, upper)
        }

        private fun exponential(x: BigDecimal): DecimalInterval {
            if (x.signum() == 0) return DecimalInterval(1)
            if (x.signum() < 0) return DecimalInterval(1) / exponential(x.negate())
            require(x < BigDecimal("100000")) { "Exponential argument outside the supported range." }
            var reduced = x
            var squarings = 0
            while (reduced > BigDecimal("0.125")) {
                reduced = reduced.divide(BigDecimal(2)) // exact decimal division
                squarings++
            }
            val argument = DecimalInterval(reduced)
            var term = DecimalInterval(1)
            var sum = term
            var index = 0
            do {
                index++
                term = term * argument / index
                sum += term
            } while (term.hi > BigDecimal("1e-60"))
            // Positive Taylor tail is bounded by a geometric series.
            val next = term * argument / (index + 1)
            val tail = next / (DecimalInterval(1) - argument / (index + 2))
            var result = DecimalInterval(sum.lo, sum.hi.add(tail.hi, UP))
            repeat(squarings) { result = result.square() }
            return result
        }
    }
}

internal operator fun Int.times(other: DecimalInterval) = other * this

