package com.example.fenton.solver

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/** Dense linear algebra used by the Newton iteration, with no Android dependency. */
internal object LinearAlgebra {
    private const val SINGULAR_VALUE_CUTOFF = 1.0e-12

    /**
     * Solves A x = b. A is a row-major square matrix.
     *
     * A rank-revealing Householder QR with column pivoting is used on the usual
     * full-rank path. Its answer is checked against the original system. If the
     * decomposition is rank deficient or the check is poor, a one-sided Jacobi
     * SVD computes the same 1e-12 truncated pseudoinverse used by the Python
     * reference implementation.
     */
    fun solve(a: DoubleArray, b: DoubleArray, size: Int): DoubleArray {
        require(size > 0) { "Matrix size must be positive." }
        require(a.size == size * size) { "Expected a $size x $size matrix." }
        require(b.size == size) { "Expected a right-hand side of length $size." }
        if (!a.all(Double::isFinite) || !b.all(Double::isFinite)) {
            throw ArithmeticException("Non-finite values in Jacobian system.")
        }

        val qr = qrWithColumnPivoting(a, b, size)
        if (qr != null && qr.all(Double::isFinite) && residualIsAcceptable(a, b, qr, size)) {
            return qr
        }

        val svd = oneSidedJacobiPseudoInverse(a, b, size)
        if (!svd.all(Double::isFinite)) {
            throw ArithmeticException("The Jacobian pseudoinverse produced non-finite values.")
        }
        return svd
    }

    private fun qrWithColumnPivoting(
        source: DoubleArray,
        sourceRhs: DoubleArray,
        n: Int,
    ): DoubleArray? {
        val a = source.copyOf()
        val rhs = sourceRhs.copyOf()
        val permutation = IntArray(n) { it }
        var rank = n
        var leadingDiagonal = 0.0

        for (k in 0 until n) {
            var pivot = k
            var pivotNormSquared = -1.0
            for (column in k until n) {
                var normSquared = 0.0
                for (row in k until n) {
                    val value = a[row * n + column]
                    normSquared += value * value
                }
                if (normSquared > pivotNormSquared) {
                    pivotNormSquared = normSquared
                    pivot = column
                }
            }

            val pivotNorm = sqrt(max(0.0, pivotNormSquared))
            if (k == 0) leadingDiagonal = pivotNorm
            if (
                !pivotNorm.isFinite() ||
                pivotNorm == 0.0 ||
                (leadingDiagonal > 0.0 && pivotNorm <= leadingDiagonal * SINGULAR_VALUE_CUTOFF)
            ) {
                rank = k
                break
            }

            if (pivot != k) {
                for (row in 0 until n) {
                    val left = row * n + k
                    val right = row * n + pivot
                    val temporary = a[left]
                    a[left] = a[right]
                    a[right] = temporary
                }
                val p = permutation[k]
                permutation[k] = permutation[pivot]
                permutation[pivot] = p
            }

            val diagonalIndex = k * n + k
            val originalDiagonal = a[diagonalIndex]
            var tailNorm = 0.0
            for (row in k + 1 until n) {
                tailNorm = hypot(tailNorm, a[row * n + k])
            }
            val columnNorm = hypot(originalDiagonal, tailNorm)
            if (columnNorm == 0.0 || !columnNorm.isFinite()) {
                rank = k
                break
            }

            val beta = if (originalDiagonal >= 0.0) -columnNorm else columnNorm
            val denominator = originalDiagonal - beta
            if (denominator == 0.0 || !denominator.isFinite()) return null
            val tau = (beta - originalDiagonal) / beta

            a[diagonalIndex] = beta
            for (row in k + 1 until n) {
                a[row * n + k] /= denominator
            }

            for (column in k + 1 until n) {
                var projection = a[k * n + column]
                for (row in k + 1 until n) {
                    projection += a[row * n + k] * a[row * n + column]
                }
                projection *= tau
                a[k * n + column] -= projection
                for (row in k + 1 until n) {
                    a[row * n + column] -= a[row * n + k] * projection
                }
            }

            var rhsProjection = rhs[k]
            for (row in k + 1 until n) rhsProjection += a[row * n + k] * rhs[row]
            rhsProjection *= tau
            rhs[k] -= rhsProjection
            for (row in k + 1 until n) rhs[row] -= a[row * n + k] * rhsProjection
        }

        // A truncated QR solution is useful, but the Jacobi pseudoinverse gives
        // closer parity when a numerical rank loss is actually observed.
        if (rank < n) return null

        val pivoted = DoubleArray(n)
        for (row in rank - 1 downTo 0) {
            var value = rhs[row]
            for (column in row + 1 until rank) {
                value -= a[row * n + column] * pivoted[column]
            }
            val diagonal = a[row * n + row]
            if (diagonal == 0.0 || !diagonal.isFinite()) return null
            pivoted[row] = value / diagonal
        }

        val answer = DoubleArray(n)
        for (column in 0 until n) answer[permutation[column]] = pivoted[column]
        return answer
    }

    private fun residualIsAcceptable(
        a: DoubleArray,
        b: DoubleArray,
        x: DoubleArray,
        n: Int,
    ): Boolean {
        var residualSquared = 0.0
        var rhsSquared = 0.0
        for (row in 0 until n) {
            var value = -b[row]
            val offset = row * n
            for (column in 0 until n) value += a[offset + column] * x[column]
            residualSquared += value * value
            rhsSquared += b[row] * b[row]
        }
        val scale = max(1.0, sqrt(rhsSquared))
        return sqrt(residualSquared) <= 1.0e-7 * scale
    }

    /** Golub-Reinsch-style result via cyclic one-sided Jacobi column rotations. */
    private fun oneSidedJacobiPseudoInverse(
        source: DoubleArray,
        rhs: DoubleArray,
        n: Int,
    ): DoubleArray {
        val work = source.copyOf()
        val rightVectors = DoubleArray(n * n)
        for (i in 0 until n) rightVectors[i * n + i] = 1.0

        val orthogonalityTolerance = 2.0e-14
        val maximumSweeps = 80
        sweepLoop@ for (sweep in 0 until maximumSweeps) {
            var rotations = 0
            for (p in 0 until n - 1) {
                for (q in p + 1 until n) {
                    var alpha = 0.0
                    var beta = 0.0
                    var gamma = 0.0
                    for (row in 0 until n) {
                        val left = work[row * n + p]
                        val right = work[row * n + q]
                        alpha += left * left
                        beta += right * right
                        gamma += left * right
                    }
                    if (alpha == 0.0 || beta == 0.0) continue
                    if (abs(gamma) <= orthogonalityTolerance * sqrt(alpha * beta)) continue

                    val zeta = (beta - alpha) / (2.0 * gamma)
                    val tangent = if (zeta >= 0.0) {
                        1.0 / (zeta + sqrt(1.0 + zeta * zeta))
                    } else {
                        -1.0 / (-zeta + sqrt(1.0 + zeta * zeta))
                    }
                    val cosine = 1.0 / sqrt(1.0 + tangent * tangent)
                    val sine = cosine * tangent

                    for (row in 0 until n) {
                        val pIndex = row * n + p
                        val qIndex = row * n + q
                        val left = work[pIndex]
                        val right = work[qIndex]
                        work[pIndex] = cosine * left - sine * right
                        work[qIndex] = sine * left + cosine * right

                        val vectorLeft = rightVectors[pIndex]
                        val vectorRight = rightVectors[qIndex]
                        rightVectors[pIndex] = cosine * vectorLeft - sine * vectorRight
                        rightVectors[qIndex] = sine * vectorLeft + cosine * vectorRight
                    }
                    rotations++
                }
            }
            if (rotations == 0) break@sweepLoop
        }

        val singularValues = DoubleArray(n)
        var largest = 0.0
        for (column in 0 until n) {
            var norm = 0.0
            for (row in 0 until n) norm = hypot(norm, work[row * n + column])
            singularValues[column] = norm
            largest = max(largest, norm)
        }
        if (largest == 0.0 || !largest.isFinite()) {
            throw ArithmeticException("The Jacobian has no usable singular values.")
        }

        val cutoff = largest * SINGULAR_VALUE_CUTOFF
        val answer = DoubleArray(n)
        for (component in 0 until n) {
            val singular = singularValues[component]
            if (singular <= cutoff) continue
            var projection = 0.0
            for (row in 0 until n) projection += work[row * n + component] * rhs[row]
            val coefficient = projection / (singular * singular)
            for (row in 0 until n) {
                answer[row] += rightVectors[row * n + component] * coefficient
            }
        }
        return answer
    }
}
