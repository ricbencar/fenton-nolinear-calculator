package com.example.fenton.solver

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/** Dense linear algebra used by the Newton iteration, with no Android dependency. */
internal object LinearAlgebra {
    private const val SINGULAR_VALUE_CUTOFF = 1.0e-15

    data class Solution(val correction: DoubleArray, val condition: Double)

    /** Column-equilibrated SVD, with the same relative truncation as NumPy. */
    fun solve(a: DoubleArray, b: DoubleArray, size: Int): Solution {
        require(size > 0 && a.size == size * size && b.size == size)
        if (!a.all(Double::isFinite) || !b.all(Double::isFinite)) {
            throw ArithmeticException("Non-finite values in Jacobian system.")
        }
        val scales = DoubleArray(size) { column ->
            (0 until size).maxOf { row -> abs(a[row * size + column]) }
                .takeIf { it > 0.0 } ?: 1.0
        }
        val scaled = DoubleArray(a.size) { index -> a[index] / scales[index % size] }
        val result = oneSidedJacobiPseudoInverse(scaled, b, size)
        for (i in 0 until size) result.correction[i] /= scales[i]
        if (!result.correction.all(Double::isFinite)) {
            throw ArithmeticException("Non-finite Jacobian correction.")
        }
        return result
    }

    /** Golub-Reinsch-style result via cyclic one-sided Jacobi column rotations. */
    private fun oneSidedJacobiPseudoInverse(
        source: DoubleArray,
        rhs: DoubleArray,
        n: Int,
    ): Solution {
        val work = source.copyOf()
        val rightVectors = DoubleArray(n * n)
        for (i in 0 until n) rightVectors[i * n + i] = 1.0

        val orthogonalityTolerance = 2.0e-15
        val maximumSweeps = 100
        var converged = false
        sweepLoop@ for (sweep in 0 until maximumSweeps) {
            var rotations = 0
            for (p in 0 until n - 1) {
                for (q in p + 1 until n) {
                    var alpha = 0.0
                    var beta = 0.0
                    var gamma = 0.0
                    for (row in 0 until n) {
                        val left = work[row * n + p]
                        val right = work[row * n + q]
                        alpha += left * left
                        beta += right * right
                        gamma += left * right
                    }
                    if (alpha == 0.0 || beta == 0.0) continue
                    if (abs(gamma) <= orthogonalityTolerance * sqrt(alpha * beta)) continue

                    val zeta = (beta - alpha) / (2.0 * gamma)
                    val tangent = if (zeta >= 0.0) {
                        1.0 / (zeta + sqrt(1.0 + zeta * zeta))
                    } else {
                        -1.0 / (-zeta + sqrt(1.0 + zeta * zeta))
                    }
                    val cosine = 1.0 / sqrt(1.0 + tangent * tangent)
                    val sine = cosine * tangent

                    for (row in 0 until n) {
                        val pIndex = row * n + p
                        val qIndex = row * n + q
                        val left = work[pIndex]
                        val right = work[qIndex]
                        work[pIndex] = cosine * left - sine * right
                        work[qIndex] = sine * left + cosine * right

                        val vectorLeft = rightVectors[pIndex]
                        val vectorRight = rightVectors[qIndex]
                        rightVectors[pIndex] = cosine * vectorLeft - sine * vectorRight
                        rightVectors[qIndex] = sine * vectorLeft + cosine * vectorRight
                    }
                    rotations++
                }
            }
            if (rotations == 0) {
                converged = true
                break@sweepLoop
            }
        }

        if (!converged) throw ArithmeticException("Jacobi SVD did not converge.")

        val singularValues = DoubleArray(n)
        var largest = 0.0
        for (column in 0 until n) {
            var norm = 0.0
            for (row in 0 until n) norm = hypot(norm, work[row * n + column])
            singularValues[column] = norm
            largest = max(largest, norm)
        }
        if (largest == 0.0 || !largest.isFinite()) {
            throw ArithmeticException("The Jacobian has no usable singular values.")
        }

        val cutoff = largest * SINGULAR_VALUE_CUTOFF
        val answer = DoubleArray(n)
        for (component in 0 until n) {
            val singular = singularValues[component]
            if (singular <= cutoff) continue
            var projection = 0.0
            for (row in 0 until n) projection += work[row * n + component] * rhs[row]
            val coefficient = projection / (singular * singular)
            for (row in 0 until n) {
                answer[row] += rightVectors[row * n + component] * coefficient
            }
        }
        val smallest = singularValues.minOrNull() ?: 0.0
        val condition = if (smallest > largest * 1.0e-300) largest / smallest
        else Double.POSITIVE_INFINITY
        return Solution(answer, condition)
    }
}
