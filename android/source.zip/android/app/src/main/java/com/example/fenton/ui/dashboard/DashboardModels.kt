package com.example.fenton.ui.dashboard

/** The two solution views available in the nonlinear-wave dashboard. */
enum class DashboardMode {
    NO_CURRENT,
    WITH_CURRENT,
}

/** Visual intent carried by a metric without depending on Compose or Android. */
enum class DashboardEmphasis {
    DEFAULT,
    PRIMARY,
    ACCENT,
    BED,
}

/** Input values as submitted for the calculation represented by a dashboard. */
data class SubmittedWaveInput(
    val waveHeight: Double,
    val wavePeriod: Double,
    val waterDepth: Double,
    val currentVelocity: Double,
)

/** One of the 19 canonical Solution.res quantities. */
data class DashboardMetric(
    val id: Int,
    val label: String,
    val physicalValue: String,
    val physicalUnit: String,
    val dimensionlessFormula: String,
    val dimensionlessValue: String,
    val definition: String,
    val emphasis: DashboardEmphasis = DashboardEmphasis.DEFAULT,
)

/** A named group of related Solution.res quantities. */
data class DashboardSection(
    val title: String,
    val items: List<DashboardMetric>,
)

/** Dashboard-ready representation of one converged current convention. */
data class DashboardSolution(
    val mode: DashboardMode,
    val title: String,
    val sections: List<DashboardSection>,
) {
    val items: List<DashboardMetric>
        get() = sections.flatMap(DashboardSection::items)
}

/**
 * Stable identifiers for calculated hydrodynamic values.
 *
 * Most identifiers map to the 35 rows in the comparison table. [HEIGHT_TO_DEPTH] and
 * [DIMENSIONLESS_PERIOD] are reference-scale values shown only in Engineering Highlights.
 */
enum class HydrodynamicParameterId {
    WAVELENGTH,
    WAVE_NUMBER,
    HEIGHT_TO_DEPTH,
    DIMENSIONLESS_PERIOD,
    KD,
    ANGULAR_FREQUENCY,
    CELERITY,
    DIMENSIONLESS_CELERITY,
    CREST_ELEVATION,
    TROUGH_ELEVATION,
    EULERIAN_CURRENT,
    STOKES_CURRENT,
    MEAN_FLUID_SPEED,
    WAVE_VOLUME_FLUX,
    VOLUME_FLUX,
    BERNOULLI_CONSTANT,
    REDUCED_BERNOULLI,
    KINETIC_ENERGY,
    POTENTIAL_ENERGY,
    TOTAL_ENERGY,
    MOMENTUM_FLUX,
    RADIATION_STRESS,
    IMPULSE,
    WAVE_POWER,
    GROUP_VELOCITY,
    MAX_SURFACE_HORIZONTAL_VELOCITY,
    MAX_BED_HORIZONTAL_VELOCITY,
    MAX_HORIZONTAL_ACCELERATION,
    MAX_BED_HORIZONTAL_ACCELERATION,
    VELOCITY_ASYMMETRY,
    MEAN_SQUARE_BED_ORBITAL_VELOCITY,
    BED_ORBITAL_RMS_VELOCITY,
    MICHE_BREAKING_LIMIT,
    SATURATION,
    BREAKING_STATUS,
    URSELL_NUMBER,
    DEPTH_REGIME,
}

/**
 * One value row comparing the no-current and requested-current solutions.
 *
 * Rows may belong to the full hydrodynamic table, Engineering Highlights, or both.
 */
data class HydrodynamicRow(
    val id: HydrodynamicParameterId,
    val label: String,
    val noCurrentValue: String,
    val withCurrentValue: String?,
    val unit: String,
    val definition: String,
    val isHighlight: Boolean = false,
    val highlightOrder: Int? = null,
)

/** A section in the calculated hydrodynamic parameter sequence. */
data class HydrodynamicSection(
    val title: String,
    val rows: List<HydrodynamicRow>,
)

/** Complete dashboard state derived from the solver's two-case result. */
data class DashboardResult(
    val submittedInput: SubmittedWaveInput,
    val noCurrent: DashboardSolution?,
    val withCurrent: DashboardSolution?,
    val hasCurrent: Boolean,
    val statusTitle: String,
    val statusSubtitle: String,
    val hydrodynamicSections: List<HydrodynamicSection>,
    /** Canonically ordered summary rows, including reference-scale highlights omitted from the table. */
    val highlights: List<HydrodynamicRow>,
) {
    val hydrodynamicParameters: List<HydrodynamicRow>
        get() = hydrodynamicSections.flatMap(HydrodynamicSection::rows)

    val availableModes: List<DashboardMode>
        get() = listOfNotNull(
            noCurrent?.let { DashboardMode.NO_CURRENT },
            withCurrent?.let { DashboardMode.WITH_CURRENT },
        )

    fun solution(mode: DashboardMode): DashboardSolution? = when (mode) {
        DashboardMode.NO_CURRENT -> noCurrent
        DashboardMode.WITH_CURRENT -> withCurrent
    }
}
