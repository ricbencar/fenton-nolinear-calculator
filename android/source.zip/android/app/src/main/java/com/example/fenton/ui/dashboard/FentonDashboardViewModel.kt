package com.example.fenton.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fenton.report.FentonReportFormatter
import com.example.fenton.solver.FentonCalculation
import com.example.fenton.solver.FentonCalculator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible

enum class DashboardInputField {
    WAVE_HEIGHT,
    WAVE_PERIOD,
    WATER_DEPTH,
    CURRENT_VELOCITY,
}

sealed interface DashboardIntent {
    data class InputChanged(val field: DashboardInputField, val value: String) : DashboardIntent
    data object Calculate : DashboardIntent
    data object EditInputs : DashboardIntent
    data class SelectMode(val mode: DashboardMode) : DashboardIntent
    data class ShowMetricDetails(val metric: DashboardMetric) : DashboardIntent
    data object DismissMetricDetails : DashboardIntent
}

data class FentonDashboardUiState(
    val waveHeight: String = "3.0",
    val wavePeriod: String = "9.0",
    val waterDepth: String = "5.0",
    val currentVelocity: String = "1.0",
    val invalidFields: Set<DashboardInputField> = emptySet(),
    val isCalculating: Boolean = false,
    val errorMessage: String? = null,
    val result: DashboardResult? = null,
    val report: String? = null,
    val selectedMode: DashboardMode = DashboardMode.WITH_CURRENT,
    val selectedMetric: DashboardMetric? = null,
) {
    val isEditing: Boolean get() = result == null

    val selectedSolution: DashboardSolution?
        get() = result?.solution(selectedMode) ?: result?.noCurrent ?: result?.withCurrent
}

internal typealias DashboardCalculation = (SubmittedWaveInput) -> FentonCalculation
internal typealias DashboardMapping = (FentonCalculation) -> DashboardResult
internal typealias DashboardReportFormatting = (FentonCalculation) -> String

class FentonDashboardViewModel(
    private val calculate: DashboardCalculation = { input ->
        FentonCalculator.calculate(
            waveHeight = input.waveHeight,
            wavePeriod = input.wavePeriod,
            waterDepth = input.waterDepth,
            currentVelocity = input.currentVelocity,
        )
    },
    private val mapDashboard: DashboardMapping = FentonDashboardMapper::map,
    private val formatReport: DashboardReportFormatting = FentonReportFormatter::format,
    private val calculationDispatcher: CoroutineDispatcher = Dispatchers.Default,
) : ViewModel() {

    private val mutableUiState = MutableStateFlow(FentonDashboardUiState())
    val uiState: StateFlow<FentonDashboardUiState> = mutableUiState.asStateFlow()

    private var calculationJob: Job? = null

    fun onIntent(intent: DashboardIntent) {
        when (intent) {
            is DashboardIntent.InputChanged -> updateInput(intent.field, intent.value)
            DashboardIntent.Calculate -> calculate()
            DashboardIntent.EditInputs -> editInputs()
            is DashboardIntent.SelectMode -> selectMode(intent.mode)
            is DashboardIntent.ShowMetricDetails -> {
                mutableUiState.value = mutableUiState.value.copy(selectedMetric = intent.metric)
            }
            DashboardIntent.DismissMetricDetails -> {
                mutableUiState.value = mutableUiState.value.copy(selectedMetric = null)
            }
        }
    }

    private fun updateInput(field: DashboardInputField, value: String) {
        val state = mutableUiState.value
        val remainingInvalidFields = state.invalidFields - field
        mutableUiState.value = when (field) {
            DashboardInputField.WAVE_HEIGHT -> state.copy(
                waveHeight = value,
                invalidFields = remainingInvalidFields,
                errorMessage = null,
            )
            DashboardInputField.WAVE_PERIOD -> state.copy(
                wavePeriod = value,
                invalidFields = remainingInvalidFields,
                errorMessage = null,
            )
            DashboardInputField.WATER_DEPTH -> state.copy(
                waterDepth = value,
                invalidFields = remainingInvalidFields,
                errorMessage = null,
            )
            DashboardInputField.CURRENT_VELOCITY -> state.copy(
                currentVelocity = value,
                invalidFields = remainingInvalidFields,
                errorMessage = null,
            )
        }
    }

    private fun calculate() {
        if (mutableUiState.value.isCalculating) return

        val state = mutableUiState.value
        val validation = validateDashboardInputs(
            height = state.waveHeight,
            period = state.wavePeriod,
            depth = state.waterDepth,
            current = state.currentVelocity,
        )
        if (validation.input == null) {
            mutableUiState.value = state.copy(
                invalidFields = validation.invalidFields,
                errorMessage = "Enter finite values. Wave height, period, and water depth must be greater than zero.",
            )
            return
        }

        val submittedInput = validation.input
        mutableUiState.value = state.copy(
            isCalculating = true,
            invalidFields = emptySet(),
            errorMessage = null,
            selectedMetric = null,
        )

        calculationJob = viewModelScope.launch {
            try {
                val payload = runInterruptible(calculationDispatcher) {
                    val calculation = calculate(submittedInput)
                    CalculationPayload(
                        dashboard = mapDashboard(calculation),
                        report = formatReport(calculation),
                    )
                }
                val preferredMode = if (payload.dashboard.withCurrent != null) {
                    DashboardMode.WITH_CURRENT
                } else {
                    DashboardMode.NO_CURRENT
                }
                mutableUiState.value = mutableUiState.value.copy(
                    isCalculating = false,
                    result = payload.dashboard,
                    report = payload.report,
                    selectedMode = preferredMode,
                    errorMessage = null,
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (exception: Exception) {
                mutableUiState.value = mutableUiState.value.copy(
                    isCalculating = false,
                    errorMessage = exception.message
                        ?.takeIf(String::isNotBlank)
                        ?: "The nonlinear solver could not complete this calculation.",
                )
            }
        }
    }

    private fun editInputs() {
        calculationJob?.cancel()
        mutableUiState.value = mutableUiState.value.copy(
            isCalculating = false,
            result = null,
            report = null,
            selectedMetric = null,
            errorMessage = null,
        )
    }

    private fun selectMode(mode: DashboardMode) {
        val state = mutableUiState.value
        if (state.result?.solution(mode) == null) return
        mutableUiState.value = state.copy(selectedMode = mode, selectedMetric = null)
    }

    private data class CalculationPayload(
        val dashboard: DashboardResult,
        val report: String,
    )
}

internal data class DashboardInputValidation(
    val input: SubmittedWaveInput?,
    val invalidFields: Set<DashboardInputField>,
)

internal fun validateDashboardInputs(
    height: String,
    period: String,
    depth: String,
    current: String,
): DashboardInputValidation {
    val parsedHeight = parseDashboardDecimal(height)
    val parsedPeriod = parseDashboardDecimal(period)
    val parsedDepth = parseDashboardDecimal(depth)
    val parsedCurrent = parseDashboardDecimal(current)

    val invalidFields = buildSet {
        if (parsedHeight == null || parsedHeight <= 0.0) add(DashboardInputField.WAVE_HEIGHT)
        if (parsedPeriod == null || parsedPeriod <= 0.0) add(DashboardInputField.WAVE_PERIOD)
        if (parsedDepth == null || parsedDepth <= 0.0) add(DashboardInputField.WATER_DEPTH)
        if (parsedCurrent == null) add(DashboardInputField.CURRENT_VELOCITY)
    }

    val input = if (invalidFields.isEmpty()) {
        SubmittedWaveInput(
            waveHeight = requireNotNull(parsedHeight),
            wavePeriod = requireNotNull(parsedPeriod),
            waterDepth = requireNotNull(parsedDepth),
            currentVelocity = requireNotNull(parsedCurrent),
        )
    } else {
        null
    }
    return DashboardInputValidation(input = input, invalidFields = invalidFields)
}

internal fun parseDashboardDecimal(raw: String): Double? = raw
    .trim()
    .replace(',', '.')
    .toDoubleOrNull()
    ?.takeIf(Double::isFinite)
