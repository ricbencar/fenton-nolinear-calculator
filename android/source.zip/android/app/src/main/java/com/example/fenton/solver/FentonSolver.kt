package com.example.fenton.solver

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/** Entry point mirroring the two-case calculation performed by fenton_gui.py. */
object FentonCalculator {
    @JvmStatic
    fun calculate(
        waveHeight: Double,
        wavePeriod: Double,
        waterDepth: Double,
        currentVelocity: Double,
        verificationLevel: VerificationLevel = VerificationLevel.FAST,
    ): FentonCalculation {
        val input = WaveInput(waveHeight, wavePeriod, waterDepth, currentVelocity)
        fun attempt(value: WaveInput): Pair<WaveSolution?, String?> {
            return try {
                FentonSolver(value, verificationLevel = verificationLevel).solve() to null
            } catch (failure: InvalidWaveInputException) {
                throw failure
            } catch (failure: FentonSolverException) {
                null to failure.message
            }
        }
        val (noCurrent, noCurrentFailure) = attempt(input.copy(currentVelocity = 0.0))
        val (withCurrent, withCurrentFailure) = if (currentVelocity == 0.0) noCurrent to null else attempt(input)
        if (noCurrent == null && withCurrent == null) {
            throw FentonConvergenceException(listOfNotNull(
                noCurrentFailure?.let { "[No current] $it" },
                withCurrentFailure?.let { "[With current] $it" },
            ).joinToString("\n"))
        }
        return FentonCalculation(noCurrent, withCurrent, input, noCurrentFailure, withCurrentFailure)
    }
}

/**
 * Rienecker-Fenton stream-function/Fourier collocation solver.
 *
 * The implementation intentionally retains the reference program's one-based
 * state vector and continuation/Newton details. It is pure Kotlin/JVM and does
 * not depend on Android, Compose, native BLAS, or third-party math libraries.
 */
class FentonSolver(
    private val input: WaveInput,
    private val requestedOrder: Int = FOURIER_ORDER,
    private val currentCriterion: Int = 1,
    private val verificationLevel: VerificationLevel = VerificationLevel.FAST,
) {
    companion object {
        const val GRAVITY = 9.80665
        const val SEA_WATER_DENSITY = 1025.0
        const val FOURIER_ORDER = 50

        private const val INTERMEDIATE_TOLERANCE = 1.0e-8
        private const val FINAL_TOLERANCE = 1.0e-10
        private const val DEFAULT_CONTINUATION_STEPS = 4
        private const val DEFAULT_NEWTON_ITERATIONS = 40
    }

    constructor(
        waveHeight: Double,
        wavePeriod: Double,
        waterDepth: Double,
        currentVelocity: Double = 0.0,
    ) : this(WaveInput(waveHeight, wavePeriod, waterDepth, currentVelocity))

    private var n = requestedOrder
    private val numberOfUnknowns get() = 2 * n + 10

    // Index zero is unused, matching the desktop's Fenton state vector.
    private var z = DoubleArray(numberOfUnknowns + 1)
    private var firstResidual = DoubleArray(numberOfUnknowns + 1)
    private var secondResidual = DoubleArray(numberOfUnknowns + 1)
    private var streamFunctionCoefficients = DoubleArray(n + 1)
    private var surfaceCoefficients = DoubleArray(n + 1)
    private var cosineTable = DoubleArray(2 * n) { cos(it * PI / n) }
    private var sineTable = DoubleArray(2 * n) { sin(it * PI / n) }
    private var condition = 0.0
    private var residualMax = Double.POSITIVE_INFINITY

    private val maximumHeightToDepth = input.waveHeight / input.waterDepth
    private val nondimensionalPeriod = input.wavePeriod * sqrt(GRAVITY / input.waterDepth)
    private val targetHeightParameter = maximumHeightToDepth / nondimensionalPeriod.pow(2)
    private val nondimensionalCurrent = input.currentVelocity / sqrt(GRAVITY * input.waterDepth)
    private var steppedHeightParameter = 0.0
    private var steppedHeightToDepth = 0.0

    init {
        validateInput(input)
        require(requestedOrder >= 2) { "Fourier order must be at least two." }
        require(currentCriterion in 1..2) { "Current criterion must be 1 (Eulerian) or 2 (Stokes)." }
    }

    fun solve(): WaveSolution {
        while (true) {
            checkInterrupted()
            var solution: WaveSolution? = null
            var error: ArithmeticException? = null
            try {
                solveAtOrder()
                solution = buildSolution()
                evaluateResidual(firstResidual)
                residualMax = firstResidual.drop(1).maxOf { abs(it) }
                if (residualMax > FINAL_TOLERANCE) {
                    throw ArithmeticException("Post-processing residual exceeds 1e-10.")
                }
                condition = LinearAlgebra.solve(
                    jacobian(), DoubleArray(numberOfUnknowns), numberOfUnknowns,
                ).condition
            } catch (failure: ArithmeticException) {
                error = failure
            }
            if (condition > 1.0e11 && n > 12) {
                resetOrder(max(12, (n * 0.8).toInt()))
                continue
            }
            val note = if (n != requestedOrder) {
                "Fourier order used: $n (requested $requestedOrder); limited by numerical conditioning."
            } else ""
            if (error != null || solution == null || condition > 1.0e11) {
                throw FentonConvergenceException(
                    error?.message ?: "The Fourier system is too ill-conditioned for a reliable binary64 solution.",
                )
            }
            val diagnostics = SolverDiagnostics(
                fourierOrder = n,
                requestedOrder = requestedOrder,
                residualMax = residualMax,
                jacobianCondition = condition,
                numericalNote = note,
            )
            try {
                return AccuracyVerifier.verify(solution.copy(diagnostics = diagnostics), verificationLevel)
            } catch (cancelled: java.util.concurrent.CancellationException) {
                throw cancelled
            } catch (failure: ArithmeticException) {
                throw FentonAccuracyException("Accuracy verification failed: ${failure.message}")
            } catch (failure: IllegalArgumentException) {
                throw FentonAccuracyException("Accuracy verification failed: ${failure.message}")
            } catch (failure: IllegalStateException) {
                throw FentonAccuracyException("Accuracy verification failed: ${failure.message}")
            }
        }
    }

    private fun resetOrder(order: Int) {
        n = order
        z = DoubleArray(numberOfUnknowns + 1)
        firstResidual = DoubleArray(numberOfUnknowns + 1)
        secondResidual = DoubleArray(numberOfUnknowns + 1)
        streamFunctionCoefficients = DoubleArray(n + 1)
        surfaceCoefficients = DoubleArray(n + 1)
        cosineTable = DoubleArray(2 * n) { cos(it * PI / n) }
        sineTable = DoubleArray(2 * n) { sin(it * PI / n) }
        condition = 0.0
    }

    private fun solveAtOrder() {
        val steps = if (abs(nondimensionalCurrent) >= 1.0) 8 else DEFAULT_CONTINUATION_STEPS
        val iterations = if (abs(nondimensionalCurrent) >= 1.0) 80 else DEFAULT_NEWTON_ITERATIONS
        var fraction = 0.0
        var previousFraction = 0.0
        var increment = 1.0 / steps
        var accepted: DoubleArray? = null
        var previous: DoubleArray? = null
        var attempts = 0
        while (fraction < 1.0) {
            checkInterrupted()
            val target = minOf(1.0, fraction + increment)
            steppedHeightParameter = target * targetHeightParameter
            steppedHeightToDepth = target * maximumHeightToDepth
            if (accepted == null) {
                initialiseLinearSeed()
            } else {
                accepted.copyInto(z)
                if (previous != null && fraction > previousFraction) {
                    val ratio = (target - fraction) / (fraction - previousFraction)
                    for (i in 1..numberOfUnknowns) z[i] += ratio * (accepted[i] - previous[i])
                }
                if (!stateIsUsable()) accepted.copyInto(z)
            }
            val tolerance = if (target == 1.0) FINAL_TOLERANCE else INTERMEDIATE_TOLERANCE
            var converged = false
            var reason = "Newton iteration limit reached."
            for (iteration in 1..iterations) {
                checkInterrupted()
                try {
                    val correction = newtonUpdate()
                    evaluateResidual(firstResidual)
                    residualMax = firstResidual.drop(1).maxOf { abs(it) }
                    if (iteration > 1 && correction < tolerance * abs(z[1]) &&
                        residualMax <= tolerance
                    ) {
                        converged = true
                        break
                    }
                    if (correction == 0.0 && residualMax > tolerance) {
                        reason = "Newton step stalled above the residual tolerance."
                        break
                    }
                } catch (failure: ArithmeticException) {
                    reason = failure.message ?: "Invalid Newton step."
                    break
                }
            }
            attempts++
            if (!converged) {
                increment *= 0.5
                if (increment < 1.0 / 4096 || attempts >= 80) {
                    throw ArithmeticException(reason)
                }
                continue
            }
            previous = accepted
            previousFraction = fraction
            fraction = target
            accepted = z.copyOf()
            increment = minOf(increment * 1.5, 1.0 / steps)
            computeSurfaceAndStreamCoefficients()
        }
    }

    private fun checkInterrupted() {
        if (Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException()
    }

    private fun initialiseLinearSeed() {
        val sigma = if (steppedHeightToDepth > 0.0) {
            2.0 * PI * sqrt(steppedHeightParameter / steppedHeightToDepth)
        } else {
            0.0
        }
        z[1] = if (sigma > 0.0) {
            sigma * sigma / tanh(sigma.pow(1.5)).pow(2.0 / 3.0)
        } else {
            2.0 * PI * max(steppedHeightParameter, 1.0e-12) /
                max(steppedHeightToDepth, 1.0e-12)
        }
        z[2] = z[1] * steppedHeightToDepth
        z[4] = sqrt(tanh(z[1]))
        z[3] = 2.0 * PI / z[4]

        // Criterion 1 prescribes Eulerian current; criterion 2 prescribes Stokes current.
        z.fill(0.0, 5)
        z[currentCriterion + 4] = nondimensionalCurrent * sqrt(z[1])
        z[7] = z[4]
        z[8] = 0.0
        z[9] = 0.5 * z[7] * z[7]

        z[10] = 0.5 * z[2]
        for (index in 1..n) {
            z[n + index + 10] = 0.0
            z[index + 10] = 0.5 * z[2] * cosineTable[index]
        }
        z[n + 11] = 0.5 * z[2] / z[7]

    }

    private fun evaluateResidual(output: DoubleArray): Double {
        output[1] = z[2] - z[1] * steppedHeightToDepth
        output[2] = z[2] - steppedHeightParameter * z[3] * z[3]
        output[3] = z[4] * z[3] - 2.0 * PI
        output[4] = z[5] + z[7] - z[4]
        output[5] = z[1] * (z[6] + z[7] - z[4]) - z[8]

        output[6] = z[currentCriterion + 4] - nondimensionalCurrent * sqrt(z[1])
        var meanLevel = z[10] + z[n + 10]
        for (index in 1 until n) meanLevel += 2.0 * z[10 + index]
        output[7] = meanLevel
        output[8] = z[10] - z[n + 10] - z[2]

        for (node in 0..n) {
            val surface = z[10 + node]
            var streamFunction = 0.0
            var horizontalVelocity = 0.0
            var verticalVelocity = 0.0

            for (harmonic in 1..n) {
                val exponent = harmonic * surface
                if (exponent > 60.0 || exponent < -60.0) {
                    throw ArithmeticException("Divergence: exp(j*zeta) is outside the safe range.")
                }
                val positive = exp(exponent)
                val negative = exp(-exponent - 2.0 * harmonic * z[1])
                val denominator = 1.0 + exp(-2.0 * harmonic * z[1])
                val stableSine = (positive - negative) / denominator
                val stableCosine = (positive + negative) / denominator
                val coefficient = z[n + 10 + harmonic]
                val cosine = cosineTable[(node * harmonic) % (2 * n)]
                val sine = sineTable[(node * harmonic) % (2 * n)]

                streamFunction += coefficient * stableSine * cosine
                horizontalVelocity += harmonic * coefficient * stableCosine * cosine
                verticalVelocity += harmonic * coefficient * stableSine * sine
            }

            output[node + 9] = streamFunction - z[8] - z[7] * surface
            output[n + node + 10] =
                0.5 * ((-z[7] + horizontalVelocity).pow(2) + verticalVelocity.pow(2)) +
                surface - z[9]
        }

        var squaredNorm = 0.0
        for (index in 1..numberOfUnknowns) squaredNorm += output[index] * output[index]
        if (!squaredNorm.isFinite()) throw ArithmeticException("Non-finite residual norm.")
        return squaredNorm
    }

    private fun newtonUpdate(): Double {
        val initialSquaredNorm = evaluateResidual(firstResidual)
        val initialState = z.copyOf()
        val linear = LinearAlgebra.solve(
            jacobian(), DoubleArray(numberOfUnknowns) { -firstResidual[it + 1] }, numberOfUnknowns,
        )
        condition = linear.condition
        val correction = linear.correction
        if (!correction.all(Double::isFinite)) {
            throw ArithmeticException("Non-finite Newton correction vector.")
        }

        var acceptedState: DoubleArray? = null
        var scale = 1.0
        while (scale >= 1.0e-4) {
            val candidate = initialState.copyOf()
            for (index in 1..numberOfUnknowns) {
                candidate[index] = initialState[index] + scale * correction[index - 1]
            }
            if (candidate[1] <= 0.0 || !activeValuesAreFinite(candidate)) {
                scale *= 0.5
                continue
            }

            candidate.copyInto(z)
            val candidateNorm = try {
                evaluateResidual(secondResidual)
            } catch (_: ArithmeticException) {
                Double.POSITIVE_INFINITY
            }
            if (candidateNorm.isFinite() && candidateNorm <= initialSquaredNorm) {
                acceptedState = candidate
                break
            }
            scale *= 0.5
        }

        val best = acceptedState ?: initialState
        best.copyInto(z)
        var meanSurfaceCorrection = 0.0
        for (index in 10..n + 10) {
            meanSurfaceCorrection += abs(best[index] - initialState[index])
        }
        return meanSurfaceCorrection / (n + 1)
    }

    /** Exact derivatives of the collocation equations (no finite differences). */
    private fun jacobian(): DoubleArray {
        val a = DoubleArray(numberOfUnknowns * numberOfUnknowns)
        fun set(row: Int, col: Int, value: Double) {
            a[(row - 1) * numberOfUnknowns + col - 1] = value
        }
        set(1, 1, -steppedHeightToDepth); set(1, 2, 1.0)
        set(2, 2, 1.0); set(2, 3, -2.0 * steppedHeightParameter * z[3])
        set(3, 3, z[4]); set(3, 4, z[3])
        set(4, 5, 1.0); set(4, 7, 1.0); set(4, 4, -1.0)
        set(5, 1, z[6] + z[7] - z[4])
        set(5, 6, z[1]); set(5, 7, z[1]); set(5, 4, -z[1]); set(5, 8, -1.0)
        set(6, currentCriterion + 4, 1.0)
        set(6, 1, -0.5 * nondimensionalCurrent / sqrt(z[1]))
        for (m in 0..n) set(7, 10 + m, if (m == 0 || m == n) 1.0 else 2.0)
        set(8, 10, 1.0); set(8, n + 10, -1.0); set(8, 2, -1.0)
        for (m in 0..n) {
            val eta = z[10 + m]
            val cosines = DoubleArray(n + 1)
            val sines = DoubleArray(n + 1)
            val c = DoubleArray(n + 1)
            val s = DoubleArray(n + 1)
            var u = 0.0
            var v = 0.0
            var psiKd = 0.0
            var uKd = 0.0
            var vKd = 0.0
            var uEta = 0.0
            var vEta = 0.0
            for (j in 1..n) {
                val ep = exp(j * eta)
                val e = exp(-2.0 * j * z[1])
                val em = exp(-j * eta - 2.0 * j * z[1])
                val den = 1.0 + e
                c[j] = (ep + em) / den
                s[j] = (ep - em) / den
                cosines[j] = cosineTable[(m * j) % (2 * n)]
                sines[j] = sineTable[(m * j) % (2 * n)]
                val b = z[n + 10 + j]
                val ds = 2.0 * j * (em + e * ep) / (den * den)
                val dc = 2.0 * j * (e * ep - em) / (den * den)
                u += j * b * c[j] * cosines[j]
                v += j * b * s[j] * sines[j]
                psiKd += b * ds * cosines[j]
                uKd += j * b * dc * cosines[j]
                vKd += j * b * ds * sines[j]
                uEta += j * j * b * s[j] * cosines[j]
                vEta += j * j * b * c[j] * sines[j]
            }
            val uw = u - z[7]
            val stream = 9 + m
            val dynamic = n + 10 + m
            set(stream, 1, psiKd); set(stream, 7, -eta); set(stream, 8, -1.0)
            set(stream, 10 + m, uw)
            set(dynamic, 1, uw * uKd + v * vKd)
            set(dynamic, 7, -uw); set(dynamic, 9, -1.0)
            set(dynamic, 10 + m, 1.0 + uw * uEta + v * vEta)
            for (j in 1..n) {
                set(stream, n + 10 + j, s[j] * cosines[j])
                set(dynamic, n + 10 + j, j * (uw * c[j] * cosines[j] + v * s[j] * sines[j]))
            }
        }
        return a
    }

    private fun computeSurfaceAndStreamCoefficients() {
        surfaceCoefficients.fill(0.0)
        for (harmonic in 1..n) {
            streamFunctionCoefficients[harmonic] = z[harmonic + n + 10]
            val alternatingSign = if (harmonic % 2 == 1) -1.0 else 1.0
            var sum = 0.5 * (z[10] + z[n + 10] * alternatingSign)
            for (node in 1 until n) {
                sum += z[10 + node] * cosineTable[(node * harmonic) % (2 * n)]
            }
            surfaceCoefficients[harmonic] = 2.0 * sum / n
        }
    }

    private fun buildSolution(): WaveSolution {
        val kd = z[1]
        if (!kd.isFinite() || kd <= 0.0) throw ArithmeticException("Invalid wavenumber kd.")
        val waveNumber = kd / input.waterDepth
        val wavelength = 2.0 * PI / waveNumber
        val celerity = wavelength / input.wavePeriod
        if (!wavelength.isFinite() || wavelength <= 0.0) {
            throw ArithmeticException("Invalid wavelength.")
        }
        if (!celerity.isFinite() || celerity <= 0.0) {
            throw ArithmeticException("Invalid celerity.")
        }

        val surfaceNodes = DoubleArray(n + 1)
        for (node in 0..n) {
            surfaceNodes[node] = input.waterDepth * (1.0 + z[10 + node] / kd)
        }

        // Re-impose dimensional period/current identities exactly as the source does.
        z[3] = input.wavePeriod * sqrt(GRAVITY * waveNumber)
        z[4] = celerity * sqrt(waveNumber / GRAVITY)
        if (currentCriterion == 1) {
            z[5] = input.currentVelocity * sqrt(waveNumber / GRAVITY)
            z[7] = z[4] - z[5]
            z[6] = z[8] / z[1] - z[7] + z[4]
        } else {
            z[6] = input.currentVelocity * sqrt(waveNumber / GRAVITY)
            z[7] = z[8] / z[1] - z[6] + z[4]
            z[5] = z[4] - z[7]
        }

        val crestElevation = surfaceNodes.first() - input.waterDepth
        val troughElevation = surfaceNodes.last() - input.waterDepth
        val steepness = input.waveHeight / wavelength
        val relativeDepth = input.waterDepth / wavelength
        val ursell = input.waveHeight * wavelength * wavelength /
            input.waterDepth.pow(3)
        val regime = when {
            relativeDepth < 0.05 -> "Shallow"
            relativeDepth < 0.5 -> "Intermediate"
            else -> "Deep"
        }
        val breakingLimit = 0.142 * wavelength * tanh(waveNumber * input.waterDepth)
        val saturation = if (breakingLimit > 0.0) input.waveHeight / breakingLimit else 0.0

        val integrals = calculateIntegralProperties(kd)
        val eulerian = z[5] * sqrt(GRAVITY * input.waterDepth / kd)
        fun surfacePoint(phase: Double) =
            kinematics(input.waterDepth * (1.0 + surfaceKeta(phase) / kd), phase, kd)
        val surfaceMaximum = phaseMaximum { abs(surfacePoint(it).horizontal) }
        val bedMaximum = phaseMaximum { abs(kinematics(0.0, it, kd).horizontal) }
        val orbitalMaximum = phaseMaximum { abs(kinematics(0.0, it, kd).horizontal - eulerian) }
        val accelerationMaximum = phaseMaximum { abs(surfacePoint(it).horizontalAcceleration) }
        val bedAccelerationMaximum = phaseMaximum { abs(kinematics(0.0, it, kd).horizontalAcceleration) }
        val verticalMaximum = phaseMaximum { abs(surfacePoint(it).vertical) }
        val tauBed = 0.5 * SEA_WATER_DENSITY * 0.005 * bedMaximum.first.pow(2)
        val bedExcursion = orbitalMaximum.first * input.wavePeriod / (2.0 * PI)
        val crestKinematics = kinematics(
            zFromBed = input.waterDepth + crestElevation,
            phase = 0.0,
            kd = kd,
        )
        val troughKinematics = kinematics(
            zFromBed = input.waterDepth + troughElevation,
            phase = PI,
            kd = kd,
        )
        val asymmetry = if (abs(troughKinematics.horizontal) > 0.0) {
            abs(crestKinematics.horizontal / troughKinematics.horizontal)
        } else {
            0.0
        }

        return WaveSolution(
            waveHeight = input.waveHeight,
            wavePeriod = input.wavePeriod,
            waterDepth = input.waterDepth,
            inputCurrent = input.currentVelocity,
            gravity = GRAVITY,
            density = SEA_WATER_DENSITY,
            wavelength = wavelength,
            waveNumber = waveNumber,
            kd = kd,
            angularFrequency = 2.0 * PI / input.wavePeriod,
            celerity = celerity,
            crestElevation = crestElevation,
            troughElevation = troughElevation,
            steepness = steepness,
            relativeDepth = relativeDepth,
            ursellNumber = ursell,
            regime = regime,
            micheBreakingLimit = breakingLimit,
            saturation = saturation,
            isBreaking = breakingLimit > 0.0 && input.waveHeight > breakingLimit,
            eulerianCurrent = eulerian,
            stokesCurrent = integrals.stokesCurrent,
            massTransport = integrals.stokesCurrent,
            meanFluidSpeed = integrals.meanFluidSpeed,
            waveVolumeFlux = integrals.waveVolumeFlux,
            volumeFlux = integrals.volumeFlux,
            bernoulliConstant = integrals.bernoulliConstant,
            reducedBernoulliConstant = integrals.reducedBernoulliConstant,
            bernoulliConstantDimensionless = integrals.bernoulliConstantDimensionless,
            kineticEnergy = integrals.kineticEnergy,
            potentialEnergy = integrals.potentialEnergy,
            totalEnergy = integrals.totalEnergy,
            momentumFlux = integrals.momentumFlux,
            radiationStress = integrals.radiationStress,
            impulse = integrals.impulse,
            wavePower = integrals.wavePower,
            groupVelocity = integrals.groupVelocity,
            kineticEnergyDepth = integrals.kineticEnergyDepth,
            potentialEnergyDepth = integrals.potentialEnergyDepth,
            energyDepth = integrals.energyDepth,
            momentumFluxDepth = integrals.momentumFluxDepth,
            radiationStressDepth = integrals.radiationStressDepth,
            impulseDepth = integrals.impulseDepth,
            wavePowerDepth = integrals.wavePowerDepth,
            surfaceHorizontalVelocity = surfaceMaximum.first,
            bedHorizontalVelocity = bedMaximum.first,
            maxHorizontalAcceleration = accelerationMaximum.first,
            maxVerticalVelocity = verticalMaximum.first,
            velocityAsymmetry = asymmetry,
            meanSquareBedOrbitalVelocity = integrals.meanSquareBedOrbitalVelocity,
            bedOrbitalRmsVelocity = sqrt(max(0.0, integrals.meanSquareBedOrbitalVelocity)),
            tauBed = tauBed,
            bedExcursion = bedExcursion,
            surfaceNodesFromBed = surfaceNodes.toList(),
            streamFunctionCoefficients = streamFunctionCoefficients.toList(),
            surfaceCoefficients = surfaceCoefficients.copyOfRange(0, n + 1).toList(),
            stateVector = z.toList(),
            maxBedHorizontalAcceleration = bedAccelerationMaximum.first,
            meanSquareBedAbsoluteVelocity = integrals.meanSquareBedOrbitalVelocity + eulerian.pow(2),
            extremaPhases = listOf(surfaceMaximum.second, bedMaximum.second, accelerationMaximum.second,
                bedAccelerationMaximum.second, verticalMaximum.second, orbitalMaximum.second),
            currentCriterion = currentCriterion,
        )
    }

    private fun calculateIntegralProperties(kd: Double): IntegralProperties {
        val celerityDepth = z[4] / sqrt(kd)
        val stokesDepth = z[6] / sqrt(kd)
        val meanFluidSpeedDepth = z[7] / sqrt(kd)
        val volumeFluxDepth = meanFluidSpeedDepth - z[8] / kd.pow(1.5)
        val bernoulliDepth = 1.0 + z[9] / kd

        val impulseK = z[8] + kd * z[5]
        val kineticK = 0.5 * (
            z[4] * impulseK - z[5] * volumeFluxDepth * kd.pow(1.5)
        )
        var potentialK = 0.0
        for (index in 1 until n) potentialK += 0.25 * surfaceCoefficients[index].pow(2)
        potentialK += surfaceCoefficients[n].pow(2) / 16.0
        val meanBedVelocityK = 2.0 * z[9] - z[4].pow(2) + 2.0 * z[4] * z[5]
        val radiationK = 4.0 * kineticK - 3.0 * potentialK +
            meanBedVelocityK * kd - 2.0 * z[5] * impulseK
        val powerK = z[4] * (3.0 * kineticK - 2.0 * potentialK) +
            0.5 * meanBedVelocityK * (impulseK + z[4] * kd) -
            2.0 * z[4] * z[5] * impulseK

        val energyDepth = (kineticK + potentialK) / kd.pow(2)
        val kineticDepth = kineticK / kd.pow(2)
        val potentialDepth = potentialK / kd.pow(2)
        val radiationDepth = radiationK / kd.pow(2)
        val powerDepth = powerK / kd.pow(2.5)
        val impulseDepth = impulseK / kd.pow(1.5)
        val dimensionalEnergyScale = SEA_WATER_DENSITY * GRAVITY * input.waterDepth.pow(2)

        val totalEnergy = dimensionalEnergyScale * energyDepth
        val wavePower = SEA_WATER_DENSITY * GRAVITY.pow(1.5) *
            input.waterDepth.pow(2.5) * powerDepth
        val stokesCurrent = stokesDepth * sqrt(GRAVITY * input.waterDepth)
        val meanFluidSpeed = meanFluidSpeedDepth * sqrt(GRAVITY * input.waterDepth)
        val volumeFlux = volumeFluxDepth * sqrt(GRAVITY * input.waterDepth.pow(3))
        val waveVolumeFlux = meanFluidSpeed * input.waterDepth - volumeFlux
        val momentumDepth = momentumFluxDepth(phase = 0.0, points = 1200, kd = kd)
        val meanSquareBedVelocity = meanSquareBedOrbitalVelocity(kd)

        return IntegralProperties(
            stokesCurrent = stokesCurrent,
            meanFluidSpeed = meanFluidSpeed,
            waveVolumeFlux = waveVolumeFlux,
            volumeFlux = volumeFlux,
            bernoulliConstant = bernoulliDepth * GRAVITY * input.waterDepth,
            reducedBernoulliConstant = (bernoulliDepth - 1.0) * GRAVITY * input.waterDepth,
            bernoulliConstantDimensionless = bernoulliDepth,
            kineticEnergy = dimensionalEnergyScale * kineticDepth,
            potentialEnergy = dimensionalEnergyScale * potentialDepth,
            totalEnergy = totalEnergy,
            momentumFlux = dimensionalEnergyScale * momentumDepth,
            radiationStress = dimensionalEnergyScale * radiationDepth,
            impulse = SEA_WATER_DENSITY * sqrt(GRAVITY * input.waterDepth.pow(3)) * impulseDepth,
            wavePower = wavePower,
            groupVelocity = if (abs(totalEnergy) > 1.0e-12) wavePower / totalEnergy else 0.0,
            kineticEnergyDepth = kineticDepth,
            potentialEnergyDepth = potentialDepth,
            energyDepth = energyDepth,
            momentumFluxDepth = momentumDepth,
            radiationStressDepth = radiationDepth,
            impulseDepth = impulseDepth,
            wavePowerDepth = powerDepth,
            meanSquareBedOrbitalVelocity = meanSquareBedVelocity,
        )
    }

    private fun momentumFluxDepth(phase: Double, points: Int, kd: Double): Double {
        val sampleCount = max(50, points)
        val celerity = z[4] / sqrt(kd)
        val bernoulli = 1.0 + z[9] / kd
        val surfaceDepth = 1.0 + surfaceKeta(phase) / kd
        val spacing = surfaceDepth / (sampleCount - 1)
        var integral = 0.0
        var previous = momentumFluxIntegrand(
            y = 0.0,
            phase = phase,
            kd = kd,
            celerity = celerity,
            bernoulli = bernoulli,
        )
        for (sample in 1 until sampleCount) {
            val y = spacing * sample
            val current = momentumFluxIntegrand(y, phase, kd, celerity, bernoulli)
            integral += 0.5 * (previous + current) * spacing
            previous = current
        }
        return integral
    }

    private fun momentumFluxIntegrand(
        y: Double,
        phase: Double,
        kd: Double,
        celerity: Double,
        bernoulli: Double,
    ): Double {
        val point = dimensionlessPoint(phase, kd * (y - 1.0), kd)
        val relativeVelocity = point.horizontal - celerity
        val pressure = bernoulli - y -
            0.5 * (relativeVelocity.pow(2) + point.vertical.pow(2))
        return pressure + relativeVelocity.pow(2)
    }

    private fun meanSquareBedOrbitalVelocity(kd: Double): Double {
        var sum = 0.0
        for (j in 1..n) {
            val e = exp(-j * kd)
            val amplitude = j * streamFunctionCoefficients[j] * 2.0 * e / (1.0 + e * e)
            sum += amplitude * amplitude
        }
        return 0.5 * GRAVITY * input.waterDepth / kd * sum
    }

    private fun phaseMaximum(value: (Double) -> Double): Pair<Double, Double> {
        val count = max(257, 8 * n + 1)
        val phases = DoubleArray(count) { PI * it / (count - 1) }
        val values = DoubleArray(count) { value(phases[it]) }
        if (!values.all(Double::isFinite)) throw ArithmeticException("Non-finite phase evaluation.")
        val best = values.indices.maxBy { values[it] }
        var maximum = values[best]
        var location = phases[best]
        val golden = (sqrt(5.0) - 1.0) / 2.0
        for (i in 1 until count - 1) {
            if (values[i] < values[i - 1] || values[i] < values[i + 1] ||
                (values[i] == values[i - 1] && values[i] == values[i + 1])
            ) continue
            var left = phases[i - 1]
            var right = phases[i + 1]
            var x1 = right - golden * (right - left)
            var x2 = left + golden * (right - left)
            var f1 = value(x1)
            var f2 = value(x2)
            for (iteration in 0 until 64) {
                if (f1 > maximum) { maximum = f1; location = x1 }
                if (f2 > maximum) { maximum = f2; location = x2 }
                if (right - left < 1.0e-12) break
                if (f1 < f2) {
                    left = x1; x1 = x2; f1 = f2
                    x2 = left + golden * (right - left); f2 = value(x2)
                } else {
                    right = x2; x2 = x1; f2 = f1
                    x1 = right - golden * (right - left); f1 = value(x1)
                }
            }
        }
        return maximum to location
    }

    private fun kinematics(zFromBed: Double, phase: Double, kd: Double): Kinematics {
        val waveNumber = kd / input.waterDepth
        val verticalCoordinate = waveNumber * (zFromBed - input.waterDepth)
        val point = dimensionlessPoint(phase, verticalCoordinate, kd)
        val velocityScale = sqrt(GRAVITY * input.waterDepth)
        return Kinematics(
            horizontal = point.horizontal * velocityScale,
            vertical = point.vertical * velocityScale,
            horizontalAcceleration = point.horizontalAcceleration * GRAVITY,
        )
    }

    private fun dimensionlessPoint(phase: Double, verticalCoordinate: Double, kd: Double): Kinematics {
        val celerity = z[4] / sqrt(kd)
        val eulerianCurrent = z[5] / sqrt(kd)
        var horizontal = 0.0
        var vertical = 0.0
        var horizontalDerivative = 0.0
        var verticalDerivative = 0.0

        for (harmonic in 1..n) {
            val cosine = cos(harmonic * phase)
            val sine = sin(harmonic * phase)
            val a = harmonic * verticalCoordinate
            val ep = exp(a)
            val em = exp(-a - 2.0 * harmonic * kd)
            val den = 1.0 + exp(-2.0 * harmonic * kd)
            val stableCosine = (ep + em) / den
            val stableSine = (ep - em) / den
            val coefficient = streamFunctionCoefficients[harmonic]

            horizontal += harmonic * coefficient * stableCosine * cosine
            vertical += harmonic * coefficient * stableSine * sine
            horizontalDerivative -= harmonic * harmonic * coefficient * stableCosine * sine
            verticalDerivative += harmonic * harmonic * coefficient * stableSine * cosine
        }

        horizontal /= sqrt(kd)
        vertical /= sqrt(kd)
        horizontalDerivative *= sqrt(kd)
        verticalDerivative *= sqrt(kd)
        horizontal += eulerianCurrent

        val timeDerivative = -celerity * horizontalDerivative
        val verticalHorizontalDerivative = verticalDerivative
        val horizontalAcceleration = timeDerivative +
            horizontal * horizontalDerivative + vertical * verticalHorizontalDerivative
        return Kinematics(horizontal, vertical, horizontalAcceleration)
    }

    private fun surfaceKeta(phase: Double): Double {
        var surface = 0.0
        for (harmonic in 1 until n) {
            surface += surfaceCoefficients[harmonic] * cos(harmonic * phase)
        }
        surface += 0.5 * surfaceCoefficients[n] * cos(n * phase)
        return surface
    }

    private fun stateIsUsable(): Boolean = z[1] > 0.0 && activeValuesAreFinite(z)

    private fun activeValuesAreFinite(values: DoubleArray): Boolean {
        for (index in 1..numberOfUnknowns) if (!values[index].isFinite()) return false
        return true
    }

    private fun validateInput(value: WaveInput) {
        if (!value.waveHeight.isFinite() || value.waveHeight <= 0.0) {
            throw InvalidWaveInputException("Wave height H must be a finite value greater than zero.")
        }
        if (!value.wavePeriod.isFinite() || value.wavePeriod <= 0.0) {
            throw InvalidWaveInputException("Wave period T must be a finite value greater than zero.")
        }
        if (!value.waterDepth.isFinite() || value.waterDepth <= 0.0) {
            throw InvalidWaveInputException("Water depth d must be a finite value greater than zero.")
        }
        if (!value.currentVelocity.isFinite()) {
            throw InvalidWaveInputException("Current velocity Uc must be finite.")
        }
    }

    private data class Kinematics(
        val horizontal: Double,
        val vertical: Double,
        val horizontalAcceleration: Double,
    )

    private data class IntegralProperties(
        val stokesCurrent: Double,
        val meanFluidSpeed: Double,
        val waveVolumeFlux: Double,
        val volumeFlux: Double,
        val bernoulliConstant: Double,
        val reducedBernoulliConstant: Double,
        val bernoulliConstantDimensionless: Double,
        val kineticEnergy: Double,
        val potentialEnergy: Double,
        val totalEnergy: Double,
        val momentumFlux: Double,
        val radiationStress: Double,
        val impulse: Double,
        val wavePower: Double,
        val groupVelocity: Double,
        val kineticEnergyDepth: Double,
        val potentialEnergyDepth: Double,
        val energyDepth: Double,
        val momentumFluxDepth: Double,
        val radiationStressDepth: Double,
        val impulseDepth: Double,
        val wavePowerDepth: Double,
        val meanSquareBedOrbitalVelocity: Double,
    )
}

