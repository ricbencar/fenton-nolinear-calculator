package com.example.fenton.solver

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.cosh
import kotlin.math.sqrt
import kotlin.math.tanh

/** Entry point mirroring the two-case calculation performed by fenton_gui.py. */
object FentonCalculator {
    @JvmStatic
    fun calculate(
        waveHeight: Double,
        wavePeriod: Double,
        waterDepth: Double,
        currentVelocity: Double,
    ): FentonCalculation {
        val noCurrent = FentonSolver(
            WaveInput(waveHeight, wavePeriod, waterDepth, currentVelocity = 0.0),
        ).solve()
        val withCurrent = if (currentVelocity == 0.0) {
            noCurrent
        } else {
            FentonSolver(
                WaveInput(waveHeight, wavePeriod, waterDepth, currentVelocity),
            ).solve()
        }
        return FentonCalculation(noCurrent = noCurrent, withCurrent = withCurrent)
    }
}

/**
 * Rienecker-Fenton stream-function/Fourier collocation solver.
 *
 * The implementation intentionally retains the reference program's one-based
 * state vector and continuation/Newton details. It is pure Kotlin/JVM and does
 * not depend on Android, Compose, native BLAS, or third-party math libraries.
 */
class FentonSolver(private val input: WaveInput) {
    companion object {
        const val GRAVITY = 9.80665
        const val SEA_WATER_DENSITY = 1025.0
        const val FOURIER_ORDER = 50

        private const val INTERMEDIATE_TOLERANCE = 1.0e-8
        private const val FINAL_TOLERANCE = 1.0e-10
        private const val DEFAULT_CONTINUATION_STEPS = 4
        private const val DEFAULT_NEWTON_ITERATIONS = 40
    }

    constructor(
        waveHeight: Double,
        wavePeriod: Double,
        waterDepth: Double,
        currentVelocity: Double = 0.0,
    ) : this(WaveInput(waveHeight, wavePeriod, waterDepth, currentVelocity))

    private val n = FOURIER_ORDER
    private val numberOfUnknowns = 2 * n + 10

    // The zero entry is deliberately unused, matching the reference notation.
    private val z = DoubleArray(numberOfUnknowns + 1)
    private val firstResidual = DoubleArray(numberOfUnknowns + 1)
    private val secondResidual = DoubleArray(numberOfUnknowns + 1)
    private val coefficients = DoubleArray(n + 1)
    private val hyperbolicTangents = DoubleArray(n + 1)
    private val streamFunctionCoefficients = DoubleArray(n + 1)
    private val surfaceCoefficients = DoubleArray(numberOfUnknowns + 1)
    private val cosineTable = DoubleArray(2 * n + 1) { index -> cos(index * PI / n) }
    private val sineTable = DoubleArray(2 * n + 1) { index -> sin(index * PI / n) }
    private val cosineAtNodes = Array(n + 1) { m ->
        DoubleArray(n) { j -> cosineTable[(m * (j + 1)) % (2 * n)] }
    }
    private val sineAtNodes = Array(n + 1) { m ->
        DoubleArray(n) { j -> sineTable[(m * (j + 1)) % (2 * n)] }
    }
    private val continuationStates = Array(numberOfUnknowns + 1) { DoubleArray(3) }

    private val maximumHeightToDepth = input.waveHeight / input.waterDepth
    private val nondimensionalPeriod = input.wavePeriod * sqrt(GRAVITY / input.waterDepth)
    private val targetHeightParameter = maximumHeightToDepth /
        (nondimensionalPeriod * nondimensionalPeriod)
    private val nondimensionalCurrent = input.currentVelocity /
        sqrt(GRAVITY * input.waterDepth)

    private var steppedHeightParameter = 0.0
    private var steppedHeightToDepth = 0.0

    init {
        validateInput(input)
    }

    fun solve(): WaveSolution {
        val continuationSteps = if (abs(nondimensionalCurrent) >= 1.0) 8
        else DEFAULT_CONTINUATION_STEPS
        val maximumNewtonIterations = if (abs(nondimensionalCurrent) >= 1.0) 80
        else DEFAULT_NEWTON_ITERATIONS

        try {
            val heightIncrement = targetHeightParameter / continuationSteps
            val heightToDepthIncrement = maximumHeightToDepth / continuationSteps

            for (step in 1..continuationSteps) {
                steppedHeightParameter = step * heightIncrement
                steppedHeightToDepth = step * heightToDepthIncrement

                if (step == 1) {
                    initialiseLinearSeed()
                } else {
                    for (index in 1..numberOfUnknowns) {
                        z[index] = 2.0 * continuationStates[index][2] -
                            continuationStates[index][1]
                    }
                    if (!stateIsUsable()) restoreLastContinuationState()
                    if (!stateIsUsable()) {
                        throw ArithmeticException(
                            "Invalid extrapolated start state at continuation step $step.",
                        )
                    }
                }

                var converged = false
                for (iteration in 1..maximumNewtonIterations) {
                    val correction = try {
                        newtonUpdate()
                    } catch (failure: ArithmeticException) {
                        if (step > 1 && iteration == 1) {
                            restoreLastContinuationState()
                            newtonUpdate()
                        } else {
                            throw failure
                        }
                    }
                    if (!correction.isFinite()) {
                        throw ArithmeticException("Non-finite Newton correction.")
                    }

                    // This update is intentionally inside the Newton loop. The
                    // Python reference extrapolates from its two last iterates.
                    if (step == 1) {
                        for (index in 1..numberOfUnknowns) {
                            continuationStates[index][2] = z[index]
                        }
                    } else {
                        for (index in 1..numberOfUnknowns) {
                            continuationStates[index][1] = continuationStates[index][2]
                            continuationStates[index][2] = z[index]
                        }
                    }

                    if (!stateIsUsable()) {
                        throw ArithmeticException("Divergence produced an invalid state vector.")
                    }
                    val tolerance = if (step == continuationSteps) {
                        FINAL_TOLERANCE
                    } else {
                        INTERMEDIATE_TOLERANCE
                    }
                    if (iteration > 1 && correction < tolerance * abs(z[1])) {
                        converged = true
                        break
                    }
                }

                if (!converged) {
                    throw FentonConvergenceException(
                        "Newton did not converge within $maximumNewtonIterations iterations " +
                            "at continuation step $step/$continuationSteps.",
                    )
                }
                computeSurfaceAndStreamCoefficients()
            }

            return buildSolution()
        } catch (failure: FentonSolverException) {
            throw failure
        } catch (failure: Throwable) {
            throw FentonConvergenceException(
                "Fenton solver failed: ${failure.message ?: failure::class.java.simpleName}",
                failure,
            )
        }
    }

    private fun initialiseLinearSeed() {
        val sigma = if (steppedHeightToDepth > 0.0) {
            2.0 * PI * sqrt(steppedHeightParameter / steppedHeightToDepth)
        } else {
            0.0
        }
        z[1] = if (sigma > 0.0) {
            sigma * sigma / tanh(sigma.pow(1.5)).pow(2.0 / 3.0)
        } else {
            2.0 * PI * max(steppedHeightParameter, 1.0e-12) /
                max(steppedHeightToDepth, 1.0e-12)
        }
        z[2] = z[1] * steppedHeightToDepth
        z[4] = sqrt(tanh(z[1]))
        z[3] = 2.0 * PI / z[4]

        // Current criterion 1: prescribed Eulerian current.
        z[5] = nondimensionalCurrent * sqrt(z[2])
        z[6] = 0.0
        z[7] = z[4]
        z[8] = 0.0
        z[9] = 0.5 * z[7] * z[7]

        z[10] = 0.5 * z[2]
        for (index in 1..n) {
            z[n + index + 10] = 0.0
            z[index + 10] = 0.5 * z[2] * cosineTable[index]
        }
        z[n + 11] = 0.5 * z[2] / z[7]

        for (index in 1..9) continuationStates[index][1] = z[index]
        for (index in 10..numberOfUnknowns) continuationStates[index][1] = 0.0
    }

    private fun evaluateResidual(output: DoubleArray): Double {
        output[1] = z[2] - z[1] * steppedHeightToDepth
        output[2] = z[2] - steppedHeightParameter * z[3] * z[3]
        output[3] = z[4] * z[3] - 2.0 * PI
        output[4] = z[5] + z[7] - z[4]
        output[5] = z[1] * (z[6] + z[7] - z[4]) - z[8]

        for (index in 1..n) {
            coefficients[index] = z[n + index + 10]
            hyperbolicTangents[index] = tanh(index * z[1])
        }

        output[6] = z[5] - nondimensionalCurrent * sqrt(z[1])
        var meanLevel = z[10] + z[n + 10]
        for (index in 1 until n) meanLevel += 2.0 * z[10 + index]
        output[7] = meanLevel
        output[8] = z[10] - z[n + 10] - z[2]

        for (node in 0..n) {
            val surface = z[10 + node]
            var streamFunction = 0.0
            var horizontalVelocity = 0.0
            var verticalVelocity = 0.0

            for (harmonic in 1..n) {
                val exponent = harmonic * surface
                if (exponent > 60.0 || exponent < -60.0) {
                    throw ArithmeticException("Divergence: exp(j*zeta) is outside the safe range.")
                }
                val positive = exp(exponent)
                val negative = 1.0 / positive
                val hyperbolicSine = 0.5 * (positive - negative)
                val hyperbolicCosine = 0.5 * (positive + negative)
                val tangent = hyperbolicTangents[harmonic]
                val stableSine = hyperbolicSine + hyperbolicCosine * tangent
                val stableCosine = hyperbolicCosine + hyperbolicSine * tangent
                val coefficient = coefficients[harmonic]
                val cosine = cosineAtNodes[node][harmonic - 1]
                val sine = sineAtNodes[node][harmonic - 1]

                streamFunction += coefficient * stableSine * cosine
                horizontalVelocity += harmonic * coefficient * stableCosine * cosine
                verticalVelocity += harmonic * coefficient * stableSine * sine
            }

            output[node + 9] = streamFunction - z[8] - z[7] * surface
            output[n + node + 10] =
                0.5 * ((-z[7] + horizontalVelocity).pow(2) + verticalVelocity.pow(2)) +
                surface - z[9]
        }

        var squaredNorm = 0.0
        for (index in 1..numberOfUnknowns) squaredNorm += output[index] * output[index]
        if (!squaredNorm.isFinite()) throw ArithmeticException("Non-finite residual norm.")
        return squaredNorm
    }

    private fun newtonUpdate(): Double {
        val initialSquaredNorm = evaluateResidual(firstResidual)
        val initialState = z.copyOf()
        val jacobian = DoubleArray(numberOfUnknowns * numberOfUnknowns)
        val rightHandSide = DoubleArray(numberOfUnknowns)

        for (columnOneBased in 1..numberOfUnknowns) {
            var increment = 0.01 * initialState[columnOneBased]
            if (abs(initialState[columnOneBased]) < 1.0e-4) increment = 1.0e-5
            if (abs(increment) > 1.0) increment = if (increment < 0.0) -1.0 else 1.0

            z[columnOneBased] = initialState[columnOneBased] + increment
            evaluateResidual(secondResidual)
            z[columnOneBased] = initialState[columnOneBased]

            rightHandSide[columnOneBased - 1] = -firstResidual[columnOneBased]
            for (rowOneBased in 1..numberOfUnknowns) {
                jacobian[(rowOneBased - 1) * numberOfUnknowns + columnOneBased - 1] =
                    (secondResidual[rowOneBased] - firstResidual[rowOneBased]) / increment
            }
        }

        val correction = LinearAlgebra.solve(
            jacobian,
            rightHandSide,
            numberOfUnknowns,
        )
        if (!correction.all(Double::isFinite)) {
            throw ArithmeticException("Non-finite Newton correction vector.")
        }

        var acceptedState: DoubleArray? = null
        var scale = 1.0
        while (scale >= 1.0e-4) {
            val candidate = initialState.copyOf()
            for (index in 1..numberOfUnknowns) {
                candidate[index] = initialState[index] + scale * correction[index - 1]
            }
            if (candidate[1] <= 0.0 || !activeValuesAreFinite(candidate)) {
                scale *= 0.5
                continue
            }

            candidate.copyInto(z)
            val candidateNorm = try {
                evaluateResidual(secondResidual)
            } catch (_: ArithmeticException) {
                Double.POSITIVE_INFINITY
            }
            if (candidateNorm.isFinite() && candidateNorm <= initialSquaredNorm) {
                acceptedState = candidate
                break
            }
            scale *= 0.5
        }

        val best = acceptedState ?: initialState
        best.copyInto(z)
        var meanSurfaceCorrection = 0.0
        for (index in 10..n + 10) {
            meanSurfaceCorrection += abs(best[index] - initialState[index])
        }
        return meanSurfaceCorrection / (n + 1)
    }

    private fun computeSurfaceAndStreamCoefficients() {
        surfaceCoefficients.fill(0.0)
        for (harmonic in 1..n) {
            streamFunctionCoefficients[harmonic] = z[harmonic + n + 10]
            val alternatingSign = if (harmonic % 2 == 1) -1.0 else 1.0
            var sum = 0.5 * (z[10] + z[n + 10] * alternatingSign)
            for (node in 1 until n) {
                sum += z[10 + node] * cosineTable[(node * harmonic) % (2 * n)]
            }
            surfaceCoefficients[harmonic] = 2.0 * sum / n
        }
    }

    private fun buildSolution(): WaveSolution {
        val kd = z[1]
        if (!kd.isFinite() || kd <= 0.0) throw ArithmeticException("Invalid wavenumber kd.")
        val waveNumber = kd / input.waterDepth
        val wavelength = 2.0 * PI / waveNumber
        val celerity = wavelength / input.wavePeriod
        if (!wavelength.isFinite() || wavelength <= 0.0) {
            throw ArithmeticException("Invalid wavelength.")
        }
        if (!celerity.isFinite() || celerity <= 0.0) {
            throw ArithmeticException("Invalid celerity.")
        }

        val surfaceNodes = DoubleArray(n + 1)
        for (node in 0..n) {
            surfaceNodes[node] = input.waterDepth * (1.0 + z[10 + node] / kd)
        }

        // Re-impose dimensional period/current identities exactly as the source does.
        z[3] = input.wavePeriod * sqrt(GRAVITY * waveNumber)
        z[4] = celerity * sqrt(waveNumber / GRAVITY)
        z[5] = input.currentVelocity * sqrt(waveNumber / GRAVITY)
        z[7] = z[4] - z[5]
        z[6] = z[8] / z[1] - z[7] + z[4]

        val crestElevation = surfaceNodes.first() - input.waterDepth
        val troughElevation = surfaceNodes.last() - input.waterDepth
        val steepness = input.waveHeight / wavelength
        val relativeDepth = input.waterDepth / wavelength
        val ursell = input.waveHeight * wavelength * wavelength /
            input.waterDepth.pow(3)
        val regime = when {
            relativeDepth < 0.05 -> "Shallow"
            relativeDepth < 0.5 -> "Intermediate"
            else -> "Deep"
        }
        val breakingLimit = 0.142 * wavelength * tanh(waveNumber * input.waterDepth)
        val saturation = if (breakingLimit > 0.0) input.waveHeight / breakingLimit else 0.0

        val integrals = calculateIntegralProperties(kd)
        val bedKinematics = kinematics(zFromBed = 0.0, phase = 0.0, kd = kd)
        val tauBed = 0.5 * SEA_WATER_DENSITY * 0.005 * bedKinematics.horizontal.pow(2)
        val bedExcursion = abs(bedKinematics.horizontal) * input.wavePeriod / (2.0 * PI)
        val crestKinematics = kinematics(
            zFromBed = input.waterDepth + crestElevation,
            phase = 0.0,
            kd = kd,
        )
        val troughKinematics = kinematics(
            zFromBed = input.waterDepth + troughElevation,
            phase = PI,
            kd = kd,
        )
        val asymmetry = if (abs(troughKinematics.horizontal) > 0.0) {
            abs(crestKinematics.horizontal / troughKinematics.horizontal)
        } else {
            0.0
        }

        var maximumAcceleration = 0.0
        var maximumVerticalVelocity = 0.0
        for (sample in 0 until 40) {
            val phase = PI * sample / 39.0
            val surface = surfaceKeta(phase)
            val zFromBed = input.waterDepth * (1.0 + surface / kd)
            val point = kinematics(zFromBed, phase, kd)
            maximumAcceleration = max(maximumAcceleration, abs(point.horizontalAcceleration))
            maximumVerticalVelocity = max(maximumVerticalVelocity, abs(point.vertical))
        }

        return WaveSolution(
            waveHeight = input.waveHeight,
            wavePeriod = input.wavePeriod,
            waterDepth = input.waterDepth,
            inputCurrent = input.currentVelocity,
            gravity = GRAVITY,
            density = SEA_WATER_DENSITY,
            wavelength = wavelength,
            waveNumber = waveNumber,
            kd = kd,
            angularFrequency = 2.0 * PI / input.wavePeriod,
            celerity = celerity,
            crestElevation = crestElevation,
            troughElevation = troughElevation,
            steepness = steepness,
            relativeDepth = relativeDepth,
            ursellNumber = ursell,
            regime = regime,
            micheBreakingLimit = breakingLimit,
            saturation = saturation,
            isBreaking = breakingLimit > 0.0 && input.waveHeight > breakingLimit,
            eulerianCurrent = input.currentVelocity,
            stokesCurrent = integrals.stokesCurrent,
            massTransport = integrals.stokesCurrent,
            meanFluidSpeed = integrals.meanFluidSpeed,
            waveVolumeFlux = integrals.waveVolumeFlux,
            volumeFlux = integrals.volumeFlux,
            bernoulliConstant = integrals.bernoulliConstant,
            reducedBernoulliConstant = integrals.reducedBernoulliConstant,
            bernoulliConstantDimensionless = integrals.bernoulliConstantDimensionless,
            kineticEnergy = integrals.kineticEnergy,
            potentialEnergy = integrals.potentialEnergy,
            totalEnergy = integrals.totalEnergy,
            momentumFlux = integrals.momentumFlux,
            radiationStress = integrals.radiationStress,
            impulse = integrals.impulse,
            wavePower = integrals.wavePower,
            groupVelocity = integrals.groupVelocity,
            kineticEnergyDepth = integrals.kineticEnergyDepth,
            potentialEnergyDepth = integrals.potentialEnergyDepth,
            energyDepth = integrals.energyDepth,
            momentumFluxDepth = integrals.momentumFluxDepth,
            radiationStressDepth = integrals.radiationStressDepth,
            impulseDepth = integrals.impulseDepth,
            wavePowerDepth = integrals.wavePowerDepth,
            surfaceHorizontalVelocity = crestKinematics.horizontal,
            bedHorizontalVelocity = bedKinematics.horizontal,
            maxHorizontalAcceleration = maximumAcceleration,
            maxVerticalVelocity = maximumVerticalVelocity,
            velocityAsymmetry = asymmetry,
            meanSquareBedOrbitalVelocity = integrals.meanSquareBedOrbitalVelocity,
            bedOrbitalRmsVelocity = sqrt(max(0.0, integrals.meanSquareBedOrbitalVelocity)),
            tauBed = tauBed,
            bedExcursion = bedExcursion,
            surfaceNodesFromBed = surfaceNodes.toList(),
            streamFunctionCoefficients = streamFunctionCoefficients.toList(),
            surfaceCoefficients = surfaceCoefficients.copyOfRange(0, n + 1).toList(),
            stateVector = z.toList(),
        )
    }

    private fun calculateIntegralProperties(kd: Double): IntegralProperties {
        val celerityDepth = z[4] / sqrt(kd)
        val stokesDepth = z[6] / sqrt(kd)
        val meanFluidSpeedDepth = z[7] / sqrt(kd)
        val volumeFluxDepth = meanFluidSpeedDepth - z[8] / kd.pow(1.5)
        val bernoulliDepth = 1.0 + z[9] / kd

        val impulseK = z[8] + kd * z[5]
        val kineticK = 0.5 * (
            z[4] * impulseK - z[5] * volumeFluxDepth * kd.pow(1.5)
        )
        var potentialK = 0.0
        for (index in 1..n) potentialK += 0.25 * surfaceCoefficients[index].pow(2)
        val meanBedVelocityK = 2.0 * z[9] - z[4].pow(2)
        val fluxTerm = z[7] * kd - z[8]
        val radiationK = 4.0 * kineticK - 3.0 * potentialK +
            meanBedVelocityK * kd + 2.0 * z[5] * fluxTerm
        val powerK = z[4] * (3.0 * kineticK - 2.0 * potentialK) +
            0.5 * meanBedVelocityK * (impulseK + z[4] * kd) +
            z[4] * z[5] * fluxTerm

        val energyDepth = (kineticK + potentialK) / kd.pow(2)
        val kineticDepth = kineticK / kd.pow(2)
        val potentialDepth = potentialK / kd.pow(2)
        val radiationDepth = radiationK / kd.pow(2)
        val powerDepth = powerK / kd.pow(2.5)
        val impulseDepth = impulseK / kd.pow(1.5)
        val dimensionalEnergyScale = SEA_WATER_DENSITY * GRAVITY * input.waterDepth.pow(2)

        val totalEnergy = dimensionalEnergyScale * energyDepth
        val wavePower = SEA_WATER_DENSITY * GRAVITY.pow(1.5) *
            input.waterDepth.pow(2.5) * powerDepth
        val stokesCurrent = stokesDepth * sqrt(GRAVITY * input.waterDepth)
        val meanFluidSpeed = meanFluidSpeedDepth * sqrt(GRAVITY * input.waterDepth)
        val volumeFlux = volumeFluxDepth * sqrt(GRAVITY * input.waterDepth.pow(3))
        val waveVolumeFlux = meanFluidSpeed * input.waterDepth - volumeFlux
        val momentumDepth = momentumFluxDepth(phase = 0.0, points = 1200, kd = kd)
        val meanSquareBedVelocity = meanSquareBedOrbitalVelocity(samples = 720, kd = kd)

        return IntegralProperties(
            stokesCurrent = stokesCurrent,
            meanFluidSpeed = meanFluidSpeed,
            waveVolumeFlux = waveVolumeFlux,
            volumeFlux = volumeFlux,
            bernoulliConstant = bernoulliDepth * GRAVITY * input.waterDepth,
            reducedBernoulliConstant = (bernoulliDepth - 1.0) * GRAVITY * input.waterDepth,
            bernoulliConstantDimensionless = bernoulliDepth,
            kineticEnergy = dimensionalEnergyScale * kineticDepth,
            potentialEnergy = dimensionalEnergyScale * potentialDepth,
            totalEnergy = totalEnergy,
            momentumFlux = dimensionalEnergyScale * momentumDepth,
            radiationStress = dimensionalEnergyScale * radiationDepth,
            impulse = SEA_WATER_DENSITY * sqrt(GRAVITY * input.waterDepth.pow(3)) * impulseDepth,
            wavePower = wavePower,
            groupVelocity = if (abs(totalEnergy) > 1.0e-12) wavePower / totalEnergy else 0.0,
            kineticEnergyDepth = kineticDepth,
            potentialEnergyDepth = potentialDepth,
            energyDepth = energyDepth,
            momentumFluxDepth = momentumDepth,
            radiationStressDepth = radiationDepth,
            impulseDepth = impulseDepth,
            wavePowerDepth = powerDepth,
            meanSquareBedOrbitalVelocity = meanSquareBedVelocity,
        )
    }

    private fun momentumFluxDepth(phase: Double, points: Int, kd: Double): Double {
        val sampleCount = max(50, points)
        val celerity = z[4] / sqrt(kd)
        val bernoulli = 1.0 + z[9] / kd
        val surfaceDepth = 1.0 + surfaceKeta(phase) / kd
        val spacing = surfaceDepth / (sampleCount - 1)
        var integral = 0.0
        var previous = momentumFluxIntegrand(
            y = 0.0,
            phase = phase,
            kd = kd,
            celerity = celerity,
            bernoulli = bernoulli,
        )
        for (sample in 1 until sampleCount) {
            val y = spacing * sample
            val current = momentumFluxIntegrand(y, phase, kd, celerity, bernoulli)
            integral += 0.5 * (previous + current) * spacing
            previous = current
        }
        return integral
    }

    private fun momentumFluxIntegrand(
        y: Double,
        phase: Double,
        kd: Double,
        celerity: Double,
        bernoulli: Double,
    ): Double {
        val point = dimensionlessPoint(phase, kd * (y - 1.0), kd)
        val relativeVelocity = point.horizontal - celerity
        val pressure = bernoulli - y -
            0.5 * (relativeVelocity.pow(2) + point.vertical.pow(2))
        return pressure + relativeVelocity.pow(2)
    }

    private fun meanSquareBedOrbitalVelocity(samples: Int, kd: Double): Double {
        val sampleCount = max(36, samples)
        var sum = 0.0
        for (sample in 0 until sampleCount) {
            val phase = 2.0 * PI * sample / sampleCount
            val velocity = kinematics(0.0, phase, kd).horizontal
            val orbital = velocity - input.currentVelocity
            sum += orbital * orbital
        }
        return sum / sampleCount
    }

    private fun kinematics(zFromBed: Double, phase: Double, kd: Double): Kinematics {
        val waveNumber = kd / input.waterDepth
        val verticalCoordinate = waveNumber * (zFromBed - input.waterDepth)
        val point = dimensionlessPoint(phase, verticalCoordinate, kd)
        val velocityScale = sqrt(GRAVITY * input.waterDepth)
        return Kinematics(
            horizontal = point.horizontal * velocityScale,
            vertical = point.vertical * velocityScale,
            horizontalAcceleration = point.horizontalAcceleration * GRAVITY,
        )
    }

    private fun dimensionlessPoint(phase: Double, verticalCoordinate: Double, kd: Double): Kinematics {
        val celerity = z[4] / sqrt(kd)
        val eulerianCurrent = z[5] / sqrt(kd)
        var horizontal = 0.0
        var vertical = 0.0
        var horizontalDerivative = 0.0
        var verticalDerivative = 0.0

        for (harmonic in 1..n) {
            val cosine = cos(harmonic * phase)
            val sine = sin(harmonic * phase)
            val hyperbolicCosine = cosh(harmonic * verticalCoordinate)
            val hyperbolicSine = sinh(harmonic * verticalCoordinate)
            val stableCosine = hyperbolicCosine +
                hyperbolicSine * hyperbolicTangents[harmonic]
            val stableSine = hyperbolicSine +
                hyperbolicCosine * hyperbolicTangents[harmonic]
            val coefficient = streamFunctionCoefficients[harmonic]

            horizontal += harmonic * coefficient * stableCosine * cosine
            vertical += harmonic * coefficient * stableSine * sine
            horizontalDerivative -= harmonic * harmonic * coefficient * stableCosine * sine
            verticalDerivative += harmonic * harmonic * coefficient * stableSine * cosine
        }

        horizontal /= sqrt(kd)
        vertical /= sqrt(kd)
        horizontalDerivative *= sqrt(kd)
        verticalDerivative *= sqrt(kd)
        horizontal += eulerianCurrent

        val timeDerivative = -celerity * horizontalDerivative
        val verticalHorizontalDerivative = verticalDerivative
        val horizontalAcceleration = timeDerivative +
            horizontal * horizontalDerivative + vertical * verticalHorizontalDerivative
        return Kinematics(horizontal, vertical, horizontalAcceleration)
    }

    private fun surfaceKeta(phase: Double): Double {
        var surface = 0.0
        for (harmonic in 1 until n) {
            surface += surfaceCoefficients[harmonic] * cos(harmonic * phase)
        }
        surface += 0.5 * surfaceCoefficients[n] * cos(n * phase)
        return surface
    }

    private fun restoreLastContinuationState() {
        for (index in 1..numberOfUnknowns) z[index] = continuationStates[index][2]
    }

    private fun stateIsUsable(): Boolean = z[1] > 0.0 && activeValuesAreFinite(z)

    private fun activeValuesAreFinite(values: DoubleArray): Boolean {
        for (index in 1..numberOfUnknowns) if (!values[index].isFinite()) return false
        return true
    }

    private fun validateInput(value: WaveInput) {
        if (!value.waveHeight.isFinite() || value.waveHeight <= 0.0) {
            throw InvalidWaveInputException("Wave height H must be a finite value greater than zero.")
        }
        if (!value.wavePeriod.isFinite() || value.wavePeriod <= 0.0) {
            throw InvalidWaveInputException("Wave period T must be a finite value greater than zero.")
        }
        if (!value.waterDepth.isFinite() || value.waterDepth <= 0.0) {
            throw InvalidWaveInputException("Water depth d must be a finite value greater than zero.")
        }
        if (!value.currentVelocity.isFinite()) {
            throw InvalidWaveInputException("Current velocity Uc must be finite.")
        }
    }

    private data class Kinematics(
        val horizontal: Double,
        val vertical: Double,
        val horizontalAcceleration: Double,
    )

    private data class IntegralProperties(
        val stokesCurrent: Double,
        val meanFluidSpeed: Double,
        val waveVolumeFlux: Double,
        val volumeFlux: Double,
        val bernoulliConstant: Double,
        val reducedBernoulliConstant: Double,
        val bernoulliConstantDimensionless: Double,
        val kineticEnergy: Double,
        val potentialEnergy: Double,
        val totalEnergy: Double,
        val momentumFlux: Double,
        val radiationStress: Double,
        val impulse: Double,
        val wavePower: Double,
        val groupVelocity: Double,
        val kineticEnergyDepth: Double,
        val potentialEnergyDepth: Double,
        val energyDepth: Double,
        val momentumFluxDepth: Double,
        val radiationStressDepth: Double,
        val impulseDepth: Double,
        val wavePowerDepth: Double,
        val meanSquareBedOrbitalVelocity: Double,
    )
}

