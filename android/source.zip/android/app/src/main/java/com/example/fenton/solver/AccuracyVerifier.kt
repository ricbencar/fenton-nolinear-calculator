package com.example.fenton.solver

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Independent post-solve acceptance tests used by the revised desktop solver. */
internal object AccuracyVerifier {
    fun verify(solution: WaveSolution): WaveSolution {
        val n = solution.diagnostics.fourierOrder
        val boundary = surfaceResidual(solution, max(2048, 32 * n))
        val beta = solution.meanSquareBedAbsoluteVelocity
        val powerReference = solution.celerity * (3 * solution.kineticEnergy - 2 * solution.potentialEnergy) +
            0.5 * beta * (solution.impulse + solution.density * solution.celerity * solution.waterDepth) -
            2 * solution.celerity * solution.eulerianCurrent * solution.impulse
        val stressReference = 4 * solution.kineticEnergy - 3 * solution.potentialEnergy +
            solution.density * beta * solution.waterDepth - 2 * solution.eulerianCurrent * solution.impulse
        val spectral = max(ratio(solution.wavePower, powerReference), ratio(solution.radiationStress, stressReference))
        val coarse = definingIntegrals(solution, max(256, 8 * n), 64)
        val fine = definingIntegrals(solution, max(512, 16 * n), 96)
        val reported = doubleArrayOf(solution.impulse, solution.kineticEnergy, solution.potentialEnergy,
            solution.radiationStress, solution.wavePower)
        val integral = fine.indices.maxOf { ratio(reported[it], fine[it]) }
        val quadrature = fine.indices.maxOf { ratio(coarse[it], fine[it]) }
        val certificate = FiniteSystemVerifier.verify(solution)
        val failures = buildList {
            if (!boundary.isFinite() || boundary > 1e-6) add("interpolated-surface residual exceeds 1e-6")
            if (!spectral.isFinite() || spectral > 1) add("spectral-bed comparison exceeds its budget")
            if (!integral.isFinite() || integral > 1) add("defining-integral comparison exceeds its budget")
            if (!quadrature.isFinite() || quadrature > 1) add("quadrature refinement exceeds its budget")
            if (!certificate.passed) add("finite-system interval verification exceeds its budget")
        }
        if (failures.isNotEmpty()) {
            throw FentonAccuracyException(
                "The collocation system converged, but the available Fourier resolution " +
                    "(N=$n) does not satisfy the output accuracy budgets: " + failures.joinToString("; ") + ".",
            )
        }
        return solution.copy(diagnostics = solution.diagnostics.copy(
            surfaceResidualMax = boundary,
            spectralBudgetRatio = spectral,
            integralBudgetRatio = integral,
            quadratureBudgetRatio = quadrature,
            intervalResidualMax = certificate.residualUpper,
            intervalOutputBudgetRatio = certificate.outputRatio,
            verified = true,
        ))
    }

    private fun ratio(actual: Double, expected: Double): Double =
        abs(actual - expected) / (1e-7 + 1e-8 * abs(expected))

    private fun surface(solution: WaveSolution, phase: Double): Double {
        val n = solution.diagnostics.fourierOrder
        var result = 0.0
        for (j in 1..n) {
            result += solution.surfaceCoefficients[j] * cos(j * phase) * if (j == n) 0.5 else 1.0
        }
        return result
    }

    private fun surfaceResidual(solution: WaveSolution, count: Int): Double {
        val n = solution.diagnostics.fourierOrder
        val z = solution.stateVector
        var maximum = 0.0
        for (i in 0 until count) {
            val phase = 2 * PI * i / count
            val eta = surface(solution, phase)
            var psi = 0.0
            var u = 0.0
            var v = 0.0
            for (j in 1..n) {
                val ep = exp(j * eta)
                val em = exp(-j * eta - 2 * j * solution.kd)
                val den = 1 + exp(-2 * j * solution.kd)
                val b = solution.streamFunctionCoefficients[j]
                psi += b * (ep - em) / den * cos(j * phase)
                u += j * b * (ep + em) / den * cos(j * phase)
                v += j * b * (ep - em) / den * sin(j * phase)
            }
            maximum = max(maximum, abs(psi - z[8] - z[7] * eta))
            maximum = max(maximum, abs(0.5 * ((u - z[7]) * (u - z[7]) + v * v) + eta - z[9]))
        }
        return maximum
    }

    /** Integrates physical definitions, independently of the algebraic invariants. */
    private fun definingIntegrals(solution: WaveSolution, phases: Int, verticalCount: Int): DoubleArray {
        val (nodes, weights) = gaussLegendre(verticalCount)
        val n = solution.diagnostics.fourierOrder
        val total = DoubleArray(5)
        val d = solution.waterDepth
        val g = solution.gravity
        val rho = solution.density
        val amplitudes = DoubleArray(n + 1) { j ->
            j * solution.streamFunctionCoefficients[j] * sqrt(g / solution.waveNumber)
        }
        val denominators = DoubleArray(n + 1) { 1 + exp(-2 * it * solution.kd) }
        for (i in 0 until phases) {
            if (Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException()
            val phase = 2 * PI * i / phases
            val eta = surface(solution, phase) / solution.waveNumber
            val thickness = (d + eta) / 2
            if (thickness <= 0) throw FentonAccuracyException("The interpolated surface intersects the bed.")
            val cosines = DoubleArray(n + 1) { cos(it * phase) }
            val sines = DoubleArray(n + 1) { sin(it * phase) }
            total[2] += 0.5 * rho * g * eta * eta / phases
            for (vIndex in nodes.indices) {
                val y = -d + thickness * (nodes[vIndex] + 1)
                var u = solution.eulerianCurrent
                var v = 0.0
                for (j in 1..n) {
                    val a = solution.waveNumber * y * j
                    val ep = exp(a)
                    val em = exp(-a - 2 * j * solution.kd)
                    u += (ep + em) / denominators[j] * amplitudes[j] * cosines[j]
                    v += (ep - em) / denominators[j] * amplitudes[j] * sines[j]
                }
                val speedSquared = u * u + v * v
                val relative = u - solution.celerity
                val pressure = rho * (solution.reducedBernoulliConstant - g * y -
                    0.5 * (relative * relative + v * v))
                val weight = weights[vIndex] * thickness / phases
                total[0] += rho * u * weight
                total[1] += 0.5 * rho * speedSquared * weight
                total[3] += (pressure + rho * u * u) * weight
                total[4] += (pressure + rho * g * y + 0.5 * rho * speedSquared) * u * weight
            }
        }
        total[3] -= 0.5 * rho * g * d * d
        return total
    }

    private fun gaussLegendre(count: Int): Pair<DoubleArray, DoubleArray> {
        val nodes = DoubleArray(count)
        val weights = DoubleArray(count)
        for (i in 0 until (count + 1) / 2) {
            var x = cos(PI * (i + 0.75) / (count + 0.5))
            var derivative = 0.0
            for (iteration in 0 until 32) {
                var previous = 1.0
                var current = x
                for (j in 2..count) {
                    val next = ((2 * j - 1) * x * current - (j - 1) * previous) / j
                    previous = current
                    current = next
                }
                derivative = count * (x * current - previous) / (x * x - 1)
                val step = current / derivative
                x -= step
                if (abs(step) < 2e-16) break
                check(iteration < 31) { "Gauss-Legendre quadrature did not converge." }
            }
            val weight = 2 / ((1 - x * x) * derivative * derivative)
            nodes[i] = -x
            nodes[count - 1 - i] = x
            weights[i] = weight
            weights[count - 1 - i] = weight
        }
        return nodes to weights
    }
}
