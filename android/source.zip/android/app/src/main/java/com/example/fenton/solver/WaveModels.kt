package com.example.fenton.solver

/** Inputs for the finite-depth, period-specified Fenton wave problem. */
data class WaveInput(
    val waveHeight: Double,
    val wavePeriod: Double,
    val waterDepth: Double,
    val currentVelocity: Double = 0.0,
)

/**
 * A converged stream-function solution.
 *
 * Dimensional values use SI units. Quantities ending in `Depth` are the
 * dimensionless, depth-scaled invariants printed by Fenton's Solution.res.
 * The state and coefficient lists are immutable snapshots of the converged
 * calculation and retain the solver's one-based state-vector convention.
 */
data class WaveSolution(
    val waveHeight: Double,
    val wavePeriod: Double,
    val waterDepth: Double,
    val inputCurrent: Double,
    val gravity: Double,
    val density: Double,
    val wavelength: Double,
    val waveNumber: Double,
    val kd: Double,
    val angularFrequency: Double,
    val celerity: Double,
    val crestElevation: Double,
    val troughElevation: Double,
    val steepness: Double,
    val relativeDepth: Double,
    val ursellNumber: Double,
    val regime: String,
    val micheBreakingLimit: Double,
    val saturation: Double,
    val isBreaking: Boolean,
    val eulerianCurrent: Double,
    val stokesCurrent: Double,
    val massTransport: Double,
    val meanFluidSpeed: Double,
    val waveVolumeFlux: Double,
    val volumeFlux: Double,
    val bernoulliConstant: Double,
    val reducedBernoulliConstant: Double,
    val bernoulliConstantDimensionless: Double,
    val kineticEnergy: Double,
    val potentialEnergy: Double,
    val totalEnergy: Double,
    val momentumFlux: Double,
    val radiationStress: Double,
    val impulse: Double,
    val wavePower: Double,
    val groupVelocity: Double,
    val kineticEnergyDepth: Double,
    val potentialEnergyDepth: Double,
    val energyDepth: Double,
    val momentumFluxDepth: Double,
    val radiationStressDepth: Double,
    val impulseDepth: Double,
    val wavePowerDepth: Double,
    val surfaceHorizontalVelocity: Double,
    val bedHorizontalVelocity: Double,
    val maxHorizontalAcceleration: Double,
    val maxVerticalVelocity: Double,
    val velocityAsymmetry: Double,
    val meanSquareBedOrbitalVelocity: Double,
    val bedOrbitalRmsVelocity: Double,
    val tauBed: Double,
    val bedExcursion: Double,
    val surfaceNodesFromBed: List<Double>,
    val streamFunctionCoefficients: List<Double>,
    val surfaceCoefficients: List<Double>,
    val stateVector: List<Double>,
)

/** The two calculations performed by the desktop application. */
data class FentonCalculation(
    val noCurrent: WaveSolution,
    val withCurrent: WaveSolution,
)

open class FentonSolverException(message: String, cause: Throwable? = null) :
    RuntimeException(message, cause)

class InvalidWaveInputException(message: String) : FentonSolverException(message)

class FentonConvergenceException(message: String, cause: Throwable? = null) :
    FentonSolverException(message, cause)

