package com.example.fenton.solver

/** Inputs for the finite-depth, period-specified Fenton wave problem. */
data class WaveInput(
    val waveHeight: Double,
    val wavePeriod: Double,
    val waterDepth: Double,
    val currentVelocity: Double = 0.0,
)

/**
 * A converged stream-function solution.
 *
 * Dimensional values use SI units. Quantities ending in `Depth` are the
 * dimensionless, depth-scaled invariants printed by Fenton's Solution.res.
 * The state and coefficient lists are immutable snapshots of the converged
 * calculation and retain the solver's one-based state-vector convention.
 */
data class WaveSolution(
    val waveHeight: Double,
    val wavePeriod: Double,
    val waterDepth: Double,
    val inputCurrent: Double,
    val gravity: Double,
    val density: Double,
    val wavelength: Double,
    val waveNumber: Double,
    val kd: Double,
    val angularFrequency: Double,
    val celerity: Double,
    val crestElevation: Double,
    val troughElevation: Double,
    val steepness: Double,
    val relativeDepth: Double,
    val ursellNumber: Double,
    val regime: String,
    val micheBreakingLimit: Double,
    val saturation: Double,
    val isBreaking: Boolean,
    val eulerianCurrent: Double,
    val stokesCurrent: Double,
    val massTransport: Double,
    val meanFluidSpeed: Double,
    val waveVolumeFlux: Double,
    val volumeFlux: Double,
    val bernoulliConstant: Double,
    val reducedBernoulliConstant: Double,
    val bernoulliConstantDimensionless: Double,
    val kineticEnergy: Double,
    val potentialEnergy: Double,
    val totalEnergy: Double,
    val momentumFlux: Double,
    val radiationStress: Double,
    val impulse: Double,
    val wavePower: Double,
    val groupVelocity: Double,
    val kineticEnergyDepth: Double,
    val potentialEnergyDepth: Double,
    val energyDepth: Double,
    val momentumFluxDepth: Double,
    val radiationStressDepth: Double,
    val impulseDepth: Double,
    val wavePowerDepth: Double,
    val surfaceHorizontalVelocity: Double,
    val bedHorizontalVelocity: Double,
    val maxHorizontalAcceleration: Double,
    val maxVerticalVelocity: Double,
    val velocityAsymmetry: Double,
    val meanSquareBedOrbitalVelocity: Double,
    val bedOrbitalRmsVelocity: Double,
    val tauBed: Double,
    val bedExcursion: Double,
    val surfaceNodesFromBed: List<Double>,
    val streamFunctionCoefficients: List<Double>,
    val surfaceCoefficients: List<Double>,
    val stateVector: List<Double>,
    val maxBedHorizontalAcceleration: Double = 0.0,
    val meanSquareBedAbsoluteVelocity: Double = meanSquareBedOrbitalVelocity + eulerianCurrent * eulerianCurrent,
    val extremaPhases: List<Double> = emptyList(),
    val currentCriterion: Int = 1,
    val diagnostics: SolverDiagnostics = SolverDiagnostics(),
)

/** Numerical acceptance evidence, not a proof of existence of an exact water wave. */
data class SolverDiagnostics(
    val fourierOrder: Int = 50,
    val requestedOrder: Int = 50,
    val residualMax: Double = Double.POSITIVE_INFINITY,
    val jacobianCondition: Double = Double.POSITIVE_INFINITY,
    val numericalNote: String = "",
    val surfaceResidualMax: Double = Double.POSITIVE_INFINITY,
    val spectralBudgetRatio: Double = Double.POSITIVE_INFINITY,
    val integralBudgetRatio: Double = Double.POSITIVE_INFINITY,
    val quadratureBudgetRatio: Double = Double.POSITIVE_INFINITY,
    val intervalResidualMax: Double = Double.POSITIVE_INFINITY,
    val intervalOutputBudgetRatio: Double = Double.POSITIVE_INFINITY,
    val verified: Boolean = false,
)

class FentonAccuracyException(message: String) : FentonSolverException(message)

/** The two calculations performed by the desktop application. */
data class FentonCalculation(
    val noCurrent: WaveSolution?,
    val withCurrent: WaveSolution?,
    val input: WaveInput = requireNotNull(withCurrent ?: noCurrent).let {
        WaveInput(it.waveHeight, it.wavePeriod, it.waterDepth, it.inputCurrent)
    },
    val noCurrentFailure: String? = null,
    val withCurrentFailure: String? = null,
)

open class FentonSolverException(message: String, cause: Throwable? = null) :
    RuntimeException(message, cause)

class InvalidWaveInputException(message: String) : FentonSolverException(message)

class FentonConvergenceException(message: String, cause: Throwable? = null) :
    FentonSolverException(message, cause)

