package com.example.fenton.solver

import java.math.BigDecimal

/** Independent enclosures of the stored finite state, not a root-existence proof. */
internal object FiniteSystemVerifier {
    data class Certificate(val residualUpper: Double, val outputRatio: Double, val passed: Boolean)

    fun verify(solution: WaveSolution): Certificate {
        val z = solution.stateVector.map { DecimalInterval(it) }
        val n = solution.diagnostics.fourierOrder
        val h = DecimalInterval(solution.waveHeight)
        val t = DecimalInterval(solution.wavePeriod)
        val d = DecimalInterval(solution.waterDepth)
        val uc = DecimalInterval(solution.inputCurrent)
        val g = DecimalInterval(solution.gravity)
        val rho = DecimalInterval(solution.density)
        val residuals = MutableList(2 * n + 10) { DecimalInterval(0) }
        residuals[0] = z[2] - z[1] * h / d
        residuals[1] = z[2] - h / (g * t.square()) * z[3].square()
        residuals[2] = z[4] * z[3] - 2 * DecimalInterval.PI
        residuals[3] = z[5] + z[7] - z[4]
        residuals[4] = z[1] * (z[6] + z[7] - z[4]) - z[8]
        residuals[5] = z[solution.currentCriterion + 4] - uc / (g * d).sqrt() * z[1].sqrt()
        residuals[6] = z[10] + z[n + 10] +
            2 * (11 until n + 10).fold(DecimalInterval(0)) { sum, j -> sum + z[j] }
        residuals[7] = z[10] - z[n + 10] - z[2]
        val table = collocationTable(n)
        val denominators = (1..n).map { (-2 * it * z[1]).exp() + 1 }
        for (m in 0..n) {
            if (Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException()
            val eta = z[m + 10]
            var psi = DecimalInterval(0)
            var u = DecimalInterval(0)
            var v = DecimalInterval(0)
            for (j in 1..n) {
                val ep = (j * eta).exp()
                val em = (-j * eta - 2 * j * z[1]).exp()
                val s = (ep - em) / denominators[j - 1]
                val c = (ep + em) / denominators[j - 1]
                val (sine, cosine) = table[(m * j) % (2 * n)]
                val b = z[n + 10 + j]
                psi += b * s * cosine
                u += j * b * c * cosine
                v += j * b * s * sine
            }
            residuals[8 + m] = psi - z[8] - z[7] * eta
            residuals[n + 9 + m] = ((u - z[7]).square() + v.square()) / 2 + eta - z[9]
        }
        val k = z[1] / d
        val speed = (g / k).sqrt()
        val scale = rho * g / k.square()
        val pulse = z[8] + z[1] * z[5]
        val kinetic = (z[4] * pulse - z[5] * (z[7] * z[1] - z[8])) / 2
        val y = solution.surfaceCoefficients.map { DecimalInterval(it) }
        val potential = (1 until n).fold(DecimalInterval(0)) { sum, j -> sum + y[j].square() / 4 } +
            y[n].square() / 16
        val beta = 2 * z[9] - z[4].square() + 2 * z[4] * z[5]
        val stress = 4 * kinetic - 3 * potential + beta * z[1] - 2 * z[5] * pulse
        val power = z[4] * (3 * kinetic - 2 * potential) +
            beta * (pulse + z[4] * z[1]) / 2 - 2 * z[4] * z[5] * pulse
        var bed = DecimalInterval(0)
        for (j in 1..n) {
            val sech = 2 * (-j * z[1]).exp() / denominators[j - 1]
            bed += (j * z[n + 10 + j] * sech).square() / 2
        }
        val outputs = listOf(
            2 * DecimalInterval.PI / k to solution.wavelength,
            z[4] * speed to solution.celerity,
            rho * speed / k * pulse to solution.impulse,
            scale * kinetic to solution.kineticEnergy,
            scale * potential to solution.potentialEnergy,
            scale * (kinetic + potential) to solution.totalEnergy,
            scale * stress to solution.radiationStress,
            scale * speed * power to solution.wavePower,
            g / k * bed to solution.meanSquareBedOrbitalVelocity,
        )
        val upper = residuals.maxOf { it.magnitude() }
        val tolerance = minOf(BigDecimal("1e-10"), BigDecimal(1e-10))
        var valid = upper <= tolerance
        var maximumRatio = 0.0
        for ((interval, reported) in outputs) {
            val error = (DecimalInterval(reported) - interval).magnitude()
            val budget = BigDecimal("1e-7").add(
                BigDecimal("1e-8").multiply(interval.minimumMagnitude(), DecimalInterval.DOWN), DecimalInterval.DOWN,
            )
            valid = valid && error <= budget
            maximumRatio = maxOf(maximumRatio, error.divide(budget, DecimalInterval.UP).toDouble())
        }
        return Certificate(upper.toDouble(), maximumRatio, valid)
    }

    private fun factorial(n: Int): BigDecimal =
        (2..n).fold(BigDecimal.ONE) { value, i -> value.multiply(BigDecimal(i)) }

    private fun collocationTable(order: Int): List<Pair<DecimalInterval, DecimalInterval>> =
        List(2 * order) { index ->
            val q = if (index <= order) index else index - 2 * order
            val x = DecimalInterval.PI * q / order
            val square = x.square()
            var sine = DecimalInterval(0)
            var cosine = DecimalInterval(0)
            var st = x
            var ct = DecimalInterval(1)
            repeat(32) { m ->
                sine += st
                cosine += ct
                st = -st * square / ((2 * m + 2) * (2 * m + 3))
                ct = -ct * square / ((2 * m + 1) * (2 * m + 2))
            }
            val radius = DecimalInterval(x.magnitude())
            val sinError = (radius.pow(65) / DecimalInterval(factorial(65))).hi
            val cosError = (radius.pow(64) / DecimalInterval(factorial(64))).hi
            sine + DecimalInterval(sinError.negate(), sinError) to
                cosine + DecimalInterval(cosError.negate(), cosError)
        }
}
