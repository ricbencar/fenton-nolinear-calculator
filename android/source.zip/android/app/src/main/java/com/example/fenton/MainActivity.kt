package com.example.fenton

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.fenton.ui.dashboard.FentonDashboardScreen
import com.example.fenton.ui.dashboard.FentonDashboardViewModel
import com.example.fenton.ui.theme.FentonTheme

class MainActivity : ComponentActivity() {
    private val dashboardViewModel: FentonDashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FentonTheme {
                val state by dashboardViewModel.uiState.collectAsState()
                FentonDashboardScreen(
                    state = state,
                    onIntent = dashboardViewModel::onIntent,
                )
            }
        }
    }
}
