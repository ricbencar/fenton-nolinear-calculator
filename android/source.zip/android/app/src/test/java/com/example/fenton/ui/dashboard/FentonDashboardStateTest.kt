package com.example.fenton.ui.dashboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FentonDashboardStateTest {
    @Test
    fun validation_acceptsPointCommaAndSignedCurrent() {
        val result = validateDashboardInputs(
            height = "3,0",
            period = "9.0",
            depth = "5",
            current = "-1,25",
        )

        assertTrue(result.invalidFields.isEmpty())
        assertNotNull(result.input)
        assertEquals(-1.25, result.input!!.currentVelocity, 0.0)
    }

    @Test
    fun validation_reportsEveryInvalidField() {
        val result = validateDashboardInputs(
            height = "0",
            period = "NaN",
            depth = "-2",
            current = "not-a-number",
        )

        assertNull(result.input)
        assertEquals(DashboardInputField.entries.toSet(), result.invalidFields)
    }
}
