package com.example.fenton.solver

import java.math.BigDecimal
import kotlin.math.PI
import kotlin.math.sqrt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class FentonSolverTest {
    @Test
    fun acceptedStatesPreservePhysicalAndScalingIdentities() {
        val calculation = PythonReferenceFixtures.defaultCalculation
        for (solution in listOfNotNull(calculation.noCurrent, calculation.withCurrent)) {
            assertEquals(2 * PI / solution.waveNumber, solution.wavelength, 1e-10)
            assertEquals(solution.wavelength / solution.wavePeriod, solution.celerity, 1e-10)
            assertEquals(solution.waveHeight, solution.crestElevation - solution.troughElevation, 1e-10)
            assertEquals(solution.kineticEnergy + solution.potentialEnergy, solution.totalEnergy, 1e-8)
            assertEquals(solution.meanSquareBedOrbitalVelocity + solution.eulerianCurrent * solution.eulerianCurrent,
                solution.meanSquareBedAbsoluteVelocity, 1e-10)
            assertEquals(sqrt(solution.meanSquareBedOrbitalVelocity), solution.bedOrbitalRmsVelocity, 1e-10)
            val n = solution.diagnostics.fourierOrder
            assertEquals(n + 1, solution.surfaceCoefficients.size)
            assertEquals(2 * n + 11, solution.stateVector.size)
            assertTrue(solution.stateVector.all(Double::isFinite))
        }
    }

    @Test(expected = InvalidWaveInputException::class)
    fun invalidInputHasClearException() {
        FentonCalculator.calculate(0.0, 9.0, 5.0, 0.0)
    }

    @Test
    fun rankDeficientJacobianUsesTruncatedMinimumNormSolution() {
        val result = LinearAlgebra.solve(doubleArrayOf(1.0, 1.0, 2.0, 2.0), doubleArrayOf(3.0, 6.0), 2)
        assertEquals(1.5, result.correction[0], 1e-10)
        assertEquals(1.5, result.correction[1], 1e-10)
        assertTrue(result.condition > 1e11)
    }

    @Test
    fun decimalTranscendentalEnclosuresContainKnownHighPrecisionValues() {
        val e = DecimalInterval(1).exp()
        val exactE = BigDecimal("2.7182818284590452353602874713526624977572470936999595749669676")
        assertTrue(e.lo <= exactE && e.hi >= exactE)
        val root = DecimalInterval(2).sqrt()
        val exactRoot = BigDecimal("1.4142135623730950488016887242096980785696718753769480731766797")
        assertTrue(root.lo <= exactRoot && root.hi >= exactRoot)
        val identity = DecimalInterval(7).exp() * DecimalInterval(-7).exp()
        assertTrue(identity.lo <= BigDecimal.ONE && identity.hi >= BigDecimal.ONE)
        assertEquals(0.0, DecimalInterval(BigDecimal(-1), BigDecimal.ONE).minimumMagnitude().toDouble(), 0.0)
    }

    @Test(expected = FentonAccuracyException::class)
    fun corruptedFiniteStateIsNotAccepted() {
        val solution = requireNotNull(PythonReferenceFixtures.defaultCalculation.noCurrent)
        val state = solution.stateVector.toMutableList()
        state[2] += 1e-5
        AccuracyVerifier.verify(solution.copy(stateVector = state))
    }

    @Test
    fun fullAuditIsOptInAndFastChecksDoNotRetainItsCertificate() {
        val fast = requireNotNull(PythonReferenceFixtures.defaultCalculation.withCurrent)
        assertTrue(fast.diagnostics.verified)
        assertFalse(fast.diagnostics.fullyVerified)
        val full = AccuracyVerifier.verify(fast, VerificationLevel.FULL)
        assertTrue(full.diagnostics.fullyVerified)
        assertTrue(full.diagnostics.intervalResidualMax <= 1e-10)
        assertTrue(full.diagnostics.intervalOutputBudgetRatio <= 1.0)
        assertTrue(full.diagnostics.integralBudgetRatio <= 1.0)
        assertTrue(full.diagnostics.quadratureBudgetRatio <= 1.0)
        assertEquals(fast.copy(diagnostics = full.diagnostics), full)
        val rechecked = AccuracyVerifier.verify(full)
        assertFalse(rechecked.diagnostics.fullyVerified)
        assertEquals(Double.POSITIVE_INFINITY, rechecked.diagnostics.intervalResidualMax, 0.0)
    }

    @Test(expected = FentonAccuracyException::class)
    fun fastChecksRejectNonFiniteOutputs() {
        val solution = requireNotNull(PythonReferenceFixtures.defaultCalculation.withCurrent)
        AccuracyVerifier.verify(solution.copy(maxBedHorizontalAcceleration = Double.NaN))
    }

    @Test(expected = FentonAccuracyException::class)
    fun fastChecksRejectInconsistentEnergyFlux() {
        val solution = requireNotNull(PythonReferenceFixtures.defaultCalculation.withCurrent)
        AccuracyVerifier.verify(solution.copy(wavePower = solution.wavePower * 1.01))
    }

    @Test
    fun conditionOnlySvdAgreesWithFullDecomposition() {
        val matrix = doubleArrayOf(3.0, 1.0, 1.0, 2.0)
        val full = LinearAlgebra.solve(matrix, doubleArrayOf(9.0, 8.0), 2)
        val conditionOnly = LinearAlgebra.solve(matrix, doubleArrayOf(0.0, 0.0), 2)
        assertEquals(full.condition, conditionOnly.condition, 0.0)
        assertEquals(2.0, full.correction[0], 1e-12)
        assertEquals(3.0, full.correction[1], 1e-12)
        assertTrue(conditionOnly.correction.all { it == 0.0 })
    }

    @Test
    fun calculatorDefaultsToFastChecksAndDoesNotSolveZeroCurrentTwice() {
        val calculation = FentonCalculator.calculate(1.0, 9.0, 10.0, 0.0)
        val solution = requireNotNull(calculation.noCurrent)
        assertSame(solution, calculation.withCurrent)
        assertEquals(VerificationLevel.FAST, solution.diagnostics.verificationLevel)
        assertFalse(solution.diagnostics.fullyVerified)
    }
}
