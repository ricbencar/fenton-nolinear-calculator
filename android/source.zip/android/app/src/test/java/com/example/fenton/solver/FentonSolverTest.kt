package com.example.fenton.solver

import java.math.BigDecimal
import kotlin.math.PI
import kotlin.math.sqrt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FentonSolverTest {
    @Test
    fun acceptedStatesPreservePhysicalAndScalingIdentities() {
        val calculation = PythonReferenceFixtures.defaultCalculation
        for (solution in listOfNotNull(calculation.noCurrent, calculation.withCurrent)) {
            assertEquals(2 * PI / solution.waveNumber, solution.wavelength, 1e-10)
            assertEquals(solution.wavelength / solution.wavePeriod, solution.celerity, 1e-10)
            assertEquals(solution.waveHeight, solution.crestElevation - solution.troughElevation, 1e-10)
            assertEquals(solution.kineticEnergy + solution.potentialEnergy, solution.totalEnergy, 1e-8)
            assertEquals(solution.meanSquareBedOrbitalVelocity + solution.eulerianCurrent * solution.eulerianCurrent,
                solution.meanSquareBedAbsoluteVelocity, 1e-10)
            assertEquals(sqrt(solution.meanSquareBedOrbitalVelocity), solution.bedOrbitalRmsVelocity, 1e-10)
            val n = solution.diagnostics.fourierOrder
            assertEquals(n + 1, solution.surfaceCoefficients.size)
            assertEquals(2 * n + 11, solution.stateVector.size)
            assertTrue(solution.stateVector.all(Double::isFinite))
        }
    }

    @Test(expected = InvalidWaveInputException::class)
    fun invalidInputHasClearException() {
        FentonCalculator.calculate(0.0, 9.0, 5.0, 0.0)
    }

    @Test
    fun rankDeficientJacobianUsesTruncatedMinimumNormSolution() {
        val result = LinearAlgebra.solve(doubleArrayOf(1.0, 1.0, 2.0, 2.0), doubleArrayOf(3.0, 6.0), 2)
        assertEquals(1.5, result.correction[0], 1e-10)
        assertEquals(1.5, result.correction[1], 1e-10)
        assertTrue(result.condition > 1e11)
    }

    @Test
    fun decimalTranscendentalEnclosuresContainKnownHighPrecisionValues() {
        val e = DecimalInterval(1).exp()
        val exactE = BigDecimal("2.7182818284590452353602874713526624977572470936999595749669676")
        assertTrue(e.lo <= exactE && e.hi >= exactE)
        val root = DecimalInterval(2).sqrt()
        val exactRoot = BigDecimal("1.4142135623730950488016887242096980785696718753769480731766797")
        assertTrue(root.lo <= exactRoot && root.hi >= exactRoot)
        val identity = DecimalInterval(7).exp() * DecimalInterval(-7).exp()
        assertTrue(identity.lo <= BigDecimal.ONE && identity.hi >= BigDecimal.ONE)
        assertEquals(0.0, DecimalInterval(BigDecimal(-1), BigDecimal.ONE).minimumMagnitude().toDouble(), 0.0)
    }

    @Test(expected = FentonAccuracyException::class)
    fun corruptedFiniteStateIsNotAccepted() {
        val solution = requireNotNull(PythonReferenceFixtures.defaultCalculation.noCurrent)
        val state = solution.stateVector.toMutableList()
        state[2] += 1e-5
        AccuracyVerifier.verify(solution.copy(stateVector = state))
    }
}
