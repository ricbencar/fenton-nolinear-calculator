package com.example.fenton.solver

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FentonSolverTest {
    @Test
    fun defaultCaseMatchesPythonReferenceWithoutCurrent() {
        val solution = defaultCalculation.noCurrent

        assertClose(68.62867109005693, solution.wavelength)
        assertClose(0.0915533582011893, solution.waveNumber)
        assertClose(7.625407898895214, solution.celerity)
        assertClose(2.4051941118567726, solution.crestElevation)
        assertClose(-0.5948058881486462, solution.troughElevation)
        assertClose(0.2184314876969172, solution.stokesCurrent)
        assertClose(37.03488205599148, solution.volumeFlux)
        assertClose(8189.35903156973, solution.totalEnergy)
        assertClose(415172.7027545839, solution.momentumFlux)
        assertClose(9464.02894147999, solution.radiationStress)
        assertClose(54133.57836480589, solution.wavePower)
        assertClose(6.610233860320764, solution.groupVelocity)
        assertClose(4.025237414283533, solution.surfaceHorizontalVelocity)
        assertClose(2.05613712461585, solution.bedHorizontalVelocity)
        assertClose(3.189793405132806, solution.maxHorizontalAcceleration)
        assertClose(5.147746063603421, solution.velocityAsymmetry)
        assertClose(0.9096044484082131, solution.meanSquareBedOrbitalVelocity)
        assertFalse(solution.isBreaking)
    }

    @Test
    fun defaultCaseMatchesPythonReferenceWithCurrent() {
        val solution = defaultCalculation.withCurrent

        assertClose(78.82722211566828, solution.wavelength)
        assertClose(0.07970831825025956, solution.waveNumber)
        assertClose(8.758580235074254, solution.celerity)
        assertClose(2.488837526184451, solution.crestElevation)
        assertClose(-0.5111624738155491, solution.troughElevation)
        assertClose(1.1937101424309757, solution.stokesCurrent)
        assertClose(37.82435046321639, solution.volumeFlux)
        assertClose(10823.625401392956, solution.totalEnergy)
        assertClose(428002.0507331675, solution.momentumFlux)
        assertClose(16367.489611182731, solution.radiationStress)
        assertClose(73508.7834872332, solution.wavePower)
        assertClose(6.791512156155453, solution.groupVelocity)
        assertClose(5.268317803179008, solution.surfaceHorizontalVelocity)
        assertClose(3.076420180198054, solution.bedHorizontalVelocity)
        assertClose(3.1018684828177254, solution.maxHorizontalAcceleration)
        assertClose(15.909875223077185, solution.velocityAsymmetry)
        assertClose(0.8006816325079575, solution.meanSquareBedOrbitalVelocity)
        assertFalse(solution.isBreaking)
    }

    @Test
    fun moderateFollowingCurrentMatchesPythonReference() {
        val solution = FentonSolver(
            waveHeight = 1.0,
            wavePeriod = 8.0,
            waterDepth = 10.0,
            currentVelocity = 1.0,
        ).solve()

        assertClose(80.73708350608968, solution.wavelength)
        assertClose(0.5448616554416059, solution.crestElevation)
        assertClose(17650.498191035018, solution.wavePower)
        assertClose(0.08271969614244831, solution.meanSquareBedOrbitalVelocity)
    }

    @Test
    fun opposingCurrentMatchesPythonReference() {
        val solution = FentonSolver(
            waveHeight = 0.5,
            wavePeriod = 5.0,
            waterDepth = 20.0,
            currentVelocity = -0.5,
        ).solve()

        assertClose(33.87227408018249, solution.wavelength)
        assertClose(0.2558413781248845, solution.crestElevation)
        assertClose(-347.09306893251096, solution.wavePower)
        assertClose(0.00013596085979237894, solution.meanSquareBedOrbitalVelocity)
    }

    @Test
    fun convergedSolutionsRespectPhysicalAndScalingInvariants() {
        for (solution in listOf(defaultCalculation.noCurrent, defaultCalculation.withCurrent)) {
            assertClose(2.0 * PI / solution.waveNumber, solution.wavelength, 2.0e-8)
            assertClose(solution.wavelength / solution.wavePeriod, solution.celerity, 2.0e-8)
            assertClose(
                solution.waveHeight,
                solution.crestElevation - solution.troughElevation,
                2.0e-7,
            )
            assertClose(
                solution.kineticEnergy + solution.potentialEnergy,
                solution.totalEnergy,
                2.0e-9,
            )
            assertClose(solution.wavePower / solution.totalEnergy, solution.groupVelocity, 2.0e-9)
            assertClose(
                solution.meanSquareBedOrbitalVelocity,
                solution.bedOrbitalRmsVelocity * solution.bedOrbitalRmsVelocity,
                2.0e-9,
            )
            assertEquals(FentonSolver.FOURIER_ORDER + 1, solution.surfaceNodesFromBed.size)
            assertEquals(FentonSolver.FOURIER_ORDER + 1, solution.surfaceCoefficients.size)
            assertEquals(FentonSolver.FOURIER_ORDER + 1, solution.streamFunctionCoefficients.size)
            assertEquals(2 * FentonSolver.FOURIER_ORDER + 11, solution.stateVector.size)
            assertTrue(solution.stateVector.all(Double::isFinite))
        }
    }

    @Test(expected = InvalidWaveInputException::class)
    fun invalidInputHasClearException() {
        FentonCalculator.calculate(0.0, 9.0, 5.0, 0.0)
    }

    @Test
    fun rankDeficientJacobianUsesTruncatedMinimumNormSolution() {
        val solution = LinearAlgebra.solve(
            a = doubleArrayOf(
                1.0, 1.0,
                2.0, 2.0,
            ),
            b = doubleArrayOf(3.0, 6.0),
            size = 2,
        )

        assertEquals(1.5, solution[0], 1.0e-10)
        assertEquals(1.5, solution[1], 1.0e-10)
    }

    private fun assertClose(
        expected: Double,
        actual: Double,
        relativeTolerance: Double = 1.0e-6,
    ) {
        val tolerance = max(1.0e-8, abs(expected) * relativeTolerance)
        assertEquals(expected, actual, tolerance)
    }

    companion object {
        private val defaultCalculation: FentonCalculation by lazy {
            FentonCalculator.calculate(
                waveHeight = 3.0,
                wavePeriod = 9.0,
                waterDepth = 5.0,
                currentVelocity = 1.0,
            )
        }
    }
}
