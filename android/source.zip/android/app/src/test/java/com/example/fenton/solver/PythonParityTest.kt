package com.example.fenton.solver

import java.util.Locale
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized

@RunWith(Parameterized::class)
internal class PythonParityTest(private val reference: PythonReferenceFixtures.Case) {
    @Test
    fun matchesCurrentPythonAcceptanceAndEveryReportedQuantity() {
        if (!reference.accepted) {
            val failure = reference.result.exceptionOrNull()
            assertTrue("Expected accuracy rejection; got $failure", failure is FentonAccuracyException)
            assertTrue(failure!!.message!!.contains("N=${reference.order}"))
            return
        }
        val solution = reference.result.getOrThrow()
        assertEquals(reference.order, solution.diagnostics.fourierOrder)
        assertTrue(solution.diagnostics.verified)
        assertTrue(solution.diagnostics.residualMax <= 1e-10)
        assertEquals(VerificationLevel.FAST, solution.diagnostics.verificationLevel)
        assertFalse(solution.diagnostics.fullyVerified)
        assertTrue(solution.diagnostics.surfaceResidualMax <= 1e-6)
        assertTrue(solution.diagnostics.spectralBudgetRatio <= 1)
        assertEquals(Double.POSITIVE_INFINITY, solution.diagnostics.intervalResidualMax, 0.0)
        for ((index, entry) in PythonReferenceFixtures.properties.withIndex()) {
            val (name, getter) = entry
            val expected = reference.expected[index]
            val actual = getter(solution)
            assertEquals(name, expected, actual, 1e-7 + 1e-8 * abs(expected))
            assertEquals("$name at report precision",
                String.format(Locale.US, "%.5f", expected), String.format(Locale.US, "%.5f", actual))
        }
    }

    companion object {
        @JvmStatic
        @Parameterized.Parameters(name = "{0}")
        fun cases(): Collection<Array<Any>> = PythonReferenceFixtures.cases.map { arrayOf(it) }
    }
}
