package com.example.fenton.ui.dashboard

import com.example.fenton.solver.FentonCalculation
import com.example.fenton.solver.PythonReferenceFixtures
import com.example.fenton.solver.WaveInput
import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FentonDashboardMapperTest {
    @Test
    fun mapsExactlyNineteenUniqueItemsIntoCanonicalGroups() {
        val dashboard = defaultDashboard

        for (solution in listOfNotNull(dashboard.noCurrent, dashboard.withCurrent)) {
            assertEquals(19, solution.items.size)
            assertEquals((1..19).toSet(), solution.items.map { it.id }.toSet())
            assertEquals(
                listOf(
                    FentonDashboardMapper.DIMENSIONS_SECTION,
                    FentonDashboardMapper.CURRENTS_SECTION,
                    FentonDashboardMapper.INTEGRAL_SECTION,
                    FentonDashboardMapper.ENERGY_SECTION,
                ),
                solution.sections.map { it.title },
            )
            assertEquals(listOf(1, 2, 3, 4, 5), solution.sections[0].items.map { it.id })
            assertEquals(listOf(6, 7, 8, 9, 10, 11, 12), solution.sections[1].items.map { it.id })
            assertEquals(listOf(13, 14, 18, 19), solution.sections[2].items.map { it.id })
            assertEquals(listOf(15, 16, 17), solution.sections[3].items.map { it.id })
        }
    }

    @Test
    fun mapsCalculatedHydrodynamicSequenceIntoSixOrderedSections() {
        val dashboard = defaultDashboard

        assertEquals(35, dashboard.hydrodynamicParameters.size)
        assertFalse(
            dashboard.hydrodynamicParameters.any {
                it.id == HydrodynamicParameterId.HEIGHT_TO_DEPTH ||
                    it.id == HydrodynamicParameterId.DIMENSIONLESS_PERIOD
            },
        )
        assertEquals(35, dashboard.hydrodynamicParameters.map { it.id }.toSet().size)
        assertEquals(
            listOf(
                "Wavelength (L)",
                "Wave number (k)",
                "kd",
                "Angular frequency (ω)",
                "Celerity / phase speed (c)",
                "c/√(gd)",
                "Crest elevation (ηc)",
                "Trough elevation (ηt)",
                "Eulerian current (ū₁)",
                "Stokes current (ū₂)",
                "Mean fluid speed (Ū)",
                "Wave volume flux (q)",
                "Volume flux (Q)",
                "Bernoulli constant (R)",
                "Reduced Bernoulli (r = R−g d)",
                "Kinetic energy (T)",
                "Potential energy (V)",
                "Total energy (E = T+V)",
                "Momentum flux (S)",
                "Radiation stress (Sₓₓ)",
                "Impulse (I)",
                "Wave power (F)",
                "Energy-flux velocity (F/E)",
                "Surface max |u|",
                "Bed max |u|",
                "Surface max |aₓ|",
                "Bed max |aₓ|",
                "Velocity asymmetry |uc|/|ut|",
                "Mean square bed orbital vel ub²",
                "Bed orbital RMS velocity ub,rms",
                "Miche breaking limit (Hmax)",
                "Saturation (H/Hmax)",
                "Breaking status",
                "Ursell number (U)",
                "Regime (by d/L)",
            ),
            dashboard.hydrodynamicParameters.map { it.label },
        )
        assertEquals(
            listOf(
                FentonDashboardMapper.HYDRO_DISPERSION_SECTION,
                FentonDashboardMapper.HYDRO_MEAN_FLOWS_SECTION,
                FentonDashboardMapper.HYDRO_FLUXES_SECTION,
                FentonDashboardMapper.HYDRO_INTEGRALS_SECTION,
                FentonDashboardMapper.HYDRO_KINEMATICS_SECTION,
                FentonDashboardMapper.HYDRO_NONLINEARITY_SECTION,
            ),
            dashboard.hydrodynamicSections.map { it.title },
        )
        assertEquals(listOf(8, 3, 4, 8, 7, 5), dashboard.hydrodynamicSections.map { it.rows.size })
        assertEquals(
            listOf(
                HydrodynamicParameterId.WAVELENGTH,
                HydrodynamicParameterId.WAVE_NUMBER,
                HydrodynamicParameterId.KD,
                HydrodynamicParameterId.ANGULAR_FREQUENCY,
                HydrodynamicParameterId.CELERITY,
                HydrodynamicParameterId.DIMENSIONLESS_CELERITY,
                HydrodynamicParameterId.CREST_ELEVATION,
                HydrodynamicParameterId.TROUGH_ELEVATION,
            ),
            dashboard.hydrodynamicSections.first().rows.map { it.id },
        )
        assertFalse(
            dashboard.hydrodynamicSections.any { it.title == "INPUTS & REFERENCE SCALES" },
        )
        assertEquals(
            listOf(
                HydrodynamicParameterId.MICHE_BREAKING_LIMIT,
                HydrodynamicParameterId.SATURATION,
                HydrodynamicParameterId.BREAKING_STATUS,
                HydrodynamicParameterId.URSELL_NUMBER,
                HydrodynamicParameterId.DEPTH_REGIME,
            ),
            dashboard.hydrodynamicSections.last().rows.map { it.id },
        )
    }

    @Test
    fun exposesEngineeringHighlightsInRequestedOrder() {
        val dashboard = defaultDashboard
        val expected = listOf(
            HydrodynamicParameterId.WAVELENGTH,
            HydrodynamicParameterId.WAVE_NUMBER,
            HydrodynamicParameterId.HEIGHT_TO_DEPTH,
            HydrodynamicParameterId.DIMENSIONLESS_PERIOD,
            HydrodynamicParameterId.CELERITY,
            HydrodynamicParameterId.CREST_ELEVATION,
            HydrodynamicParameterId.TROUGH_ELEVATION,
            HydrodynamicParameterId.MICHE_BREAKING_LIMIT,
            HydrodynamicParameterId.SATURATION,
            HydrodynamicParameterId.MAX_SURFACE_HORIZONTAL_VELOCITY,
            HydrodynamicParameterId.MAX_BED_HORIZONTAL_VELOCITY,
        )

        assertEquals(expected, dashboard.highlights.map { it.id })
        assertEquals((0..10).toList(), dashboard.highlights.map { it.highlightOrder })
        assertTrue(dashboard.highlights.all { it.isHighlight })
        assertEquals(
            listOf(
                "Wavelength (L)",
                "Wave number (k)",
                "Height to depth (H/d)",
                "Dimensionless period τ√(g/d)",
                "Celerity / phase speed (c)",
                "Crest elevation (ηc)",
                "Trough elevation (ηt)",
                "Miche breaking limit (Hmax)",
                "Saturation (H/Hmax)",
                "Surface max |u|",
                "Bed max |u|",
            ),
            dashboard.highlights.map { it.label },
        )
        assertEquals(
            expected.toSet(),
            dashboard.highlights.filter { it.isHighlight }.map { it.id }.toSet(),
        )
        assertEquals(
            listOf(
                "68.70676" to "78.82722",
                "0.09145" to "0.07971",
                "0.60000" to "0.60000",
                "12.60427" to "12.60427",
                "7.63408" to "8.75858",
                "2.43011" to "2.48884",
                "-0.56989" to "-0.51116",
                "4.17414" to "4.23897",
                "0.71871" to "0.70772",
                "4.24991" to "5.26832",
                "1.98889" to "3.07642",
            ),
            dashboard.highlights.map { it.noCurrentValue to it.withCurrentValue },
        )
    }

    @Test
    fun hydrodynamicRowsCarryBothGoldenCasesUnitsAndEnglishDefinitions() {
        val dashboard = defaultDashboard

        assertHydrodynamicRow(
            dashboard,
            HydrodynamicParameterId.WAVE_POWER,
            "Wave power (F)",
            "54.66850",
            "73.50878",
            "kW/m",
        )
        assertHydrodynamicRow(
            dashboard,
            HydrodynamicParameterId.MEAN_SQUARE_BED_ORBITAL_VELOCITY,
            "Mean square bed orbital vel ub²",
            "0.83581",
            "0.80068",
            "m²/s²",
        )
        assertHydrodynamicRow(
            dashboard,
            HydrodynamicParameterId.BREAKING_STATUS,
            "Breaking status",
            "BELOW MICHE",
            "BELOW MICHE",
            "-",
        )
        assertHydrodynamicRow(
            dashboard,
            HydrodynamicParameterId.DEPTH_REGIME,
            "Regime (by d/L)",
            "Intermediate",
            "Intermediate",
            "-",
        )
        assertTrue(
            dashboard.hydrodynamicParameters.all {
                it.label.isNotBlank() && it.definition.isNotBlank() && it.unit.isNotBlank()
            },
        )
    }

    @Test
    fun carriesSubmittedInputsModesAndConvergenceStatus() {
        val dashboard = defaultDashboard

        assertEquals(SubmittedWaveInput(3.0, 9.0, 5.0, 1.0), dashboard.submittedInput)
        assertTrue(dashboard.hasCurrent)
        assertEquals(
            listOf(DashboardMode.NO_CURRENT, DashboardMode.WITH_CURRENT),
            dashboard.availableModes,
        )
        assertEquals(DashboardMode.NO_CURRENT, requireNotNull(dashboard.noCurrent).mode)
        assertEquals("No Current", requireNotNull(dashboard.noCurrent).title)
        assertEquals(DashboardMode.WITH_CURRENT, dashboard.withCurrent?.mode)
        assertEquals("With Current", dashboard.withCurrent?.title)
        assertEquals(dashboard.noCurrent, dashboard.solution(DashboardMode.NO_CURRENT))
        assertEquals(dashboard.withCurrent, dashboard.solution(DashboardMode.WITH_CURRENT))
        assertEquals("Fast calculation • core checks passed", dashboard.statusTitle)
        assertEquals("No current: N=50 • 110 equations\nWith current: N=50 • 110 equations", dashboard.statusSubtitle)
    }

    @Test
    fun mapsGoldenSolutionResValuesWithFixedFiveDecimalFormatting() {
        val noCurrent = requireNotNull(defaultDashboard.noCurrent)
        val withCurrent = requireNotNull(defaultDashboard.withCurrent)

        assertMetric(noCurrent, 2, "68.70676", "m", "λ/d", "13.74135")
        assertMetric(noCurrent, 13, "417.70597", "kN/m", "S/ρgd²", "1.66221")
        assertMetric(noCurrent, 17, "0.83581", "m²/s²", "ub²/gd", "0.01705")
        assertMetric(noCurrent, 19, "54.66850", "kW/m", "F/(ρg³ᐟ²d⁵ᐟ²)", "0.03107")

        assertMetric(withCurrent, 2, "78.82722", "m", "λ/d", "15.76544")
        assertMetric(withCurrent, 13, "428.00205", "kN/m", "S/ρgd²", "1.70318")
        assertMetric(withCurrent, 14, "6.11776", "10³ kg/(m·s)", "I/(ρ√(gd³))", "0.17047")
        assertMetric(withCurrent, 15, "7.40649", "kJ/m²", "T/ρgd²", "0.02947")
        assertMetric(withCurrent, 16, "3.41714", "kJ/m²", "V/ρgd²", "0.01360")
        assertMetric(withCurrent, 17, "1.80068", "m²/s²", "ub²/gd", "0.03672")
        assertMetric(withCurrent, 18, "16.36749", "kN/m", "S_xx/ρgd²", "0.06513")
        assertMetric(withCurrent, 19, "73.50878", "kW/m", "F/(ρg³ᐟ²d⁵ᐟ²)", "0.04177")
    }

    @Test
    fun usesOnlyEnglishLabelsDefinitionsAndRequestedEmphasis() {
        val solution = requireNotNull(defaultDashboard.noCurrent)
        assertEquals(
            listOf(
                "Water depth",
                "Wave length",
                "Wave height",
                "Wave period",
                "Wave speed",
                "Eulerian current",
                "Stokes current",
                "Mean fluid speed",
                "Wave volume flux",
                "Reduced Bernoulli constant",
                "Volume flux",
                "Bernoulli constant",
                "Momentum flux",
                "Impulse",
                "Radiation stress",
                "Wave power",
                "Kinetic energy",
                "Potential energy",
                "Mean square of bed velocity (absolute)",
            ),
            solution.items.map { it.label },
        )
        assertEquals(
            "Still-water depth from the seabed to mean water level; the reference length scale.",
            solution.item(1).definition,
        )
        assertEquals("Crest-to-crest wavelength.", solution.item(2).definition)
        assertEquals("Wave energy flux per unit crest width.", solution.item(19).definition)
        assertTrue(solution.items.all { it.label.isNotBlank() && it.definition.isNotBlank() })
        assertEquals(DashboardEmphasis.PRIMARY, solution.item(2).emphasis)
        assertEquals(DashboardEmphasis.BED, solution.item(17).emphasis)
        assertEquals(DashboardEmphasis.ACCENT, solution.item(19).emphasis)
        assertTrue(
            solution.items
                .filterNot { it.id in setOf(2, 17, 19) }
                .all { it.emphasis == DashboardEmphasis.DEFAULT },
        )
    }

    @Test
    fun fixedFormattingIsIndependentOfDeviceLocale() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale.forLanguageTag("pt-PT"))
            val dashboard = FentonDashboardMapper.map(defaultCalculation)
            assertEquals("68.70676", requireNotNull(dashboard.noCurrent).item(2).physicalValue)
            assertEquals("13.74135", requireNotNull(dashboard.noCurrent).item(2).dimensionlessValue)
            assertEquals(
                "68.70676",
                dashboard.hydrodynamicRow(HydrodynamicParameterId.WAVELENGTH).noCurrentValue,
            )
        } finally {
            Locale.setDefault(previous)
        }
    }

    @Test
    fun omitsWithCurrentDashboardWhenSubmittedCurrentIsZero() {
        val calculation = FentonCalculation(
            noCurrent = defaultCalculation.noCurrent,
            withCurrent = defaultCalculation.noCurrent,
        )
        val dashboard = FentonDashboardMapper.map(calculation)

        assertFalse(dashboard.hasCurrent)
        assertEquals(0.0, dashboard.submittedInput.currentVelocity, 0.0)
        assertNull(dashboard.withCurrent)
        assertEquals(listOf(DashboardMode.NO_CURRENT), dashboard.availableModes)
        assertNull(dashboard.solution(DashboardMode.WITH_CURRENT))
        assertTrue(dashboard.hydrodynamicParameters.all { it.withCurrentValue == null })
        assertEquals(11, dashboard.highlights.size)
    }

    @Test
    fun partialResultsExposeOnlyAcceptedModesAndColumns() {
        val base = defaultCalculation
        for (failedNoCurrent in listOf(true, false)) {
            val calculation = FentonCalculation(
                noCurrent = base.noCurrent.takeUnless { failedNoCurrent },
                withCurrent = base.withCurrent.takeIf { failedNoCurrent },
                input = WaveInput(3.0, 9.0, 5.0, 1.0),
                noCurrentFailure = if (failedNoCurrent) "Accuracy check failed." else null,
                withCurrentFailure = if (!failedNoCurrent) "Accuracy check failed." else null,
            )
            val dashboard = FentonDashboardMapper.map(calculation)
            assertEquals(listOf(if (failedNoCurrent) DashboardMode.WITH_CURRENT else DashboardMode.NO_CURRENT),
                dashboard.availableModes)
            assertTrue(dashboard.statusSubtitle.contains("Accuracy check failed."))
            val rows = dashboard.hydrodynamicParameters + dashboard.highlights
            if (failedNoCurrent) assertTrue(rows.all { it.noCurrentValue == "—" })
            else assertTrue(rows.all { it.withCurrentValue == null })
        }
    }

    private fun assertMetric(
        solution: DashboardSolution,
        id: Int,
        value: String,
        unit: String,
        formula: String,
        dimensionlessValue: String,
    ) {
        val item = solution.item(id)
        assertEquals(value, item.physicalValue)
        assertEquals(unit, item.physicalUnit)
        assertEquals(formula, item.dimensionlessFormula)
        assertEquals(dimensionlessValue, item.dimensionlessValue)
    }

    private fun DashboardSolution.item(id: Int): DashboardMetric =
        requireNotNull(items.firstOrNull { it.id == id }) { "Missing dashboard item $id." }

    private fun assertHydrodynamicRow(
        dashboard: DashboardResult,
        id: HydrodynamicParameterId,
        label: String,
        noCurrentValue: String,
        withCurrentValue: String,
        unit: String,
    ) {
        val row = dashboard.hydrodynamicRow(id)
        assertEquals(label, row.label)
        assertEquals(noCurrentValue, row.noCurrentValue)
        assertEquals(withCurrentValue, row.withCurrentValue)
        assertEquals(unit, row.unit)
    }

    private fun DashboardResult.hydrodynamicRow(id: HydrodynamicParameterId): HydrodynamicRow =
        requireNotNull(hydrodynamicParameters.firstOrNull { it.id == id }) {
            "Missing hydrodynamic row $id."
        }

    companion object {
        private val defaultCalculation get() = PythonReferenceFixtures.defaultCalculation

        private val defaultDashboard by lazy {
            FentonDashboardMapper.map(defaultCalculation)
        }
    }
}
