package com.example.fenton.solver

import kotlin.system.measureNanoTime
import org.junit.Assume.assumeTrue
import org.junit.Test

/**
 * Set FENTON_BENCHMARK=1 and run testDebugUnitTest --tests '*SolverPerformanceTest'.
 * Timings are printed, never used as flaky CI thresholds. No APK is built by this task.
 */
class SolverPerformanceTest {
    @Test
    fun profileDefaultCalculation() {
        assumeTrue(System.getenv("FENTON_BENCHMARK") == "1")
        repeat(3) { run ->
            lateinit var solution: WaveSolution
            val input = WaveInput(3.0, 9.0, 5.0, 1.0)
            val solve = measureNanoTime {
                solution = FentonSolver(input, verificationLevel = VerificationLevel.FULL).solve()
            }
            val fast = measureNanoTime { FentonSolver(input).solve() }
            val validation = measureNanoTime { AccuracyVerifier.verify(solution, VerificationLevel.FULL) }
            val intervals = measureNanoTime { FiniteSystemVerifier.verify(solution) }
            println("PROFILE run=$run fullMs=${solve / 1e6} fastMs=${fast / 1e6} verificationMs=${validation / 1e6} intervalMs=${intervals / 1e6}")
        }
    }
}
