package com.example.fenton.report

import com.example.fenton.solver.FentonCalculation
import com.example.fenton.solver.PythonReferenceFixtures
import com.example.fenton.solver.WaveInput
import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FentonReportFormatterTest {
    @Test
    fun calculatedTablesMatchPythonWithHonestFastVerificationHeader() {
        val report = FentonReportFormatter.format(PythonReferenceFixtures.defaultCalculation)
        fun tables(text: String) = text.substring(text.indexOf("CALCULATED HYDRODYNAMIC PARAMETERS"))
        assertEquals(tables(PythonReferenceFixtures.defaultReport), tables(report))
        assertTrue(report.contains("Fast calculation; core numerical checks passed."))
        assertTrue(report.contains("audits skipped for speed."))
        assertFalse(report.contains("nine output bounds checked"))
        assertFalse(report.contains("interval residual bound"))
    }

    @Test
    fun reportUsesLfAndEveryBoxLineIsExactly107UnicodeCharacters() {
        val report = FentonReportFormatter.format(PythonReferenceFixtures.defaultCalculation)
        assertFalse(report.contains('\r'))
        assertTrue(report.endsWith("\n\n"))
        report.lineSequence().filter { it.startsWith('|') || it.startsWith('+') }.forEach {
            assertEquals(it, 107, it.codePointCount(0, it.length))
        }
    }

    @Test
    fun zeroCurrentOmitsCurrentSolutionAndUsesDashes() {
        val solution = requireNotNull(PythonReferenceFixtures.defaultCalculation.noCurrent)
        val report = FentonReportFormatter.format(FentonCalculation(solution, solution))
        assertTrue(report.contains("SOLUTION.RES (NO CURRENT)"))
        assertFalse(report.contains("SOLUTION.RES (WITH CURRENT)"))
        val row = report.lineSequence().first { it.contains("Water depth (d)") && it.count { c -> c == '|' } == 5 }
        assertEquals("-", row.split('|')[3].trim())
    }

    @Test
    fun rejectedColumnsNeverContainSubstitutedValues() {
        val base = PythonReferenceFixtures.defaultCalculation
        val report = FentonReportFormatter.format(FentonCalculation(
            noCurrent = null, withCurrent = base.withCurrent, input = WaveInput(3.0, 9.0, 5.0, 1.0),
            noCurrentFailure = "Output accuracy budget exceeded.",
        ))
        assertTrue(report.contains("[No current] Output accuracy budget exceeded."))
        assertFalse(report.contains("SOLUTION.RES (NO CURRENT)"))
        val row = report.lineSequence().first { it.contains("Wavelength (L)") }
        assertEquals("-", row.split('|')[2].trim())
        assertEquals("78.82722", row.split('|')[3].trim())
    }

    @Test
    fun formattingIsLocaleIndependentAndHandlesLargeNumbers() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale.forLanguageTag("pt-PT"))
            val base = PythonReferenceFixtures.defaultCalculation
            val report = FentonReportFormatter.format(base.copy(
                noCurrent = requireNotNull(base.noCurrent).copy(wavelength = 1e100),
            ))
            assertTrue(report.contains("1.000000e+100"))
            assertTrue(report.contains("3.00000"))
            assertFalse(report.contains("3,00000"))
        } finally {
            Locale.setDefault(previous)
        }
    }
}
