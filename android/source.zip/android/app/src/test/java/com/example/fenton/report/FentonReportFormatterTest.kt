package com.example.fenton.report

import com.example.fenton.solver.FentonCalculation
import com.example.fenton.solver.FentonCalculator
import com.example.fenton.solver.WaveSolution
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sqrt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FentonReportFormatterTest {
    @Test
    fun goldenDefaultMatchesDesktopOutputByteForByte() {
        val reportBytes = FentonReportFormatter.format(defaultCalculation()).toByteArray(Charsets.UTF_8)

        assertGoldenReport(reportBytes)
    }

    @Test
    fun solverDefaultReportMatchesDesktopOutputByteForByte() {
        val calculation = FentonCalculator.calculate(
            waveHeight = 3.0,
            wavePeriod = 9.0,
            waterDepth = 5.0,
            currentVelocity = 1.0,
        )
        val reportBytes = FentonReportFormatter.format(calculation).toByteArray(Charsets.UTF_8)

        assertGoldenReport(reportBytes)
    }

    @Test
    fun goldenDefaultContainsDesktopSectionsAndValues() {
        val report = FentonReportFormatter.format(defaultCalculation())

        val horizontalLine = "+" + "-".repeat(105) + "+"
        assertEquals(horizontalLine, report.lineSequence().first())
        assertTrue(report.contains("NONLINEAR WAVE HYDRODYNAMICS SOLVER (FENTON)"))
        assertTrue(report.contains("Wave height (H)             : 3.0 m"))
        assertTrue(report.contains("Eulerian current ū₁         : 1.0 m/s (positive with wave propagation)"))
        assertTrue(report.contains("CALCULATED HYDRODYNAMIC PARAMETERS"))
        assertTrue(report.contains("68.62867"))
        assertTrue(report.contains("78.82722"))
        assertTrue(report.contains("SOLUTION.RES (NO CURRENT)"))
        assertTrue(report.contains("SOLUTION.RES (WITH CURRENT)"))
        assertTrue(report.contains("PARAMETER DEFINITIONS & GLOSSARY"))
        assertTrue(report.contains("Mean square *orbital* bed velocity"))
        assertTrue(report.contains("0.03076"))
        assertTrue(report.contains("0.04177"))
    }

    @Test
    fun zeroCurrentOmitsCurrentSolutionAndUsesComparisonDashes() {
        val noCurrent = defaultNoCurrentSolution()
        val report = FentonReportFormatter.format(
            FentonCalculation(
                noCurrent = noCurrent,
                withCurrent = noCurrent.copy(inputCurrent = 0.0),
            ),
        )

        assertEquals(1, Regex("SOLUTION\\.RES \\(").findAll(report).count())
        assertTrue(report.contains("SOLUTION.RES (NO CURRENT)"))
        assertFalse(report.contains("SOLUTION.RES (WITH CURRENT)"))

        val waterDepthRow = report.lineSequence().first {
            it.contains("Water depth (d)") && it.count { character -> character == '|' } == 5
        }
        assertTrue(waterDepthRow.contains("-"))
    }

    @Test
    fun reportUsesLfAndEveryBoxLineIsExactly107UnicodeCharacters() {
        val report = FentonReportFormatter.format(defaultCalculation())

        assertFalse(report.contains('\r'))
        assertTrue(report.endsWith("\n\n"))
        report.lineSequence()
            .filter { it.startsWith('|') || it.startsWith('+') }
            .forEachIndexed { index, line ->
                assertEquals(
                    "fixed-width line $index: $line",
                    FentonReportFormatter.REPORT_WIDTH,
                    line.codePointCount(0, line.length),
                )
            }
    }

    @Test
    fun numericFormattingIsLocaleIndependentAndFallsBackToScientificNotation() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale.forLanguageTag("pt-PT"))
            val base = defaultCalculation()
            val report = FentonReportFormatter.format(
                FentonCalculation(
                    noCurrent = base.noCurrent.copy(wavelength = 1.0e100),
                    withCurrent = base.withCurrent.copy(wavelength = 1.0e100),
                ),
            )

            assertTrue(report.contains("1.000000e+100"))
            assertTrue(report.contains("3.00000"))
            assertFalse(report.contains("3,00000"))
        } finally {
            Locale.setDefault(previous)
        }
    }

    private fun defaultCalculation(): FentonCalculation = FentonCalculation(
        noCurrent = defaultNoCurrentSolution(),
        withCurrent = defaultWithCurrentSolution(),
    )

    private fun defaultNoCurrentSolution(): WaveSolution = WaveSolution(
        waveHeight = 3.0,
        wavePeriod = 9.0,
        waterDepth = 5.0,
        inputCurrent = 0.0,
        gravity = 9.80665,
        density = 1025.0,
        wavelength = 68.62867109005693,
        waveNumber = 0.0915533582011893,
        kd = 0.4577667910059465,
        angularFrequency = 2.0 * PI / 9.0,
        celerity = 7.625407898895214,
        crestElevation = 2.4051941118567726,
        troughElevation = -0.5948058881486462,
        steepness = 0.043713508543146574,
        relativeDepth = 0.07285584757191096,
        ursellNumber = 113.03746789409318,
        regime = "Intermediate",
        micheBreakingLimit = 4.17353266600449,
        saturation = 0.7188155071689027,
        isBreaking = false,
        eulerianCurrent = 0.0,
        stokesCurrent = 0.2184314876969172,
        massTransport = 0.2184314876969172,
        meanFluidSpeed = 7.625407898895214,
        waveVolumeFlux = 1.0921574384845911,
        volumeFlux = 37.03488205599148,
        bernoulliConstant = 78.51202719382192,
        reducedBernoulliConstant = 29.478777193821927,
        bernoulliConstantDimensionless = 1.6011997408660843,
        kineticEnergy = 4268.174803606979,
        potentialEnergy = 3921.184227962751,
        totalEnergy = 8189.35903156973,
        momentumFlux = 415172.7027545839,
        radiationStress = 9464.02894147999,
        impulse = 1119.4613744466997,
        wavePower = 54133.57836480589,
        groupVelocity = 6.610233860320764,
        kineticEnergyDepth = 0.016984690915363598,
        potentialEnergyDepth = 0.015603883439324713,
        energyDepth = 0.03258857435468831,
        momentumFluxDepth = 1.6521300924281577,
        radiationStressDepth = 0.03766097073841751,
        impulseDepth = 0.031193916387045724,
        wavePowerDepth = 0.03076357807878592,
        surfaceHorizontalVelocity = 4.025237414283533,
        bedHorizontalVelocity = 2.05613712461585,
        maxHorizontalAcceleration = 3.189793405132806,
        maxVerticalVelocity = 1.8367045261699193,
        velocityAsymmetry = 5.147746063603421,
        meanSquareBedOrbitalVelocity = 0.9096044484082131,
        bedOrbitalRmsVelocity = sqrt(0.9096044484082131),
        tauBed = 10.833480930260313,
        bedExcursion = 2.945199483516321,
        surfaceNodesFromBed = emptyList(),
        streamFunctionCoefficients = emptyList(),
        surfaceCoefficients = emptyList(),
        stateVector = emptyList(),
    )

    private fun defaultWithCurrentSolution(): WaveSolution = defaultNoCurrentSolution().copy(
        inputCurrent = 1.0,
        wavelength = 78.82722211566828,
        waveNumber = 0.07970831825025956,
        kd = 0.3985415912512978,
        celerity = 8.758580235074254,
        crestElevation = 2.488837526184451,
        troughElevation = -0.5111624738155491,
        steepness = 0.038057918565212234,
        relativeDepth = 0.06342986427535371,
        ursellNumber = 149.12954271534963,
        micheBreakingLimit = 4.238969879725234,
        saturation = 0.7077191122184754,
        eulerianCurrent = 1.0,
        stokesCurrent = 1.1937101424309757,
        massTransport = 1.1937101424309757,
        meanFluidSpeed = 7.758580235074253,
        waveVolumeFlux = 0.9685507121548724,
        volumeFlux = 37.82435046321639,
        bernoulliConstant = 79.53137444790065,
        reducedBernoulliConstant = 30.498124447900654,
        bernoulliConstantDimensionless = 1.6219886392988565,
        kineticEnergy = 7406.4859161046215,
        potentialEnergy = 3417.1394852883336,
        totalEnergy = 10823.625401392956,
        momentumFlux = 428002.0507331675,
        radiationStress = 16367.489611182731,
        impulse = 6117.764479958751,
        wavePower = 73508.7834872332,
        groupVelocity = 6.791512156155453,
        kineticEnergyDepth = 0.02947322446768611,
        potentialEnergyDepth = 0.013598097698168065,
        energyDepth = 0.04307132216585418,
        momentumFluxDepth = 1.7031829475918543,
        radiationStressDepth = 0.065132466428374,
        impulseDepth = 0.1704721913766733,
        wavePowerDepth = 0.0417743158423142,
        surfaceHorizontalVelocity = 5.268317803179008,
        bedHorizontalVelocity = 3.076420180198054,
        maxHorizontalAcceleration = 3.1018684828177254,
        maxVerticalVelocity = 1.766424478602979,
        velocityAsymmetry = 15.909875223077185,
        meanSquareBedOrbitalVelocity = 0.8006816325079575,
        bedOrbitalRmsVelocity = sqrt(0.8006816325079575),
        tauBed = 24.25242538314518,
        bedExcursion = 4.406647308355617,
    )

    private fun ByteArray.sha256(): String = MessageDigest.getInstance("SHA-256")
        .digest(this)
        .joinToString(separator = "") { byte -> "%02x".format(Locale.US, byte.toInt() and 0xff) }

    private fun assertGoldenReport(reportBytes: ByteArray) {
        assertEquals(17_011, reportBytes.size)
        assertEquals(
            "7cb801d98e6066daf4770e17357391faff712f3990d2a30ffaa56df36c226544",
            reportBytes.sha256(),
        )
    }
}
