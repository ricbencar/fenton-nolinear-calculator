package com.example.fenton

import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.fenton.ui.dashboard.parseDashboardDecimal

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {
    @Test
    fun useAppContext() {
        // Context of the app under test.
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.example.fenton", appContext.packageName)
    }

    @Test
    fun decimalParser_acceptsCommaAndSignedCurrent() {
        assertEquals(-1.5, parseDashboardDecimal("-1,5")!!, 0.0)
        assertEquals(3.25, parseDashboardDecimal(" 3.25 ")!!, 0.0)
    }

    @Test
    fun decimalParser_rejectsInvalidAndNonFiniteValues() {
        assertEquals(null, parseDashboardDecimal("1,2.3"))
        assertEquals(null, parseDashboardDecimal("NaN"))
        assertEquals(null, parseDashboardDecimal("Infinity"))
    }
}
